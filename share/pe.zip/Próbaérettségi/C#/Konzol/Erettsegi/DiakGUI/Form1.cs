﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiakGUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Beolvas()
        {
            string file = "diak.txt";
            if (File.Exists(file))
            {
                StreamReader f = new StreamReader(file);
                while (!f.EndOfStream)
                {
                    Diak ujDiak = new Diak();
                    string[] darabolt = f.ReadLine().Split(';');
                    ujDiak.Nev = darabolt[0];
                    ujDiak.MatekIrasbeli = int.Parse(darabolt[1]);
                    ujDiak.MatekSzobeli = int.Parse(darabolt[2]);
                    ujDiak.InfoIrasbeli = int.Parse(darabolt[3]);
                    ujDiak.InfoSzobeli = int.Parse(darabolt[4]);
                    diakok.Add(ujDiak);
                }
            }
            else
            {
                Console.WriteLine("Nem létezik a fájl!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
