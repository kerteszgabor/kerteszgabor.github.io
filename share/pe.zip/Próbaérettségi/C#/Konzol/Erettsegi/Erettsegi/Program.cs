﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Erettsegi
{
    class Program
    {
        static void Main(string[] args)
        {
            DiakKezelo diakKezelo = new DiakKezelo();
            diakKezelo.Beolvas();
            diakKezelo.HanyDiakVettReszt();
            diakKezelo.MatekAtlag();
            diakKezelo.TantargybolJelesek();

            Console.ReadLine();
        }
    }

    class Diak //DTO osztály
    {
        public string Nev { get; set; }
        public int MatekIrasbeli { get; set; }
        public int MatekSzobeli { get; set; }
        public int InfoIrasbeli { get; set; }
        public int InfoSzobeli { get; set; }
    }

    class DiakKezelo
    {
        List<Diak> diakok;
        public List<Diak> Diakok
        {
            get { return diakok; }
        }

        public DiakKezelo()
        {
            diakok = new List<Diak>();
        }

        public void Beolvas()
        {
            string file = "diak.txt";
            if (File.Exists(file))
            {
                StreamReader f = new StreamReader(file);
                while (!f.EndOfStream)
                {
                    Diak ujDiak = new Diak();
                    string[] darabolt = f.ReadLine().Split(';');
                    ujDiak.Nev = darabolt[0];
                    ujDiak.MatekIrasbeli = int.Parse(darabolt[1]);
                    ujDiak.MatekSzobeli = int.Parse(darabolt[2]);
                    ujDiak.InfoIrasbeli = int.Parse(darabolt[3]);
                    ujDiak.InfoSzobeli= int.Parse(darabolt[4]);
                    diakok.Add(ujDiak);
                }
            }
            else
            {
                Console.WriteLine("Nem létezik a fájl!");
            }
        }

        public void HanyDiakVettReszt()
        {
            Console.WriteLine($"3.feladat: Diákok száma: {diakok.Count} fő");
        }

        public void MatekAtlag()
        {
            int osszPont = 0;
            foreach (Diak diak in diakok)
            {
                osszPont += diak.MatekIrasbeli;
            }

            double atlag = (double)osszPont / diakok.Count;
            Console.WriteLine($"4.feladat: Az iskola Matematika írásbeli átlaga: {atlag.ToString("#.#")} pont volt.");

           // string atlagLambda = diakok.Average(t => t.MatekIrasbeli).ToString("#.#");
           // Console.WriteLine(atlagLambda);
        }

        public void TantargybolJelesek()
        {
            string beolvasott = "";
            Console.Write("Kérem a tantárgyat! (Matematika vagy Informatika): ");
            beolvasott = Console.ReadLine();
            beolvasott = new string(beolvasott.Where(t => !Char.IsWhiteSpace(t)).ToArray());
            foreach (Diak diak in diakok)
            {
                if (beolvasott == "Matematika")
                {
                    if (diak.MatekIrasbeli >= 80)
                    {
                        Console.WriteLine(diak.Nev);
                    }
                }
                else if (beolvasott == "Informatika")
                {
                    int pont = diak.InfoIrasbeli + diak.InfoSzobeli;
                    if (pont >= 120 && diak.InfoSzobeli >= 4)
                    {
                        Console.WriteLine(diak.Nev);
                    }
                }
                else
                {
                    Console.WriteLine("Hibás adat!");
                }
            }
            //sw.AppendText()
            //vagy konstruktor
        }
    }
}
