-- A feladatok megoldására elkészített SQL parancsokat illessze be a feladat sorszáma után!


-- 1. feladat:


-- 3. feladat:
UPDATE karakter SET szuperhos_nev = "Fekete Özvegy" WHERE karakter.szuperhos_nev = "Black Widow"

-- 4. feladat:
SELECT COUNT(id) as "Filmek száma", AVG(hossz / 60) as "Átlagos órák száma" FROM `film`

-- 5. feladat:
SELECT Substring(megjelenes,1,4) as "Év", COUNT(*) as "Filmek száma" FROM `film` WHERE rendezo LIKE "%Joe Russo%" OR rendezo LIKE "%Jon Watts%" GROUP by 1 ORDER by 2 DESC

-- 6. feladat:
SELECT k.szuperhos_nev FROM karakter k inner JOIN szerepel sz on k.id = sz.karakter_id INNER JOIN film f on sz.film_id = f.id INNER JOIN (SELECT COUNT(szerepel.karakter_id), karakter.szuperhos_nev, karakter.id as "ID" from szerepel INNER join karakter on szerepel.karakter_id = karakter.id group by szerepel.karakter_id limit 1) q WHERE sz.karakter_id = q.ID LIMIT 1

-- 7. feladat:
SELECT f.cim as "cím", f.hossz as "hossz" FROM karakter k inner JOIN szerepel sz on k.id = sz.karakter_id INNER JOIN film f on sz.film_id = f.id
Where f.hossz <= 120 and k.szuperhos_nev LIKE "Thor"
GROUP by 1
