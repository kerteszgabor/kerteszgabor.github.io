
CREATE TABLE `film` (
  `id` INT(11) NOT NULL,
  `cim` VARCHAR(45) DEFAULT NULL,
  `eredeti` VARCHAR(45) DEFAULT NULL,
  `hossz` INT(11) NOT NULL,
  `megjelenes` DATE DEFAULT NULL,
  `rendezo` VARCHAR(25) DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `karakter` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `nev` VARCHAR(45),
  `szuperhos_nev` VARCHAR(45),
  PRIMARY KEY (`id`)
);
    
 CREATE TABLE IF NOT EXISTS `szerepel` (
  `film_id` INT NOT NULL,
  `karakter_id` INT NOT NULL,
  PRIMARY KEY (`film_id`, `karakter_id`),  
  CONSTRAINT `fk_film_has_szerep_film1` FOREIGN KEY (`film_id`) REFERENCES `film` (`id`),  
  CONSTRAINT `fk_film_has_szerep_szerep1` FOREIGN KEY (`karakter_id`) REFERENCES `karakter` (`id`)
);

INSERT INTO `film` (`id`, `cim`, `eredeti`, `hossz`, `megjelenes`, `rendezo`) VALUES
(1, 'A Vasember', 'Iron Man', 126, '2008-05-02', 'Jon Favreau'),
(2, 'A hihetetlen Hulk', 'The Incredible Hulk', 112, '2008-06-13', 'Louis Leterrier'),
(3, 'Vasember 2', 'Iron Man 2', 124, '2010-05-07', 'Jon Favreau'),
(4, 'Thor', 'Thor', 115, '2011-05-06', 'Kenneth Branagh'),
(5, 'Amerika kapitány: Az első bosszúálló', 'Captain America: The First Avenger', 124, '2011-07-22', 'Joe Johnston'),
(6, 'Bosszúállók', 'Marvel\'s The Avengers', 143, '2012-05-04', 'Joss Whedon'),
(7, 'Vasember 3', 'Iron Man 3', 130, '2013-05-02', 'Shane Black'),
(8, 'Thor: Sötét világ', 'Thor: The Dark World', 112, '2013-11-08', 'Alan Taylor'),
(9, 'Amerika kapitány: A tél katonája', 'Captain America: The Winter Soldier', 136, '2014-04-04', 'Anthony and Joe Russo'),
(10, 'A galaxis őrzői', 'Guardians of the Galaxy', 121, '2014-08-01', 'James Gunn'),
(11, 'Bosszúállók: Ultron kora', 'Avengers: Age of Ultron', 136, '2015-05-01', 'Joss Whedon'),
(12, 'A Hangya', 'Ant-Man', 117, '2015-07-17', 'Peyton Reed'),
(13, 'Amerika kapitány: Polgárháború', 'Captain America: Civil War', 147, '2016-05-06', 'Anthony and Joe Russo'),
(14, 'Doctor Strange', 'Doctor Strange', 115, '2016-11-04', 'Scott Derrickson'),
(15, 'A galaxis őrzői vol. 2.', 'Guardians of the Galaxy Vol. 2', 136, '2017-05-05', 'James Gunn'),
(16, 'Pókember: Hazatérés', 'Spider-Man: Homecoming', 133, '2017-07-07', 'Jon Watts'),
(17, 'Thor: Ragnarök', 'Thor: Ragnarok', 132, '2017-11-03', 'Taika Waititi'),
(18, 'Fekete Párduc', 'Black Panther', 134, '2018-02-16', 'Ryan Coogler'),
(19, 'Bosszúállók: Végtelen háború', 'Avengers: Infinity War', 149, '2018-04-27', 'Anthony and Joe Russo'),
(20, 'A Hangya és a Darázs', 'Ant-Man and the Wasp', 118, '2018-07-06', 'Peyton Reed'),
(21, 'Marvel Kapitány', 'Captain Marvel', 123, '2019-03-08', 'Anna Boden and Ryan Fleck'),
(22, 'Bosszúállók: Végjáték', 'Avengers: Endgame', 181, '2019-04-26', 'Anthony and Joe Russo'),
(23, 'Pókember: Idegenben', 'Spider-Man: Far From Home', 129, '2019-07-02', 'Jon Watts');

INSERT INTO `karakter` (`id`, `nev`, `szuperhos_nev`) VALUES
(1, 'Tony Stark', 'Vasember'),
(2, NULL, 'Thor'),
(3, 'Bruce Banner', 'Hulk'),
(4, 'Steve Rogers', 'Amerika Kapitány'),
(5, 'Natasha Romanoff', 'Black Widow'),
(6, 'James Rhodes', 'Hadigép'),
(7, 'Peter Parker', 'Pókember'),
(8, "T'Challa", 'Fekete párduc'),
(9, NULL, 'Gamora'),
(10, NULL, 'Nebula'),
(11, NULL, 'Loki'),
(12, NULL, 'Vízió'),
(13, 'Wanda Maximoff', 'Skarlát Boszorkány'),
(14, 'Sam Wilson', 'Falcon');

INSERT INTO `szerepel` (`film_id`, `karakter_id`) VALUES
(1, 1),
(1, 6),
(2, 1),
(2, 3),
(3, 1),
(3, 6),
(3, 5),
(4, 2),
(4, 11),
(5, 4),
(6, 1),
(6, 4),
(6, 3),
(6, 2),
(6, 5),
(6, 11),
(7, 1),
(7, 6),
(8, 2),
(8, 11),
(8, 4),
(9, 4),
(9, 5),
(10, 9),
(10, 10),
(11, 1),
(11, 2),
(11, 3),
(11, 4),
(11, 5),
(11, 6),
(11, 13),
(11, 12);


