﻿namespace ismetloDogaKerteszMegoldas
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.gomb_eredmeny = new System.Windows.Forms.Label();
            this.tetra_eredmeny = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tetra_el = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.label_terfogatok_aranya = new System.Windows.Forms.Label();
            this.label_Valami = new System.Windows.Forms.Label();
            this.label_aranyszam = new System.Windows.Forms.Label();
            this.label_bvlami = new System.Windows.Forms.Label();
            this.sipalya_group = new System.Windows.Forms.GroupBox();
            this.sipalya_text = new System.Windows.Forms.TextBox();
            this.sipalya_btn = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Nszam_textbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.visszaszamolt_listbox = new System.Windows.Forms.ListBox();
            this.min_textbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.max_textbox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.rnd_listbox = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tetra_el)).BeginInit();
            this.sipalya_group.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label_aranyszam);
            this.groupBox1.Controls.Add(this.label_bvlami);
            this.groupBox1.Controls.Add(this.label_terfogatok_aranya);
            this.groupBox1.Controls.Add(this.label_Valami);
            this.groupBox1.Controls.Add(this.gomb_eredmeny);
            this.groupBox1.Controls.Add(this.tetra_eredmeny);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.tetra_el);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(27, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(230, 207);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Tetraéder";
            // 
            // gomb_eredmeny
            // 
            this.gomb_eredmeny.AutoSize = true;
            this.gomb_eredmeny.Location = new System.Drawing.Point(158, 98);
            this.gomb_eredmeny.Name = "gomb_eredmeny";
            this.gomb_eredmeny.Size = new System.Drawing.Size(0, 13);
            this.gomb_eredmeny.TabIndex = 6;
            // 
            // tetra_eredmeny
            // 
            this.tetra_eredmeny.AutoSize = true;
            this.tetra_eredmeny.Location = new System.Drawing.Point(158, 66);
            this.tetra_eredmeny.Name = "tetra_eredmeny";
            this.tetra_eredmeny.Size = new System.Drawing.Size(0, 13);
            this.tetra_eredmeny.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 98);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Köré írt gömb térfogata:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Tetraéder térfogata:";
            // 
            // tetra_el
            // 
            this.tetra_el.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tetra_el.Location = new System.Drawing.Point(95, 19);
            this.tetra_el.Name = "tetra_el";
            this.tetra_el.Size = new System.Drawing.Size(99, 20);
            this.tetra_el.TabIndex = 2;
            this.tetra_el.ValueChanged += new System.EventHandler(this.tetra_el_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Él hossza";
            // 
            // label_terfogatok_aranya
            // 
            this.label_terfogatok_aranya.AutoSize = true;
            this.label_terfogatok_aranya.Location = new System.Drawing.Point(158, 133);
            this.label_terfogatok_aranya.Name = "label_terfogatok_aranya";
            this.label_terfogatok_aranya.Size = new System.Drawing.Size(0, 13);
            this.label_terfogatok_aranya.TabIndex = 8;
            // 
            // label_Valami
            // 
            this.label_Valami.AutoSize = true;
            this.label_Valami.Location = new System.Drawing.Point(20, 133);
            this.label_Valami.Name = "label_Valami";
            this.label_Valami.Size = new System.Drawing.Size(97, 13);
            this.label_Valami.TabIndex = 7;
            this.label_Valami.Text = "Térfogatok aránya:";
            // 
            // label_aranyszam
            // 
            this.label_aranyszam.AutoSize = true;
            this.label_aranyszam.Location = new System.Drawing.Point(158, 167);
            this.label_aranyszam.Name = "label_aranyszam";
            this.label_aranyszam.Size = new System.Drawing.Size(0, 13);
            this.label_aranyszam.TabIndex = 10;
            // 
            // label_bvlami
            // 
            this.label_bvlami.AutoSize = true;
            this.label_bvlami.Location = new System.Drawing.Point(20, 167);
            this.label_bvlami.Name = "label_bvlami";
            this.label_bvlami.Size = new System.Drawing.Size(98, 13);
            this.label_bvlami.TabIndex = 9;
            this.label_bvlami.Text = "Állandó arányszám:";
            // 
            // sipalya_group
            // 
            this.sipalya_group.Controls.Add(this.sipalya_btn);
            this.sipalya_group.Controls.Add(this.sipalya_text);
            this.sipalya_group.Location = new System.Drawing.Point(57, 241);
            this.sipalya_group.Name = "sipalya_group";
            this.sipalya_group.Size = new System.Drawing.Size(200, 184);
            this.sipalya_group.TabIndex = 2;
            this.sipalya_group.TabStop = false;
            this.sipalya_group.Text = "Sípályák";
            // 
            // sipalya_text
            // 
            this.sipalya_text.Location = new System.Drawing.Point(49, 32);
            this.sipalya_text.Name = "sipalya_text";
            this.sipalya_text.Size = new System.Drawing.Size(100, 20);
            this.sipalya_text.TabIndex = 0;
            // 
            // sipalya_btn
            // 
            this.sipalya_btn.Location = new System.Drawing.Point(34, 58);
            this.sipalya_btn.Name = "sipalya_btn";
            this.sipalya_btn.Size = new System.Drawing.Size(135, 23);
            this.sipalya_btn.TabIndex = 1;
            this.sipalya_btn.Text = "Sípálya nehézsége";
            this.sipalya_btn.UseVisualStyleBackColor = true;
            this.sipalya_btn.Click += new System.EventHandler(this.sipalya_btn_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rnd_listbox);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.max_textbox);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.min_textbox);
            this.groupBox2.Controls.Add(this.visszaszamolt_listbox);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.Nszam_textbox);
            this.groupBox2.Location = new System.Drawing.Point(314, 33);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(300, 325);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Számok";
            // 
            // Nszam_textbox
            // 
            this.Nszam_textbox.Location = new System.Drawing.Point(20, 38);
            this.Nszam_textbox.Name = "Nszam_textbox";
            this.Nszam_textbox.Size = new System.Drawing.Size(107, 20);
            this.Nszam_textbox.TabIndex = 2;
            this.Nszam_textbox.TextChanged += new System.EventHandler(this.Nszam_textbox_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(142, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Szám amitől visszaszámolok:";
            // 
            // visszaszamolt_listbox
            // 
            this.visszaszamolt_listbox.FormattingEnabled = true;
            this.visszaszamolt_listbox.Location = new System.Drawing.Point(20, 64);
            this.visszaszamolt_listbox.Name = "visszaszamolt_listbox";
            this.visszaszamolt_listbox.Size = new System.Drawing.Size(107, 225);
            this.visszaszamolt_listbox.TabIndex = 5;
            this.visszaszamolt_listbox.Visible = false;
            // 
            // min_textbox
            // 
            this.min_textbox.Location = new System.Drawing.Point(217, 38);
            this.min_textbox.Name = "min_textbox";
            this.min_textbox.Size = new System.Drawing.Size(55, 20);
            this.min_textbox.TabIndex = 6;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(187, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Véletlenszám:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(154, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Alsó határ:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(149, 80);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(62, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "Felső határ:";
            // 
            // max_textbox
            // 
            this.max_textbox.Location = new System.Drawing.Point(217, 77);
            this.max_textbox.Name = "max_textbox";
            this.max_textbox.Size = new System.Drawing.Size(55, 20);
            this.max_textbox.TabIndex = 10;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(152, 107);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(142, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "Kérem a random számokat";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rnd_listbox
            // 
            this.rnd_listbox.FormattingEnabled = true;
            this.rnd_listbox.Location = new System.Drawing.Point(152, 142);
            this.rnd_listbox.Name = "rnd_listbox";
            this.rnd_listbox.Size = new System.Drawing.Size(142, 147);
            this.rnd_listbox.TabIndex = 12;
            this.rnd_listbox.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(840, 450);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.sipalya_group);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tetra_el)).EndInit();
            this.sipalya_group.ResumeLayout(false);
            this.sipalya_group.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown tetra_el;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label gomb_eredmeny;
        private System.Windows.Forms.Label tetra_eredmeny;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label_aranyszam;
        private System.Windows.Forms.Label label_bvlami;
        private System.Windows.Forms.Label label_terfogatok_aranya;
        private System.Windows.Forms.Label label_Valami;
        private System.Windows.Forms.GroupBox sipalya_group;
        private System.Windows.Forms.Button sipalya_btn;
        private System.Windows.Forms.TextBox sipalya_text;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Nszam_textbox;
        private System.Windows.Forms.ListBox visszaszamolt_listbox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox max_textbox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox min_textbox;
        private System.Windows.Forms.ListBox rnd_listbox;
    }
}

