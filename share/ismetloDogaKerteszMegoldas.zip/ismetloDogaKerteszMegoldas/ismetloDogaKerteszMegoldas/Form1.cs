﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ismetloDogaKerteszMegoldas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Első röpdolgozat pótlása - MEGOLDÁSOK 
        // Kertész Gábor 2020.11.18

        // Tetraéder
        private void tetra_el_ValueChanged(object sender, EventArgs e)
        {
            double a = Double.Parse(tetra_el.Value.ToString());
            double V_tetra = ((double)1 / 12) * Math.Pow(a, 3) * Math.Sqrt(2);
            double R = (a / 4) * Math.Sqrt(6);
            double V_gomb = ((double)4 / 3) * Math.Pow(R, 3) * Math.PI;

            tetra_eredmeny.Text = V_tetra.ToString("#.###");
            gomb_eredmeny.Text = V_gomb.ToString("#.###");

            double terfogatok_hanyadosa = (double)V_tetra / V_gomb;
            double aranyszam = ((double)2 / (9 * Math.PI)) * Math.Sqrt(3);

            label_terfogatok_aranya.Text = terfogatok_hanyadosa.ToString("#.######");
            label_aranyszam.Text = aranyszam.ToString("#.######");
        }

        // Sípálya
        private void sipalya_btn_Click(object sender, EventArgs e)
        {
            //3-as feladat ugyanígy oldható meg
            try
            {
                int sipalyaMeredekseg = int.Parse(sipalya_text.Text);
                if (sipalyaMeredekseg >= 0 && sipalyaMeredekseg < 13)
                {
                    sipalya_group.BackColor = Color.AliceBlue;
                    sipalya_group.ForeColor = Color.Black;      // szövegek színét állítom, hogy látszódjanak
                }
                else if (sipalyaMeredekseg < 21)
                {
                    sipalya_group.BackColor = Color.PaleVioletRed;
                    sipalya_group.ForeColor = Color.Black;           // szövegek színét állítom, hogy látszódjanak
                }
                else
                {
                    sipalya_group.BackColor = Color.Black;
                    sipalya_group.ForeColor = Color.White;           // szövegek színét állítom, hogy látszódjanak
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Számokat írj be!");
                sipalya_text.Text = "";
            }
        }

        // Számtól hármasával visszalépegetés
        private void Nszam_textbox_TextChanged(object sender, EventArgs e)
        {
            visszaszamolt_listbox.Items.Clear();
            if (Nszam_textbox.Text == "")
            {
                visszaszamolt_listbox.Visible = false;
            }
            else
            {
                try
                {
                    int nszam = int.Parse(Nszam_textbox.Text);
                    visszaszamolt_listbox.Visible = true;
                    for (int i = nszam; i > 0; i -= 3)          // while ciklus is jó megoldás
                    {
                        visszaszamolt_listbox.Items.Add(i);
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Hibás adat!");
                    Nszam_textbox.Text = "";
                }
            }
        }

        // VÉLETLENSZÁMOK
        private void button1_Click(object sender, EventArgs e)
        {
            rnd_listbox.Items.Clear();
            string maxSzam = max_textbox.Text;
            string minSzam = min_textbox.Text;
            if (maxSzam!= "" && minSzam != "")
            {
                int max = int.Parse(maxSzam);
                int min = int.Parse(minSzam);
                rnd_listbox.Visible = true;
                Random r = new Random();

                for (int i = 0; i < 10; i++)
                {
                    rnd_listbox.Items.Add($"{i + 1}. véletlenszám:\t{(r.NextDouble() * (max - min) + min).ToString("#.###")}");
                }
            }
            else
            {
                MessageBox.Show("Add meg mind a két számot!");
            }
        }
    }
}
