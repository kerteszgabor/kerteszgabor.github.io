﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hegylancok
{
    class Program
    {
        static void Main(string[] args)
        {
            Hegylanc hegylanc = new Hegylanc();

            hegylanc.DisplayInHexadecimal(true);
            Console.WriteLine();
            hegylanc.DisplayInHexadecimal(false);

            Console.WriteLine($"\nA hegyláncban található hegyek száma: {hegylanc.NumberOfMountains}\n");

            try
            {
                Console.Write($"A leghosszabb hegylánc hossza: {hegylanc.GetLongestRidge}, és");
                Console.WriteLine($" a benne található magasságok átlaga: {hegylanc.GetAverageHeightOfLongestRidge.ToString("#.#")}");
            }
            catch (InvalidOperationException)
            {
                Console.WriteLine("\nNincs hegylánc a vektorban!");
            }

            hegylanc.WriteHeightsToFile();

            Console.ReadLine();
        }
    }
}
