﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hegylancok
{
    class Hegylanc
    {
        byte[] heights;  
        static Random r;
        Dictionary<byte, string> hexNumbers;
        List<byte[]> ridges;
        string[] heightsInHexa;

        public Hegylanc()
        {
            this.heights = new byte[80];
            this.ridges = new List<byte[]>();
            r = new Random();
            int lastIndex = heights.Length;

            for (int i = 0; i < lastIndex; i++)
            {
                heights[i] = (byte)r.Next(1, 16);
                if (heights[i] % 2 == 0)
                {
                    heights[i] = 0;
                }
            }

            heights[0] = heights[1] = heights[2]
                = heights[lastIndex - 1] = heights[lastIndex - 2] = heights[lastIndex - 3]
                = 0;

            HexSetup();
            GetRidges();
        }

        void HexSetup()
        {
            hexNumbers = new Dictionary<byte, string>();

            for (byte i = 0; i < 10; i++)
            {
                hexNumbers.Add(i,i.ToString());
            }

            hexNumbers.Add(10, "A");
            hexNumbers.Add(11, "B");
            hexNumbers.Add(12, "C");
            hexNumbers.Add(13, "D");
            hexNumbers.Add(14, "E");
            hexNumbers.Add(15, "F");
        }

        public void DisplayInHexadecimal(bool displayColored)
        {
            heightsInHexa = new string[heights.Length];

            for (int i = 0; i < heights.Length; i++)
            {
                string jelenlegiSzam;
                hexNumbers.TryGetValue(heights[i], out jelenlegiSzam);
                heightsInHexa[i] = jelenlegiSzam;
                Console.Write(jelenlegiSzam);
            }


            if (displayColored)
            {
                List<int> mountains = GetMountainIndexes();
                foreach (var item in mountains)
                {
                    Console.SetCursorPosition(item, Console.CursorTop);
                    Console.ForegroundColor = (ConsoleColor)r.Next(16);
                    Console.Write(heightsInHexa[item]);
                }
                Console.ResetColor();
            }
            Console.WriteLine();
        }

        public int NumberOfMountains
        {
            get
            {
                return GetMountainIndexes().Count;
            }
        }

        private List<int> GetMountainIndexes()
        {
            List<int> mountains = new List<int>();

            for (int i = 2; i < heights.Length - 3; i++)
            {
                if (heights[i] != 0 && heights[i-1] == 0 && heights[i+1] == 0)
                {
                    mountains.Add(i);
                }
            }

            return mountains;
        }

        private void GetRidges()
        {
            int i = 2;
            while(i < heights.Length - 3)
            {
                if (heights[i] != 0 && heights[i - 1] == 0)
                {
                    int j = i + 1;
                    if (heights[j] != 0) //tehát biztosan láncunk van, nem csak hegy
                    {
                        byte[] currentRidge = new byte[heights.Length];
                        int z = 0;
                        currentRidge[z] = heights[i];
                        while (heights[j] != 0)
                        {
                            currentRidge[++z] = heights[j++];
                        }
                        Array.Resize(ref currentRidge, ++z);    //átméretezzük a tömböt akkorára, amennyi elem ténylegesen van benne
                        ridges.Add(currentRidge);
                        i = j;
                    }
                }
                i++;
            }
        }

        public int GetLongestRidge
        {
            get
            {
                return ridges.Max(t => t.Length);
            }
        }

        public double GetAverageHeightOfLongestRidge
        {
            get
            {
                return ridges
                    .Where(t => t.Length == ridges.Max(z => z.Length))
                    .FirstOrDefault()
                    .Average(t => t);
            }
        }

        public void WriteHeightsToFile()
        {
            StreamWriter r = new StreamWriter("hegylancok.txt");
            if (heightsInHexa == null)
            {
                DisplayInHexadecimal(true); //failsafe, nullreference ellen
            }

            for (int i = 0; i < heightsInHexa.Length; i++)
            {
                r.Write(heightsInHexa[i]);
            }
            r.Close();
        }
    }
}
