﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blackjack_project_2020
{
    class Pakli
    {
        
    }

    class Pikk : Pakli
    {
        
    }

    class Kör : Pakli
    {

    }

    class Treff : Pakli
    {

    }

    class Káró : Pakli
    {

    }
}
