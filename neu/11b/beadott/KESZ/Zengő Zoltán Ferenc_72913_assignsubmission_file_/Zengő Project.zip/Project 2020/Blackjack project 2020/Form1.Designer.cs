﻿namespace Blackjack_project_2020
{
    partial class Blackjack
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Blackjack));
            this.pnl_belepes = new System.Windows.Forms.Panel();
            this.btn_guest = new System.Windows.Forms.Button();
            this.btn_regisztracio = new System.Windows.Forms.Button();
            this.btn_elfelejt = new System.Windows.Forms.Button();
            this.lbl_szoveg3 = new System.Windows.Forms.Label();
            this.lbl_szoveg2 = new System.Windows.Forms.Label();
            this.lbl_szoveg1 = new System.Windows.Forms.Label();
            this.tb_bejelszo = new System.Windows.Forms.TextBox();
            this.tb_befelhasz = new System.Windows.Forms.TextBox();
            this.btn_bezar = new System.Windows.Forms.Button();
            this.btn_belepes = new System.Windows.Forms.Button();
            this.pnl_regisztracio = new System.Windows.Forms.Panel();
            this.lbl_szoveg6 = new System.Windows.Forms.Label();
            this.btn_revissza = new System.Windows.Forms.Button();
            this.btn_regisztralok = new System.Windows.Forms.Button();
            this.cb_nemrob = new System.Windows.Forms.CheckBox();
            this.cb_hozzaad = new System.Windows.Forms.CheckBox();
            this.cb_elfogad = new System.Windows.Forms.CheckBox();
            this.tb_reemail = new System.Windows.Forms.TextBox();
            this.tb_rejelszoujra = new System.Windows.Forms.TextBox();
            this.tb_rejelszo = new System.Windows.Forms.TextBox();
            this.tb_refelhasz = new System.Windows.Forms.TextBox();
            this.lbl_szoveg7 = new System.Windows.Forms.Label();
            this.lbl_szoveg5 = new System.Windows.Forms.Label();
            this.lbl_szoveg4 = new System.Windows.Forms.Label();
            this.pnl_bankkartya = new System.Windows.Forms.Panel();
            this.tb_lejarat = new System.Windows.Forms.TextBox();
            this.tb_cvc = new System.Windows.Forms.TextBox();
            this.tb_kartyaszam = new System.Windows.Forms.TextBox();
            this.btn_hozzaad = new System.Windows.Forms.Button();
            this.lbl_szoveg10 = new System.Windows.Forms.Label();
            this.lbl_szoveg9 = new System.Windows.Forms.Label();
            this.lbl_szoveg8 = new System.Windows.Forms.Label();
            this.pnl_jelszocsere = new System.Windows.Forms.Panel();
            this.tb_csejelszoujra = new System.Windows.Forms.TextBox();
            this.tb_csejelszo = new System.Windows.Forms.TextBox();
            this.tb_emailkod = new System.Windows.Forms.TextBox();
            this.lbl_szoveg13 = new System.Windows.Forms.Label();
            this.lbl_szoveg12 = new System.Windows.Forms.Label();
            this.lbl_szoveg11 = new System.Windows.Forms.Label();
            this.btn_csere = new System.Windows.Forms.Button();
            this.pnl_emailkod = new System.Windows.Forms.Panel();
            this.tb_emailbe = new System.Windows.Forms.TextBox();
            this.btn_kovissza = new System.Windows.Forms.Button();
            this.btn_emailker = new System.Windows.Forms.Button();
            this.lbl_szoveg14 = new System.Windows.Forms.Label();
            this.pnl_zsetonvesz = new System.Windows.Forms.Panel();
            this.btn_100000 = new System.Windows.Forms.Button();
            this.btn_10000 = new System.Windows.Forms.Button();
            this.btn_5000 = new System.Windows.Forms.Button();
            this.btn_1000 = new System.Windows.Forms.Button();
            this.rb_100000 = new System.Windows.Forms.RadioButton();
            this.rb_10000 = new System.Windows.Forms.RadioButton();
            this.rb_5000 = new System.Windows.Forms.RadioButton();
            this.rb_1000 = new System.Windows.Forms.RadioButton();
            this.lbl_zsetonmennyiseg = new System.Windows.Forms.Label();
            this.lbl_egyenlegem = new System.Windows.Forms.Label();
            this.btn_zsevissza = new System.Windows.Forms.Button();
            this.btn_egyenlegtolt = new System.Windows.Forms.Button();
            this.btn_megvesz = new System.Windows.Forms.Button();
            this.pnl_egyenlegtolt = new System.Windows.Forms.Panel();
            this.btn_toltes = new System.Windows.Forms.Button();
            this.btn_egyvissza = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lbl_szoveg17 = new System.Windows.Forms.Label();
            this.pnl_kapkod = new System.Windows.Forms.Panel();
            this.lbl_kapkod = new System.Windows.Forms.Label();
            this.lbl_szoveg16 = new System.Windows.Forms.Label();
            this.pnl_jatek = new System.Windows.Forms.Panel();
            this.lbl_felezert = new System.Windows.Forms.Label();
            this.pnl_lap24 = new System.Windows.Forms.Panel();
            this.lbl_lapert48 = new System.Windows.Forms.Label();
            this.pb_lapszin48 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin47 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert47 = new System.Windows.Forms.Label();
            this.pnl_lap16 = new System.Windows.Forms.Panel();
            this.lbl_lapert32 = new System.Windows.Forms.Label();
            this.pb_lapszin32 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin31 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert31 = new System.Windows.Forms.Label();
            this.pnl_lap8 = new System.Windows.Forms.Panel();
            this.lbl_lapert16 = new System.Windows.Forms.Label();
            this.pb_lapszin16 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin15 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert15 = new System.Windows.Forms.Label();
            this.pnl_lap7 = new System.Windows.Forms.Panel();
            this.lbl_lapert14 = new System.Windows.Forms.Label();
            this.pb_lapszin14 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin13 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert13 = new System.Windows.Forms.Label();
            this.pnl_lap15 = new System.Windows.Forms.Panel();
            this.lbl_lapert30 = new System.Windows.Forms.Label();
            this.pb_lapszin30 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin29 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert29 = new System.Windows.Forms.Label();
            this.pnl_lap23 = new System.Windows.Forms.Panel();
            this.lbl_lapert46 = new System.Windows.Forms.Label();
            this.pb_lapszin46 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin45 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert45 = new System.Windows.Forms.Label();
            this.pnl_lap22 = new System.Windows.Forms.Panel();
            this.lbl_lapert44 = new System.Windows.Forms.Label();
            this.pb_lapszin44 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin43 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert43 = new System.Windows.Forms.Label();
            this.pnl_lap14 = new System.Windows.Forms.Panel();
            this.lbl_lapert28 = new System.Windows.Forms.Label();
            this.pb_lapszin28 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin27 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert27 = new System.Windows.Forms.Label();
            this.pnl_lap6 = new System.Windows.Forms.Panel();
            this.lbl_lapert12 = new System.Windows.Forms.Label();
            this.pb_lapszin12 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin11 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert11 = new System.Windows.Forms.Label();
            this.pnl_lap5 = new System.Windows.Forms.Panel();
            this.lbl_lapert10 = new System.Windows.Forms.Label();
            this.pb_lapszin10 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin9 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert9 = new System.Windows.Forms.Label();
            this.pnl_lap13 = new System.Windows.Forms.Panel();
            this.lbl_lapert26 = new System.Windows.Forms.Label();
            this.pb_lapszin26 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin25 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert25 = new System.Windows.Forms.Label();
            this.pnl_lap21 = new System.Windows.Forms.Panel();
            this.lbl_lapert42 = new System.Windows.Forms.Label();
            this.pb_lapszin42 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin41 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert41 = new System.Windows.Forms.Label();
            this.pnl_lap20 = new System.Windows.Forms.Panel();
            this.lbl_lapert40 = new System.Windows.Forms.Label();
            this.pb_lapszin40 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin39 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert39 = new System.Windows.Forms.Label();
            this.pnl_lap12 = new System.Windows.Forms.Panel();
            this.lbl_lapert24 = new System.Windows.Forms.Label();
            this.pb_lapszin24 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin23 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert23 = new System.Windows.Forms.Label();
            this.pnl_lap4 = new System.Windows.Forms.Panel();
            this.lbl_lapert8 = new System.Windows.Forms.Label();
            this.pb_lapszin8 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin7 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert7 = new System.Windows.Forms.Label();
            this.pnl_lap3 = new System.Windows.Forms.Panel();
            this.lbl_lapert6 = new System.Windows.Forms.Label();
            this.pb_lapszin6 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin5 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert5 = new System.Windows.Forms.Label();
            this.pnl_lap11 = new System.Windows.Forms.Panel();
            this.lbl_lapert22 = new System.Windows.Forms.Label();
            this.pb_lapszin22 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin21 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert21 = new System.Windows.Forms.Label();
            this.pnl_lap19 = new System.Windows.Forms.Panel();
            this.lbl_lapert38 = new System.Windows.Forms.Label();
            this.pb_lapszin38 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin37 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert37 = new System.Windows.Forms.Label();
            this.pnl_lap18 = new System.Windows.Forms.Panel();
            this.lbl_lapert36 = new System.Windows.Forms.Label();
            this.pb_lapszin36 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin35 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert35 = new System.Windows.Forms.Label();
            this.pnl_lap10 = new System.Windows.Forms.Panel();
            this.lbl_lapert20 = new System.Windows.Forms.Label();
            this.pb_lapszin20 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin19 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert19 = new System.Windows.Forms.Label();
            this.pnl_lap2 = new System.Windows.Forms.Panel();
            this.lbl_lapert4 = new System.Windows.Forms.Label();
            this.pb_lapszin4 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin3 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert3 = new System.Windows.Forms.Label();
            this.pnl_lap9 = new System.Windows.Forms.Panel();
            this.lbl_lapert18 = new System.Windows.Forms.Label();
            this.pb_lapszin18 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin17 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert17 = new System.Windows.Forms.Label();
            this.pnl_lap17 = new System.Windows.Forms.Panel();
            this.lbl_lapert34 = new System.Windows.Forms.Label();
            this.pb_lapszin34 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin33 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert33 = new System.Windows.Forms.Label();
            this.pnl_lap1 = new System.Windows.Forms.Panel();
            this.lbl_lapert2 = new System.Windows.Forms.Label();
            this.pb_lapszin2 = new System.Windows.Forms.PictureBox();
            this.pb_lapszin1 = new System.Windows.Forms.PictureBox();
            this.lbl_lapert1 = new System.Windows.Forms.Label();
            this.lbl_playerert = new System.Windows.Forms.Label();
            this.lbl_szoveg28 = new System.Windows.Forms.Label();
            this.lbl_szoveg27 = new System.Windows.Forms.Label();
            this.lbl_szoveg26 = new System.Windows.Forms.Label();
            this.lbl_osztoert = new System.Windows.Forms.Label();
            this.lbl_szoveg25 = new System.Windows.Forms.Label();
            this.lbl_szoveg24 = new System.Windows.Forms.Label();
            this.btn_zsetonvesz = new System.Windows.Forms.Button();
            this.btn_kilepes = new System.Windows.Forms.Button();
            this.btn_betesz = new System.Windows.Forms.Button();
            this.sb_egyeni = new System.Windows.Forms.VScrollBar();
            this.pnl_iranypult = new System.Windows.Forms.Panel();
            this.lbl_szoveg22 = new System.Windows.Forms.Label();
            this.lbl_szoveg23 = new System.Windows.Forms.Label();
            this.lbl_szoveg21 = new System.Windows.Forms.Label();
            this.lbl_szoveg20 = new System.Windows.Forms.Label();
            this.lbl_szoveg19 = new System.Windows.Forms.Label();
            this.btn_segit5 = new System.Windows.Forms.Button();
            this.btn_segit4 = new System.Windows.Forms.Button();
            this.btn_segit3 = new System.Windows.Forms.Button();
            this.btn_segit2 = new System.Windows.Forms.Button();
            this.btn_segit1 = new System.Windows.Forms.Button();
            this.btn_ismetles = new System.Windows.Forms.Button();
            this.btn_egyeni = new System.Windows.Forms.Button();
            this.btn_max = new System.Windows.Forms.Button();
            this.btn_min = new System.Windows.Forms.Button();
            this.btn_11 = new System.Windows.Forms.Button();
            this.btn_1 = new System.Windows.Forms.Button();
            this.lbl_szoveg18 = new System.Windows.Forms.Label();
            this.lbl_zsetonod = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pnl_belepes.SuspendLayout();
            this.pnl_regisztracio.SuspendLayout();
            this.pnl_bankkartya.SuspendLayout();
            this.pnl_jelszocsere.SuspendLayout();
            this.pnl_emailkod.SuspendLayout();
            this.pnl_zsetonvesz.SuspendLayout();
            this.pnl_egyenlegtolt.SuspendLayout();
            this.pnl_kapkod.SuspendLayout();
            this.pnl_jatek.SuspendLayout();
            this.pnl_lap24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin48)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin47)).BeginInit();
            this.pnl_lap16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin31)).BeginInit();
            this.pnl_lap8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin15)).BeginInit();
            this.pnl_lap7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin13)).BeginInit();
            this.pnl_lap15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin29)).BeginInit();
            this.pnl_lap23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin46)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin45)).BeginInit();
            this.pnl_lap22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin44)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin43)).BeginInit();
            this.pnl_lap14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin28)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin27)).BeginInit();
            this.pnl_lap6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin11)).BeginInit();
            this.pnl_lap5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin9)).BeginInit();
            this.pnl_lap13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin26)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin25)).BeginInit();
            this.pnl_lap21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin42)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin41)).BeginInit();
            this.pnl_lap20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin40)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin39)).BeginInit();
            this.pnl_lap12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin23)).BeginInit();
            this.pnl_lap4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin7)).BeginInit();
            this.pnl_lap3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin5)).BeginInit();
            this.pnl_lap11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin21)).BeginInit();
            this.pnl_lap19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin37)).BeginInit();
            this.pnl_lap18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin36)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin35)).BeginInit();
            this.pnl_lap10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin19)).BeginInit();
            this.pnl_lap2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin3)).BeginInit();
            this.pnl_lap9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin17)).BeginInit();
            this.pnl_lap17.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin34)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin33)).BeginInit();
            this.pnl_lap1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin1)).BeginInit();
            this.pnl_iranypult.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_belepes
            // 
            this.pnl_belepes.BackColor = System.Drawing.Color.Wheat;
            this.pnl_belepes.Controls.Add(this.btn_guest);
            this.pnl_belepes.Controls.Add(this.btn_regisztracio);
            this.pnl_belepes.Controls.Add(this.btn_elfelejt);
            this.pnl_belepes.Controls.Add(this.lbl_szoveg3);
            this.pnl_belepes.Controls.Add(this.lbl_szoveg2);
            this.pnl_belepes.Controls.Add(this.lbl_szoveg1);
            this.pnl_belepes.Controls.Add(this.tb_bejelszo);
            this.pnl_belepes.Controls.Add(this.tb_befelhasz);
            this.pnl_belepes.Controls.Add(this.btn_bezar);
            this.pnl_belepes.Controls.Add(this.btn_belepes);
            this.pnl_belepes.Location = new System.Drawing.Point(12, 12);
            this.pnl_belepes.Name = "pnl_belepes";
            this.pnl_belepes.Size = new System.Drawing.Size(222, 294);
            this.pnl_belepes.TabIndex = 0;
            // 
            // btn_guest
            // 
            this.btn_guest.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btn_guest.Location = new System.Drawing.Point(106, 130);
            this.btn_guest.Name = "btn_guest";
            this.btn_guest.Size = new System.Drawing.Size(89, 27);
            this.btn_guest.TabIndex = 9;
            this.btn_guest.Text = "Guestként";
            this.btn_guest.UseVisualStyleBackColor = true;
            this.btn_guest.Visible = false;
            this.btn_guest.Click += new System.EventHandler(this.btn_guest_Click);
            // 
            // btn_regisztracio
            // 
            this.btn_regisztracio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btn_regisztracio.Location = new System.Drawing.Point(15, 248);
            this.btn_regisztracio.Name = "btn_regisztracio";
            this.btn_regisztracio.Size = new System.Drawing.Size(116, 35);
            this.btn_regisztracio.TabIndex = 8;
            this.btn_regisztracio.Text = "Regisztrálás";
            this.btn_regisztracio.UseVisualStyleBackColor = true;
            this.btn_regisztracio.Click += new System.EventHandler(this.btn_regisztracio_Click);
            // 
            // btn_elfelejt
            // 
            this.btn_elfelejt.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btn_elfelejt.Location = new System.Drawing.Point(15, 163);
            this.btn_elfelejt.Name = "btn_elfelejt";
            this.btn_elfelejt.Size = new System.Drawing.Size(180, 26);
            this.btn_elfelejt.TabIndex = 7;
            this.btn_elfelejt.Text = "Elfelejtettem a jelszavamat";
            this.btn_elfelejt.UseVisualStyleBackColor = true;
            this.btn_elfelejt.Click += new System.EventHandler(this.btn_elfelejt_Click);
            // 
            // lbl_szoveg3
            // 
            this.lbl_szoveg3.AutoSize = true;
            this.lbl_szoveg3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lbl_szoveg3.Location = new System.Drawing.Point(13, 192);
            this.lbl_szoveg3.Name = "lbl_szoveg3";
            this.lbl_szoveg3.Size = new System.Drawing.Size(118, 32);
            this.lbl_szoveg3.TabIndex = 6;
            this.lbl_szoveg3.Text = "Nem regisztráltál? \r\nRegisztrálj!";
            // 
            // lbl_szoveg2
            // 
            this.lbl_szoveg2.AutoSize = true;
            this.lbl_szoveg2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lbl_szoveg2.Location = new System.Drawing.Point(13, 67);
            this.lbl_szoveg2.Name = "lbl_szoveg2";
            this.lbl_szoveg2.Size = new System.Drawing.Size(50, 16);
            this.lbl_szoveg2.TabIndex = 5;
            this.lbl_szoveg2.Text = "Jelszó:";
            // 
            // lbl_szoveg1
            // 
            this.lbl_szoveg1.AutoSize = true;
            this.lbl_szoveg1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.lbl_szoveg1.Location = new System.Drawing.Point(13, 11);
            this.lbl_szoveg1.Name = "lbl_szoveg1";
            this.lbl_szoveg1.Size = new System.Drawing.Size(106, 16);
            this.lbl_szoveg1.TabIndex = 4;
            this.lbl_szoveg1.Text = "Felhasználónév:";
            // 
            // tb_bejelszo
            // 
            this.tb_bejelszo.BackColor = System.Drawing.Color.White;
            this.tb_bejelszo.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tb_bejelszo.Location = new System.Drawing.Point(15, 89);
            this.tb_bejelszo.Name = "tb_bejelszo";
            this.tb_bejelszo.Size = new System.Drawing.Size(156, 21);
            this.tb_bejelszo.TabIndex = 3;
            // 
            // tb_befelhasz
            // 
            this.tb_befelhasz.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.tb_befelhasz.Location = new System.Drawing.Point(15, 30);
            this.tb_befelhasz.Name = "tb_befelhasz";
            this.tb_befelhasz.Size = new System.Drawing.Size(156, 21);
            this.tb_befelhasz.TabIndex = 2;
            this.tb_befelhasz.Click += new System.EventHandler(this.tb_befelhasz_Click);
            // 
            // btn_bezar
            // 
            this.btn_bezar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btn_bezar.Location = new System.Drawing.Point(188, 6);
            this.btn_bezar.Name = "btn_bezar";
            this.btn_bezar.Size = new System.Drawing.Size(22, 24);
            this.btn_bezar.TabIndex = 1;
            this.btn_bezar.Text = "X";
            this.btn_bezar.UseVisualStyleBackColor = true;
            // 
            // btn_belepes
            // 
            this.btn_belepes.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.btn_belepes.Location = new System.Drawing.Point(15, 130);
            this.btn_belepes.Name = "btn_belepes";
            this.btn_belepes.Size = new System.Drawing.Size(85, 27);
            this.btn_belepes.TabIndex = 0;
            this.btn_belepes.Text = "Belépés";
            this.btn_belepes.UseVisualStyleBackColor = true;
            this.btn_belepes.Click += new System.EventHandler(this.btn_belepes_Click);
            // 
            // pnl_regisztracio
            // 
            this.pnl_regisztracio.BackColor = System.Drawing.Color.Wheat;
            this.pnl_regisztracio.Controls.Add(this.lbl_szoveg6);
            this.pnl_regisztracio.Controls.Add(this.btn_revissza);
            this.pnl_regisztracio.Controls.Add(this.btn_regisztralok);
            this.pnl_regisztracio.Controls.Add(this.cb_nemrob);
            this.pnl_regisztracio.Controls.Add(this.cb_hozzaad);
            this.pnl_regisztracio.Controls.Add(this.cb_elfogad);
            this.pnl_regisztracio.Controls.Add(this.tb_reemail);
            this.pnl_regisztracio.Controls.Add(this.tb_rejelszoujra);
            this.pnl_regisztracio.Controls.Add(this.tb_rejelszo);
            this.pnl_regisztracio.Controls.Add(this.tb_refelhasz);
            this.pnl_regisztracio.Controls.Add(this.lbl_szoveg7);
            this.pnl_regisztracio.Controls.Add(this.lbl_szoveg5);
            this.pnl_regisztracio.Controls.Add(this.lbl_szoveg4);
            this.pnl_regisztracio.Location = new System.Drawing.Point(239, 12);
            this.pnl_regisztracio.Name = "pnl_regisztracio";
            this.pnl_regisztracio.Size = new System.Drawing.Size(276, 472);
            this.pnl_regisztracio.TabIndex = 1;
            this.pnl_regisztracio.Visible = false;
            // 
            // lbl_szoveg6
            // 
            this.lbl_szoveg6.AutoSize = true;
            this.lbl_szoveg6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_szoveg6.Location = new System.Drawing.Point(14, 144);
            this.lbl_szoveg6.Name = "lbl_szoveg6";
            this.lbl_szoveg6.Size = new System.Drawing.Size(84, 18);
            this.lbl_szoveg6.TabIndex = 13;
            this.lbl_szoveg6.Text = "Jelszó újra:";
            // 
            // btn_revissza
            // 
            this.btn_revissza.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_revissza.Location = new System.Drawing.Point(164, 421);
            this.btn_revissza.Name = "btn_revissza";
            this.btn_revissza.Size = new System.Drawing.Size(75, 34);
            this.btn_revissza.TabIndex = 12;
            this.btn_revissza.Text = "Vissza";
            this.btn_revissza.UseVisualStyleBackColor = true;
            this.btn_revissza.Click += new System.EventHandler(this.btn_revissza_Click);
            // 
            // btn_regisztralok
            // 
            this.btn_regisztralok.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_regisztralok.Location = new System.Drawing.Point(17, 421);
            this.btn_regisztralok.Name = "btn_regisztralok";
            this.btn_regisztralok.Size = new System.Drawing.Size(100, 34);
            this.btn_regisztralok.TabIndex = 11;
            this.btn_regisztralok.Text = "Regisztálok";
            this.btn_regisztralok.UseVisualStyleBackColor = true;
            this.btn_regisztralok.Click += new System.EventHandler(this.btn_regisztralok_Click);
            // 
            // cb_nemrob
            // 
            this.cb_nemrob.AutoSize = true;
            this.cb_nemrob.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.cb_nemrob.Location = new System.Drawing.Point(17, 380);
            this.cb_nemrob.Name = "cb_nemrob";
            this.cb_nemrob.Size = new System.Drawing.Size(149, 22);
            this.cb_nemrob.TabIndex = 10;
            this.cb_nemrob.Text = "Nem vagyok robot";
            this.cb_nemrob.UseVisualStyleBackColor = true;
            // 
            // cb_hozzaad
            // 
            this.cb_hozzaad.AutoSize = true;
            this.cb_hozzaad.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.cb_hozzaad.Location = new System.Drawing.Point(17, 338);
            this.cb_hozzaad.Name = "cb_hozzaad";
            this.cb_hozzaad.Size = new System.Drawing.Size(222, 22);
            this.cb_hozzaad.TabIndex = 9;
            this.cb_hozzaad.Text = "Hozzáadom a bankkártyámat";
            this.cb_hozzaad.UseVisualStyleBackColor = true;
            this.cb_hozzaad.CheckedChanged += new System.EventHandler(this.cb_hozzaad_CheckedChanged);
            // 
            // cb_elfogad
            // 
            this.cb_elfogad.AutoSize = true;
            this.cb_elfogad.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.cb_elfogad.Location = new System.Drawing.Point(17, 280);
            this.cb_elfogad.Name = "cb_elfogad";
            this.cb_elfogad.Size = new System.Drawing.Size(183, 40);
            this.cb_elfogad.TabIndex = 8;
            this.cb_elfogad.Text = "Elfogadom az \r\nadatvédelmi feltételeket.";
            this.cb_elfogad.UseVisualStyleBackColor = true;
            // 
            // tb_reemail
            // 
            this.tb_reemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.tb_reemail.Location = new System.Drawing.Point(17, 227);
            this.tb_reemail.Name = "tb_reemail";
            this.tb_reemail.Size = new System.Drawing.Size(149, 24);
            this.tb_reemail.TabIndex = 7;
            // 
            // tb_rejelszoujra
            // 
            this.tb_rejelszoujra.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.tb_rejelszoujra.Location = new System.Drawing.Point(17, 165);
            this.tb_rejelszoujra.Name = "tb_rejelszoujra";
            this.tb_rejelszoujra.Size = new System.Drawing.Size(149, 24);
            this.tb_rejelszoujra.TabIndex = 6;
            // 
            // tb_rejelszo
            // 
            this.tb_rejelszo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.tb_rejelszo.Location = new System.Drawing.Point(17, 99);
            this.tb_rejelszo.Name = "tb_rejelszo";
            this.tb_rejelszo.Size = new System.Drawing.Size(149, 24);
            this.tb_rejelszo.TabIndex = 5;
            // 
            // tb_refelhasz
            // 
            this.tb_refelhasz.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.tb_refelhasz.Location = new System.Drawing.Point(17, 39);
            this.tb_refelhasz.Name = "tb_refelhasz";
            this.tb_refelhasz.Size = new System.Drawing.Size(149, 24);
            this.tb_refelhasz.TabIndex = 4;
            // 
            // lbl_szoveg7
            // 
            this.lbl_szoveg7.AutoSize = true;
            this.lbl_szoveg7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_szoveg7.Location = new System.Drawing.Point(14, 206);
            this.lbl_szoveg7.Name = "lbl_szoveg7";
            this.lbl_szoveg7.Size = new System.Drawing.Size(82, 18);
            this.lbl_szoveg7.TabIndex = 3;
            this.lbl_szoveg7.Text = "E-mail cím:";
            // 
            // lbl_szoveg5
            // 
            this.lbl_szoveg5.AutoSize = true;
            this.lbl_szoveg5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_szoveg5.Location = new System.Drawing.Point(14, 78);
            this.lbl_szoveg5.Name = "lbl_szoveg5";
            this.lbl_szoveg5.Size = new System.Drawing.Size(56, 18);
            this.lbl_szoveg5.TabIndex = 1;
            this.lbl_szoveg5.Text = "Jelszó:";
            // 
            // lbl_szoveg4
            // 
            this.lbl_szoveg4.AutoSize = true;
            this.lbl_szoveg4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_szoveg4.Location = new System.Drawing.Point(14, 18);
            this.lbl_szoveg4.Name = "lbl_szoveg4";
            this.lbl_szoveg4.Size = new System.Drawing.Size(115, 18);
            this.lbl_szoveg4.TabIndex = 0;
            this.lbl_szoveg4.Text = "Felhasználónév:";
            // 
            // pnl_bankkartya
            // 
            this.pnl_bankkartya.BackColor = System.Drawing.Color.Wheat;
            this.pnl_bankkartya.Controls.Add(this.tb_lejarat);
            this.pnl_bankkartya.Controls.Add(this.tb_cvc);
            this.pnl_bankkartya.Controls.Add(this.tb_kartyaszam);
            this.pnl_bankkartya.Controls.Add(this.btn_hozzaad);
            this.pnl_bankkartya.Controls.Add(this.lbl_szoveg10);
            this.pnl_bankkartya.Controls.Add(this.lbl_szoveg9);
            this.pnl_bankkartya.Controls.Add(this.lbl_szoveg8);
            this.pnl_bankkartya.Location = new System.Drawing.Point(521, 12);
            this.pnl_bankkartya.Name = "pnl_bankkartya";
            this.pnl_bankkartya.Size = new System.Drawing.Size(228, 283);
            this.pnl_bankkartya.TabIndex = 2;
            this.pnl_bankkartya.Visible = false;
            // 
            // tb_lejarat
            // 
            this.tb_lejarat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.tb_lejarat.Location = new System.Drawing.Point(15, 111);
            this.tb_lejarat.Name = "tb_lejarat";
            this.tb_lejarat.Size = new System.Drawing.Size(100, 24);
            this.tb_lejarat.TabIndex = 7;
            this.tb_lejarat.Text = "00/00";
            // 
            // tb_cvc
            // 
            this.tb_cvc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.tb_cvc.Location = new System.Drawing.Point(15, 182);
            this.tb_cvc.Name = "tb_cvc";
            this.tb_cvc.Size = new System.Drawing.Size(100, 24);
            this.tb_cvc.TabIndex = 6;
            this.tb_cvc.Text = "000";
            // 
            // tb_kartyaszam
            // 
            this.tb_kartyaszam.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.tb_kartyaszam.Location = new System.Drawing.Point(15, 38);
            this.tb_kartyaszam.Name = "tb_kartyaszam";
            this.tb_kartyaszam.Size = new System.Drawing.Size(151, 24);
            this.tb_kartyaszam.TabIndex = 5;
            this.tb_kartyaszam.Text = "0000-0000-0000-0000";
            // 
            // btn_hozzaad
            // 
            this.btn_hozzaad.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_hozzaad.Location = new System.Drawing.Point(15, 232);
            this.btn_hozzaad.Name = "btn_hozzaad";
            this.btn_hozzaad.Size = new System.Drawing.Size(100, 35);
            this.btn_hozzaad.TabIndex = 3;
            this.btn_hozzaad.Text = "Hozzáadom";
            this.btn_hozzaad.UseVisualStyleBackColor = true;
            this.btn_hozzaad.Click += new System.EventHandler(this.btn_hozzaad_Click);
            // 
            // lbl_szoveg10
            // 
            this.lbl_szoveg10.AutoSize = true;
            this.lbl_szoveg10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_szoveg10.Location = new System.Drawing.Point(12, 161);
            this.lbl_szoveg10.Name = "lbl_szoveg10";
            this.lbl_szoveg10.Size = new System.Drawing.Size(110, 18);
            this.lbl_szoveg10.TabIndex = 2;
            this.lbl_szoveg10.Text = "Biztonsági kód:";
            // 
            // lbl_szoveg9
            // 
            this.lbl_szoveg9.AutoSize = true;
            this.lbl_szoveg9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_szoveg9.Location = new System.Drawing.Point(12, 90);
            this.lbl_szoveg9.Name = "lbl_szoveg9";
            this.lbl_szoveg9.Size = new System.Drawing.Size(104, 18);
            this.lbl_szoveg9.TabIndex = 1;
            this.lbl_szoveg9.Text = "Lejárati dátum:";
            // 
            // lbl_szoveg8
            // 
            this.lbl_szoveg8.AutoSize = true;
            this.lbl_szoveg8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_szoveg8.Location = new System.Drawing.Point(12, 17);
            this.lbl_szoveg8.Name = "lbl_szoveg8";
            this.lbl_szoveg8.Size = new System.Drawing.Size(91, 18);
            this.lbl_szoveg8.TabIndex = 0;
            this.lbl_szoveg8.Text = "Kártyaszám:";
            // 
            // pnl_jelszocsere
            // 
            this.pnl_jelszocsere.BackColor = System.Drawing.Color.Wheat;
            this.pnl_jelszocsere.Controls.Add(this.tb_csejelszoujra);
            this.pnl_jelszocsere.Controls.Add(this.tb_csejelszo);
            this.pnl_jelszocsere.Controls.Add(this.tb_emailkod);
            this.pnl_jelszocsere.Controls.Add(this.lbl_szoveg13);
            this.pnl_jelszocsere.Controls.Add(this.lbl_szoveg12);
            this.pnl_jelszocsere.Controls.Add(this.lbl_szoveg11);
            this.pnl_jelszocsere.Controls.Add(this.btn_csere);
            this.pnl_jelszocsere.Location = new System.Drawing.Point(755, 12);
            this.pnl_jelszocsere.Name = "pnl_jelszocsere";
            this.pnl_jelszocsere.Size = new System.Drawing.Size(192, 254);
            this.pnl_jelszocsere.TabIndex = 3;
            this.pnl_jelszocsere.Visible = false;
            // 
            // tb_csejelszoujra
            // 
            this.tb_csejelszoujra.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.tb_csejelszoujra.Location = new System.Drawing.Point(18, 151);
            this.tb_csejelszoujra.Name = "tb_csejelszoujra";
            this.tb_csejelszoujra.Size = new System.Drawing.Size(139, 24);
            this.tb_csejelszoujra.TabIndex = 6;
            // 
            // tb_csejelszo
            // 
            this.tb_csejelszo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.tb_csejelszo.Location = new System.Drawing.Point(18, 95);
            this.tb_csejelszo.Name = "tb_csejelszo";
            this.tb_csejelszo.Size = new System.Drawing.Size(139, 24);
            this.tb_csejelszo.TabIndex = 5;
            // 
            // tb_emailkod
            // 
            this.tb_emailkod.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.tb_emailkod.Location = new System.Drawing.Point(18, 39);
            this.tb_emailkod.Name = "tb_emailkod";
            this.tb_emailkod.Size = new System.Drawing.Size(139, 24);
            this.tb_emailkod.TabIndex = 4;
            // 
            // lbl_szoveg13
            // 
            this.lbl_szoveg13.AutoSize = true;
            this.lbl_szoveg13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_szoveg13.Location = new System.Drawing.Point(15, 126);
            this.lbl_szoveg13.Name = "lbl_szoveg13";
            this.lbl_szoveg13.Size = new System.Drawing.Size(84, 18);
            this.lbl_szoveg13.TabIndex = 3;
            this.lbl_szoveg13.Text = "Jelszó újra:";
            // 
            // lbl_szoveg12
            // 
            this.lbl_szoveg12.AutoSize = true;
            this.lbl_szoveg12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_szoveg12.Location = new System.Drawing.Point(15, 70);
            this.lbl_szoveg12.Name = "lbl_szoveg12";
            this.lbl_szoveg12.Size = new System.Drawing.Size(56, 18);
            this.lbl_szoveg12.TabIndex = 2;
            this.lbl_szoveg12.Text = "Jelszó:";
            // 
            // lbl_szoveg11
            // 
            this.lbl_szoveg11.AutoSize = true;
            this.lbl_szoveg11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_szoveg11.Location = new System.Drawing.Point(15, 14);
            this.lbl_szoveg11.Name = "lbl_szoveg11";
            this.lbl_szoveg11.Size = new System.Drawing.Size(152, 18);
            this.lbl_szoveg11.TabIndex = 1;
            this.lbl_szoveg11.Text = "E-mailben kapott kód:";
            // 
            // btn_csere
            // 
            this.btn_csere.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_csere.Location = new System.Drawing.Point(18, 200);
            this.btn_csere.Name = "btn_csere";
            this.btn_csere.Size = new System.Drawing.Size(114, 26);
            this.btn_csere.TabIndex = 0;
            this.btn_csere.Text = "Jelszó csere";
            this.btn_csere.UseVisualStyleBackColor = true;
            this.btn_csere.Click += new System.EventHandler(this.btn_csere_Click);
            // 
            // pnl_emailkod
            // 
            this.pnl_emailkod.BackColor = System.Drawing.Color.Wheat;
            this.pnl_emailkod.Controls.Add(this.tb_emailbe);
            this.pnl_emailkod.Controls.Add(this.btn_kovissza);
            this.pnl_emailkod.Controls.Add(this.btn_emailker);
            this.pnl_emailkod.Controls.Add(this.lbl_szoveg14);
            this.pnl_emailkod.Location = new System.Drawing.Point(521, 303);
            this.pnl_emailkod.Name = "pnl_emailkod";
            this.pnl_emailkod.Size = new System.Drawing.Size(314, 148);
            this.pnl_emailkod.TabIndex = 4;
            this.pnl_emailkod.Visible = false;
            // 
            // tb_emailbe
            // 
            this.tb_emailbe.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.tb_emailbe.Location = new System.Drawing.Point(86, 65);
            this.tb_emailbe.Name = "tb_emailbe";
            this.tb_emailbe.Size = new System.Drawing.Size(139, 24);
            this.tb_emailbe.TabIndex = 3;
            // 
            // btn_kovissza
            // 
            this.btn_kovissza.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_kovissza.Location = new System.Drawing.Point(234, 110);
            this.btn_kovissza.Name = "btn_kovissza";
            this.btn_kovissza.Size = new System.Drawing.Size(75, 26);
            this.btn_kovissza.TabIndex = 2;
            this.btn_kovissza.Text = "Vissza";
            this.btn_kovissza.UseVisualStyleBackColor = true;
            this.btn_kovissza.Click += new System.EventHandler(this.btn_kovissza_Click);
            // 
            // btn_emailker
            // 
            this.btn_emailker.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_emailker.Location = new System.Drawing.Point(6, 110);
            this.btn_emailker.Name = "btn_emailker";
            this.btn_emailker.Size = new System.Drawing.Size(112, 26);
            this.btn_emailker.TabIndex = 1;
            this.btn_emailker.Text = "Email küldése";
            this.btn_emailker.UseVisualStyleBackColor = true;
            this.btn_emailker.Click += new System.EventHandler(this.btn_emailker_Click);
            // 
            // lbl_szoveg14
            // 
            this.lbl_szoveg14.AutoSize = true;
            this.lbl_szoveg14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_szoveg14.Location = new System.Drawing.Point(3, 13);
            this.lbl_szoveg14.Name = "lbl_szoveg14";
            this.lbl_szoveg14.Size = new System.Drawing.Size(306, 18);
            this.lbl_szoveg14.TabIndex = 0;
            this.lbl_szoveg14.Text = "Kérlek írd be az e-mailed vagy a felhasználód!";
            this.lbl_szoveg14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_zsetonvesz
            // 
            this.pnl_zsetonvesz.BackColor = System.Drawing.Color.Wheat;
            this.pnl_zsetonvesz.Controls.Add(this.label2);
            this.pnl_zsetonvesz.Controls.Add(this.btn_100000);
            this.pnl_zsetonvesz.Controls.Add(this.label1);
            this.pnl_zsetonvesz.Controls.Add(this.btn_10000);
            this.pnl_zsetonvesz.Controls.Add(this.btn_5000);
            this.pnl_zsetonvesz.Controls.Add(this.btn_1000);
            this.pnl_zsetonvesz.Controls.Add(this.rb_100000);
            this.pnl_zsetonvesz.Controls.Add(this.rb_10000);
            this.pnl_zsetonvesz.Controls.Add(this.rb_5000);
            this.pnl_zsetonvesz.Controls.Add(this.rb_1000);
            this.pnl_zsetonvesz.Controls.Add(this.lbl_zsetonmennyiseg);
            this.pnl_zsetonvesz.Controls.Add(this.lbl_egyenlegem);
            this.pnl_zsetonvesz.Controls.Add(this.btn_zsevissza);
            this.pnl_zsetonvesz.Controls.Add(this.btn_egyenlegtolt);
            this.pnl_zsetonvesz.Controls.Add(this.btn_megvesz);
            this.pnl_zsetonvesz.Location = new System.Drawing.Point(14, 490);
            this.pnl_zsetonvesz.Name = "pnl_zsetonvesz";
            this.pnl_zsetonvesz.Size = new System.Drawing.Size(778, 306);
            this.pnl_zsetonvesz.TabIndex = 5;
            this.pnl_zsetonvesz.Visible = false;
            // 
            // btn_100000
            // 
            this.btn_100000.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_100000.BackgroundImage")));
            this.btn_100000.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_100000.Location = new System.Drawing.Point(592, 60);
            this.btn_100000.Name = "btn_100000";
            this.btn_100000.Size = new System.Drawing.Size(160, 160);
            this.btn_100000.TabIndex = 3;
            this.btn_100000.UseVisualStyleBackColor = true;
            // 
            // btn_10000
            // 
            this.btn_10000.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_10000.BackgroundImage")));
            this.btn_10000.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_10000.Location = new System.Drawing.Point(399, 60);
            this.btn_10000.Name = "btn_10000";
            this.btn_10000.Size = new System.Drawing.Size(160, 160);
            this.btn_10000.TabIndex = 2;
            this.btn_10000.UseVisualStyleBackColor = true;
            // 
            // btn_5000
            // 
            this.btn_5000.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_5000.BackgroundImage")));
            this.btn_5000.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_5000.Location = new System.Drawing.Point(206, 60);
            this.btn_5000.Name = "btn_5000";
            this.btn_5000.Size = new System.Drawing.Size(160, 160);
            this.btn_5000.TabIndex = 1;
            this.btn_5000.UseVisualStyleBackColor = true;
            // 
            // btn_1000
            // 
            this.btn_1000.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_1000.BackgroundImage")));
            this.btn_1000.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_1000.Location = new System.Drawing.Point(13, 60);
            this.btn_1000.Name = "btn_1000";
            this.btn_1000.Size = new System.Drawing.Size(160, 160);
            this.btn_1000.TabIndex = 0;
            this.btn_1000.UseVisualStyleBackColor = true;
            // 
            // rb_100000
            // 
            this.rb_100000.AutoSize = true;
            this.rb_100000.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rb_100000.Location = new System.Drawing.Point(628, 226);
            this.rb_100000.Name = "rb_100000";
            this.rb_100000.Size = new System.Drawing.Size(83, 22);
            this.rb_100000.TabIndex = 17;
            this.rb_100000.TabStop = true;
            this.rb_100000.Text = "36,000Ft";
            this.rb_100000.UseVisualStyleBackColor = true;
            this.rb_100000.CheckedChanged += new System.EventHandler(this.rb_100000_CheckedChanged_1);
            // 
            // rb_10000
            // 
            this.rb_10000.AutoSize = true;
            this.rb_10000.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rb_10000.Location = new System.Drawing.Point(444, 226);
            this.rb_10000.Name = "rb_10000";
            this.rb_10000.Size = new System.Drawing.Size(75, 22);
            this.rb_10000.TabIndex = 16;
            this.rb_10000.TabStop = true;
            this.rb_10000.Text = "8,300Ft";
            this.rb_10000.UseVisualStyleBackColor = true;
            this.rb_10000.CheckedChanged += new System.EventHandler(this.rb_10000_CheckedChanged_1);
            // 
            // rb_5000
            // 
            this.rb_5000.AutoSize = true;
            this.rb_5000.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rb_5000.Location = new System.Drawing.Point(242, 226);
            this.rb_5000.Name = "rb_5000";
            this.rb_5000.Size = new System.Drawing.Size(75, 22);
            this.rb_5000.TabIndex = 15;
            this.rb_5000.TabStop = true;
            this.rb_5000.Text = "4,400Ft";
            this.rb_5000.UseVisualStyleBackColor = true;
            this.rb_5000.CheckedChanged += new System.EventHandler(this.rb_5000_CheckedChanged_1);
            // 
            // rb_1000
            // 
            this.rb_1000.AutoSize = true;
            this.rb_1000.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.rb_1000.Location = new System.Drawing.Point(54, 226);
            this.rb_1000.Name = "rb_1000";
            this.rb_1000.Size = new System.Drawing.Size(63, 22);
            this.rb_1000.TabIndex = 14;
            this.rb_1000.TabStop = true;
            this.rb_1000.Text = "900Ft";
            this.rb_1000.UseVisualStyleBackColor = true;
            this.rb_1000.CheckedChanged += new System.EventHandler(this.rb_1000_CheckedChanged);
            // 
            // lbl_zsetonmennyiseg
            // 
            this.lbl_zsetonmennyiseg.AutoSize = true;
            this.lbl_zsetonmennyiseg.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_zsetonmennyiseg.Location = new System.Drawing.Point(696, 26);
            this.lbl_zsetonmennyiseg.Name = "lbl_zsetonmennyiseg";
            this.lbl_zsetonmennyiseg.Size = new System.Drawing.Size(56, 18);
            this.lbl_zsetonmennyiseg.TabIndex = 9;
            this.lbl_zsetonmennyiseg.Text = "100000";
            // 
            // lbl_egyenlegem
            // 
            this.lbl_egyenlegem.AutoSize = true;
            this.lbl_egyenlegem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_egyenlegem.Location = new System.Drawing.Point(503, 26);
            this.lbl_egyenlegem.Name = "lbl_egyenlegem";
            this.lbl_egyenlegem.Size = new System.Drawing.Size(56, 18);
            this.lbl_egyenlegem.TabIndex = 8;
            this.lbl_egyenlegem.Text = "100000";
            // 
            // btn_zsevissza
            // 
            this.btn_zsevissza.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_zsevissza.Location = new System.Drawing.Point(14, 266);
            this.btn_zsevissza.Name = "btn_zsevissza";
            this.btn_zsevissza.Size = new System.Drawing.Size(94, 29);
            this.btn_zsevissza.TabIndex = 7;
            this.btn_zsevissza.Text = "Vissza";
            this.btn_zsevissza.UseVisualStyleBackColor = true;
            this.btn_zsevissza.Click += new System.EventHandler(this.btn_zsevissza_Click);
            // 
            // btn_egyenlegtolt
            // 
            this.btn_egyenlegtolt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_egyenlegtolt.Location = new System.Drawing.Point(483, 266);
            this.btn_egyenlegtolt.Name = "btn_egyenlegtolt";
            this.btn_egyenlegtolt.Size = new System.Drawing.Size(127, 29);
            this.btn_egyenlegtolt.TabIndex = 5;
            this.btn_egyenlegtolt.Text = "Egyenleg töltés";
            this.btn_egyenlegtolt.UseVisualStyleBackColor = true;
            this.btn_egyenlegtolt.Click += new System.EventHandler(this.btn_egyenlegtolt_Click);
            // 
            // btn_megvesz
            // 
            this.btn_megvesz.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_megvesz.Location = new System.Drawing.Point(651, 266);
            this.btn_megvesz.Name = "btn_megvesz";
            this.btn_megvesz.Size = new System.Drawing.Size(101, 29);
            this.btn_megvesz.TabIndex = 4;
            this.btn_megvesz.Text = "Megveszem";
            this.btn_megvesz.UseVisualStyleBackColor = true;
            this.btn_megvesz.Click += new System.EventHandler(this.btn_megvesz_Click);
            // 
            // pnl_egyenlegtolt
            // 
            this.pnl_egyenlegtolt.BackColor = System.Drawing.Color.Wheat;
            this.pnl_egyenlegtolt.Controls.Add(this.btn_toltes);
            this.pnl_egyenlegtolt.Controls.Add(this.btn_egyvissza);
            this.pnl_egyenlegtolt.Controls.Add(this.textBox1);
            this.pnl_egyenlegtolt.Controls.Add(this.lbl_szoveg17);
            this.pnl_egyenlegtolt.Location = new System.Drawing.Point(12, 312);
            this.pnl_egyenlegtolt.Name = "pnl_egyenlegtolt";
            this.pnl_egyenlegtolt.Size = new System.Drawing.Size(221, 138);
            this.pnl_egyenlegtolt.TabIndex = 6;
            this.pnl_egyenlegtolt.Visible = false;
            // 
            // btn_toltes
            // 
            this.btn_toltes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_toltes.Location = new System.Drawing.Point(135, 97);
            this.btn_toltes.Name = "btn_toltes";
            this.btn_toltes.Size = new System.Drawing.Size(75, 31);
            this.btn_toltes.TabIndex = 3;
            this.btn_toltes.Text = "Feltölt";
            this.btn_toltes.UseVisualStyleBackColor = true;
            this.btn_toltes.Click += new System.EventHandler(this.btn_toltes_Click);
            // 
            // btn_egyvissza
            // 
            this.btn_egyvissza.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_egyvissza.Location = new System.Drawing.Point(13, 97);
            this.btn_egyvissza.Name = "btn_egyvissza";
            this.btn_egyvissza.Size = new System.Drawing.Size(75, 31);
            this.btn_egyvissza.TabIndex = 2;
            this.btn_egyvissza.Text = "Vissza";
            this.btn_egyvissza.UseVisualStyleBackColor = true;
            this.btn_egyvissza.Click += new System.EventHandler(this.btn_egyvissza_Click);
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.textBox1.Location = new System.Drawing.Point(59, 59);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(121, 24);
            this.textBox1.TabIndex = 1;
            // 
            // lbl_szoveg17
            // 
            this.lbl_szoveg17.AutoSize = true;
            this.lbl_szoveg17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_szoveg17.Location = new System.Drawing.Point(10, 12);
            this.lbl_szoveg17.Name = "lbl_szoveg17";
            this.lbl_szoveg17.Size = new System.Drawing.Size(182, 36);
            this.lbl_szoveg17.TabIndex = 0;
            this.lbl_szoveg17.Text = "Kérlek írd be az összeget! \r\nMax:100 ezer";
            // 
            // pnl_kapkod
            // 
            this.pnl_kapkod.BackColor = System.Drawing.Color.Wheat;
            this.pnl_kapkod.Controls.Add(this.lbl_kapkod);
            this.pnl_kapkod.Controls.Add(this.lbl_szoveg16);
            this.pnl_kapkod.Location = new System.Drawing.Point(840, 303);
            this.pnl_kapkod.Name = "pnl_kapkod";
            this.pnl_kapkod.Size = new System.Drawing.Size(192, 88);
            this.pnl_kapkod.TabIndex = 7;
            this.pnl_kapkod.Visible = false;
            // 
            // lbl_kapkod
            // 
            this.lbl_kapkod.AutoSize = true;
            this.lbl_kapkod.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_kapkod.Location = new System.Drawing.Point(67, 43);
            this.lbl_kapkod.Name = "lbl_kapkod";
            this.lbl_kapkod.Size = new System.Drawing.Size(46, 18);
            this.lbl_kapkod.TabIndex = 1;
            this.lbl_kapkod.Text = "label2";
            // 
            // lbl_szoveg16
            // 
            this.lbl_szoveg16.AutoSize = true;
            this.lbl_szoveg16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.lbl_szoveg16.Location = new System.Drawing.Point(13, 12);
            this.lbl_szoveg16.Name = "lbl_szoveg16";
            this.lbl_szoveg16.Size = new System.Drawing.Size(84, 18);
            this.lbl_szoveg16.TabIndex = 0;
            this.lbl_szoveg16.Text = "Kapott kód:";
            // 
            // pnl_jatek
            // 
            this.pnl_jatek.BackColor = System.Drawing.Color.Beige;
            this.pnl_jatek.Controls.Add(this.lbl_felezert);
            this.pnl_jatek.Controls.Add(this.pnl_lap24);
            this.pnl_jatek.Controls.Add(this.pnl_lap16);
            this.pnl_jatek.Controls.Add(this.pnl_lap8);
            this.pnl_jatek.Controls.Add(this.pnl_lap7);
            this.pnl_jatek.Controls.Add(this.pnl_lap15);
            this.pnl_jatek.Controls.Add(this.pnl_lap23);
            this.pnl_jatek.Controls.Add(this.pnl_lap22);
            this.pnl_jatek.Controls.Add(this.pnl_lap14);
            this.pnl_jatek.Controls.Add(this.pnl_lap6);
            this.pnl_jatek.Controls.Add(this.pnl_lap5);
            this.pnl_jatek.Controls.Add(this.pnl_lap13);
            this.pnl_jatek.Controls.Add(this.pnl_lap21);
            this.pnl_jatek.Controls.Add(this.pnl_lap20);
            this.pnl_jatek.Controls.Add(this.pnl_lap12);
            this.pnl_jatek.Controls.Add(this.pnl_lap4);
            this.pnl_jatek.Controls.Add(this.pnl_lap3);
            this.pnl_jatek.Controls.Add(this.pnl_lap11);
            this.pnl_jatek.Controls.Add(this.pnl_lap19);
            this.pnl_jatek.Controls.Add(this.pnl_lap18);
            this.pnl_jatek.Controls.Add(this.pnl_lap10);
            this.pnl_jatek.Controls.Add(this.pnl_lap2);
            this.pnl_jatek.Controls.Add(this.pnl_lap9);
            this.pnl_jatek.Controls.Add(this.pnl_lap17);
            this.pnl_jatek.Controls.Add(this.pnl_lap1);
            this.pnl_jatek.Controls.Add(this.lbl_playerert);
            this.pnl_jatek.Controls.Add(this.lbl_szoveg28);
            this.pnl_jatek.Controls.Add(this.lbl_szoveg27);
            this.pnl_jatek.Controls.Add(this.lbl_szoveg26);
            this.pnl_jatek.Controls.Add(this.lbl_osztoert);
            this.pnl_jatek.Controls.Add(this.lbl_szoveg25);
            this.pnl_jatek.Controls.Add(this.lbl_szoveg24);
            this.pnl_jatek.Controls.Add(this.btn_zsetonvesz);
            this.pnl_jatek.Controls.Add(this.btn_kilepes);
            this.pnl_jatek.Controls.Add(this.btn_betesz);
            this.pnl_jatek.Controls.Add(this.sb_egyeni);
            this.pnl_jatek.Controls.Add(this.pnl_iranypult);
            this.pnl_jatek.Location = new System.Drawing.Point(983, 609);
            this.pnl_jatek.Name = "pnl_jatek";
            this.pnl_jatek.Size = new System.Drawing.Size(1620, 980);
            this.pnl_jatek.TabIndex = 8;
            this.pnl_jatek.Visible = false;
            this.pnl_jatek.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lbl_felezert
            // 
            this.lbl_felezert.AutoSize = true;
            this.lbl_felezert.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbl_felezert.Location = new System.Drawing.Point(5, 272);
            this.lbl_felezert.Name = "lbl_felezert";
            this.lbl_felezert.Size = new System.Drawing.Size(117, 22);
            this.lbl_felezert.TabIndex = 16;
            this.lbl_felezert.Text = "Felezés érték";
            // 
            // pnl_lap24
            // 
            this.pnl_lap24.Controls.Add(this.lbl_lapert48);
            this.pnl_lap24.Controls.Add(this.pb_lapszin48);
            this.pnl_lap24.Controls.Add(this.pb_lapszin47);
            this.pnl_lap24.Controls.Add(this.lbl_lapert47);
            this.pnl_lap24.Location = new System.Drawing.Point(1236, 457);
            this.pnl_lap24.Name = "pnl_lap24";
            this.pnl_lap24.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap24.TabIndex = 15;
            // 
            // lbl_lapert48
            // 
            this.lbl_lapert48.AutoSize = true;
            this.lbl_lapert48.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert48.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert48.Name = "lbl_lapert48";
            this.lbl_lapert48.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert48.TabIndex = 3;
            this.lbl_lapert48.Text = "T";
            // 
            // pb_lapszin48
            // 
            this.pb_lapszin48.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin48.Name = "pb_lapszin48";
            this.pb_lapszin48.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin48.TabIndex = 2;
            this.pb_lapszin48.TabStop = false;
            // 
            // pb_lapszin47
            // 
            this.pb_lapszin47.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin47.Name = "pb_lapszin47";
            this.pb_lapszin47.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin47.TabIndex = 1;
            this.pb_lapszin47.TabStop = false;
            // 
            // lbl_lapert47
            // 
            this.lbl_lapert47.AutoSize = true;
            this.lbl_lapert47.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert47.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert47.Name = "lbl_lapert47";
            this.lbl_lapert47.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert47.TabIndex = 0;
            this.lbl_lapert47.Text = "T";
            this.lbl_lapert47.Click += new System.EventHandler(this.label46_Click);
            // 
            // pnl_lap16
            // 
            this.pnl_lap16.Controls.Add(this.lbl_lapert32);
            this.pnl_lap16.Controls.Add(this.pb_lapszin32);
            this.pnl_lap16.Controls.Add(this.pb_lapszin31);
            this.pnl_lap16.Controls.Add(this.lbl_lapert31);
            this.pnl_lap16.Location = new System.Drawing.Point(1236, 234);
            this.pnl_lap16.Name = "pnl_lap16";
            this.pnl_lap16.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap16.TabIndex = 15;
            // 
            // lbl_lapert32
            // 
            this.lbl_lapert32.AutoSize = true;
            this.lbl_lapert32.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert32.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert32.Name = "lbl_lapert32";
            this.lbl_lapert32.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert32.TabIndex = 3;
            this.lbl_lapert32.Text = "T";
            // 
            // pb_lapszin32
            // 
            this.pb_lapszin32.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin32.Name = "pb_lapszin32";
            this.pb_lapszin32.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin32.TabIndex = 2;
            this.pb_lapszin32.TabStop = false;
            // 
            // pb_lapszin31
            // 
            this.pb_lapszin31.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin31.Name = "pb_lapszin31";
            this.pb_lapszin31.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin31.TabIndex = 1;
            this.pb_lapszin31.TabStop = false;
            // 
            // lbl_lapert31
            // 
            this.lbl_lapert31.AutoSize = true;
            this.lbl_lapert31.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert31.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert31.Name = "lbl_lapert31";
            this.lbl_lapert31.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert31.TabIndex = 0;
            this.lbl_lapert31.Text = "T";
            // 
            // pnl_lap8
            // 
            this.pnl_lap8.Controls.Add(this.lbl_lapert16);
            this.pnl_lap8.Controls.Add(this.pb_lapszin16);
            this.pnl_lap8.Controls.Add(this.pb_lapszin15);
            this.pnl_lap8.Controls.Add(this.lbl_lapert15);
            this.pnl_lap8.Location = new System.Drawing.Point(1236, 11);
            this.pnl_lap8.Name = "pnl_lap8";
            this.pnl_lap8.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap8.TabIndex = 15;
            // 
            // lbl_lapert16
            // 
            this.lbl_lapert16.AutoSize = true;
            this.lbl_lapert16.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert16.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert16.Name = "lbl_lapert16";
            this.lbl_lapert16.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert16.TabIndex = 3;
            this.lbl_lapert16.Text = "T";
            // 
            // pb_lapszin16
            // 
            this.pb_lapszin16.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin16.Name = "pb_lapszin16";
            this.pb_lapszin16.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin16.TabIndex = 2;
            this.pb_lapszin16.TabStop = false;
            // 
            // pb_lapszin15
            // 
            this.pb_lapszin15.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin15.Name = "pb_lapszin15";
            this.pb_lapszin15.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin15.TabIndex = 1;
            this.pb_lapszin15.TabStop = false;
            // 
            // lbl_lapert15
            // 
            this.lbl_lapert15.AutoSize = true;
            this.lbl_lapert15.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert15.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert15.Name = "lbl_lapert15";
            this.lbl_lapert15.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert15.TabIndex = 0;
            this.lbl_lapert15.Text = "T";
            // 
            // pnl_lap7
            // 
            this.pnl_lap7.Controls.Add(this.lbl_lapert14);
            this.pnl_lap7.Controls.Add(this.pb_lapszin14);
            this.pnl_lap7.Controls.Add(this.pb_lapszin13);
            this.pnl_lap7.Controls.Add(this.lbl_lapert13);
            this.pnl_lap7.Location = new System.Drawing.Point(1084, 11);
            this.pnl_lap7.Name = "pnl_lap7";
            this.pnl_lap7.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap7.TabIndex = 15;
            // 
            // lbl_lapert14
            // 
            this.lbl_lapert14.AutoSize = true;
            this.lbl_lapert14.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert14.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert14.Name = "lbl_lapert14";
            this.lbl_lapert14.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert14.TabIndex = 3;
            this.lbl_lapert14.Text = "T";
            // 
            // pb_lapszin14
            // 
            this.pb_lapszin14.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin14.Name = "pb_lapszin14";
            this.pb_lapszin14.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin14.TabIndex = 2;
            this.pb_lapszin14.TabStop = false;
            // 
            // pb_lapszin13
            // 
            this.pb_lapszin13.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin13.Name = "pb_lapszin13";
            this.pb_lapszin13.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin13.TabIndex = 1;
            this.pb_lapszin13.TabStop = false;
            // 
            // lbl_lapert13
            // 
            this.lbl_lapert13.AutoSize = true;
            this.lbl_lapert13.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert13.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert13.Name = "lbl_lapert13";
            this.lbl_lapert13.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert13.TabIndex = 0;
            this.lbl_lapert13.Text = "T";
            // 
            // pnl_lap15
            // 
            this.pnl_lap15.Controls.Add(this.lbl_lapert30);
            this.pnl_lap15.Controls.Add(this.pb_lapszin30);
            this.pnl_lap15.Controls.Add(this.pb_lapszin29);
            this.pnl_lap15.Controls.Add(this.lbl_lapert29);
            this.pnl_lap15.Location = new System.Drawing.Point(1084, 234);
            this.pnl_lap15.Name = "pnl_lap15";
            this.pnl_lap15.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap15.TabIndex = 15;
            // 
            // lbl_lapert30
            // 
            this.lbl_lapert30.AutoSize = true;
            this.lbl_lapert30.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert30.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert30.Name = "lbl_lapert30";
            this.lbl_lapert30.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert30.TabIndex = 3;
            this.lbl_lapert30.Text = "T";
            // 
            // pb_lapszin30
            // 
            this.pb_lapszin30.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin30.Name = "pb_lapszin30";
            this.pb_lapszin30.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin30.TabIndex = 2;
            this.pb_lapszin30.TabStop = false;
            // 
            // pb_lapszin29
            // 
            this.pb_lapszin29.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin29.Name = "pb_lapszin29";
            this.pb_lapszin29.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin29.TabIndex = 1;
            this.pb_lapszin29.TabStop = false;
            // 
            // lbl_lapert29
            // 
            this.lbl_lapert29.AutoSize = true;
            this.lbl_lapert29.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert29.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert29.Name = "lbl_lapert29";
            this.lbl_lapert29.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert29.TabIndex = 0;
            this.lbl_lapert29.Text = "T";
            // 
            // pnl_lap23
            // 
            this.pnl_lap23.Controls.Add(this.lbl_lapert46);
            this.pnl_lap23.Controls.Add(this.pb_lapszin46);
            this.pnl_lap23.Controls.Add(this.pb_lapszin45);
            this.pnl_lap23.Controls.Add(this.lbl_lapert45);
            this.pnl_lap23.Location = new System.Drawing.Point(1084, 457);
            this.pnl_lap23.Name = "pnl_lap23";
            this.pnl_lap23.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap23.TabIndex = 15;
            // 
            // lbl_lapert46
            // 
            this.lbl_lapert46.AutoSize = true;
            this.lbl_lapert46.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert46.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert46.Name = "lbl_lapert46";
            this.lbl_lapert46.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert46.TabIndex = 3;
            this.lbl_lapert46.Text = "T";
            // 
            // pb_lapszin46
            // 
            this.pb_lapszin46.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin46.Name = "pb_lapszin46";
            this.pb_lapszin46.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin46.TabIndex = 2;
            this.pb_lapszin46.TabStop = false;
            // 
            // pb_lapszin45
            // 
            this.pb_lapszin45.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin45.Name = "pb_lapszin45";
            this.pb_lapszin45.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin45.TabIndex = 1;
            this.pb_lapszin45.TabStop = false;
            // 
            // lbl_lapert45
            // 
            this.lbl_lapert45.AutoSize = true;
            this.lbl_lapert45.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert45.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert45.Name = "lbl_lapert45";
            this.lbl_lapert45.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert45.TabIndex = 0;
            this.lbl_lapert45.Text = "T";
            // 
            // pnl_lap22
            // 
            this.pnl_lap22.Controls.Add(this.lbl_lapert44);
            this.pnl_lap22.Controls.Add(this.pb_lapszin44);
            this.pnl_lap22.Controls.Add(this.pb_lapszin43);
            this.pnl_lap22.Controls.Add(this.lbl_lapert43);
            this.pnl_lap22.Location = new System.Drawing.Point(932, 457);
            this.pnl_lap22.Name = "pnl_lap22";
            this.pnl_lap22.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap22.TabIndex = 15;
            // 
            // lbl_lapert44
            // 
            this.lbl_lapert44.AutoSize = true;
            this.lbl_lapert44.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert44.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert44.Name = "lbl_lapert44";
            this.lbl_lapert44.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert44.TabIndex = 3;
            this.lbl_lapert44.Text = "T";
            // 
            // pb_lapszin44
            // 
            this.pb_lapszin44.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin44.Name = "pb_lapszin44";
            this.pb_lapszin44.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin44.TabIndex = 2;
            this.pb_lapszin44.TabStop = false;
            // 
            // pb_lapszin43
            // 
            this.pb_lapszin43.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin43.Name = "pb_lapszin43";
            this.pb_lapszin43.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin43.TabIndex = 1;
            this.pb_lapszin43.TabStop = false;
            // 
            // lbl_lapert43
            // 
            this.lbl_lapert43.AutoSize = true;
            this.lbl_lapert43.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert43.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert43.Name = "lbl_lapert43";
            this.lbl_lapert43.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert43.TabIndex = 0;
            this.lbl_lapert43.Text = "T";
            this.lbl_lapert43.Click += new System.EventHandler(this.label34_Click);
            // 
            // pnl_lap14
            // 
            this.pnl_lap14.Controls.Add(this.lbl_lapert28);
            this.pnl_lap14.Controls.Add(this.pb_lapszin28);
            this.pnl_lap14.Controls.Add(this.pb_lapszin27);
            this.pnl_lap14.Controls.Add(this.lbl_lapert27);
            this.pnl_lap14.Location = new System.Drawing.Point(932, 234);
            this.pnl_lap14.Name = "pnl_lap14";
            this.pnl_lap14.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap14.TabIndex = 15;
            // 
            // lbl_lapert28
            // 
            this.lbl_lapert28.AutoSize = true;
            this.lbl_lapert28.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert28.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert28.Name = "lbl_lapert28";
            this.lbl_lapert28.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert28.TabIndex = 3;
            this.lbl_lapert28.Text = "T";
            // 
            // pb_lapszin28
            // 
            this.pb_lapszin28.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin28.Name = "pb_lapszin28";
            this.pb_lapszin28.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin28.TabIndex = 2;
            this.pb_lapszin28.TabStop = false;
            // 
            // pb_lapszin27
            // 
            this.pb_lapszin27.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin27.Name = "pb_lapszin27";
            this.pb_lapszin27.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin27.TabIndex = 1;
            this.pb_lapszin27.TabStop = false;
            // 
            // lbl_lapert27
            // 
            this.lbl_lapert27.AutoSize = true;
            this.lbl_lapert27.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert27.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert27.Name = "lbl_lapert27";
            this.lbl_lapert27.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert27.TabIndex = 0;
            this.lbl_lapert27.Text = "T";
            // 
            // pnl_lap6
            // 
            this.pnl_lap6.Controls.Add(this.lbl_lapert12);
            this.pnl_lap6.Controls.Add(this.pb_lapszin12);
            this.pnl_lap6.Controls.Add(this.pb_lapszin11);
            this.pnl_lap6.Controls.Add(this.lbl_lapert11);
            this.pnl_lap6.Location = new System.Drawing.Point(932, 11);
            this.pnl_lap6.Name = "pnl_lap6";
            this.pnl_lap6.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap6.TabIndex = 15;
            // 
            // lbl_lapert12
            // 
            this.lbl_lapert12.AutoSize = true;
            this.lbl_lapert12.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert12.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert12.Name = "lbl_lapert12";
            this.lbl_lapert12.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert12.TabIndex = 3;
            this.lbl_lapert12.Text = "T";
            // 
            // pb_lapszin12
            // 
            this.pb_lapszin12.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin12.Name = "pb_lapszin12";
            this.pb_lapszin12.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin12.TabIndex = 2;
            this.pb_lapszin12.TabStop = false;
            // 
            // pb_lapszin11
            // 
            this.pb_lapszin11.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin11.Name = "pb_lapszin11";
            this.pb_lapszin11.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin11.TabIndex = 1;
            this.pb_lapszin11.TabStop = false;
            // 
            // lbl_lapert11
            // 
            this.lbl_lapert11.AutoSize = true;
            this.lbl_lapert11.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert11.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert11.Name = "lbl_lapert11";
            this.lbl_lapert11.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert11.TabIndex = 0;
            this.lbl_lapert11.Text = "T";
            // 
            // pnl_lap5
            // 
            this.pnl_lap5.Controls.Add(this.lbl_lapert10);
            this.pnl_lap5.Controls.Add(this.pb_lapszin10);
            this.pnl_lap5.Controls.Add(this.pb_lapszin9);
            this.pnl_lap5.Controls.Add(this.lbl_lapert9);
            this.pnl_lap5.Location = new System.Drawing.Point(780, 11);
            this.pnl_lap5.Name = "pnl_lap5";
            this.pnl_lap5.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap5.TabIndex = 15;
            // 
            // lbl_lapert10
            // 
            this.lbl_lapert10.AutoSize = true;
            this.lbl_lapert10.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert10.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert10.Name = "lbl_lapert10";
            this.lbl_lapert10.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert10.TabIndex = 3;
            this.lbl_lapert10.Text = "T";
            // 
            // pb_lapszin10
            // 
            this.pb_lapszin10.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin10.Name = "pb_lapszin10";
            this.pb_lapszin10.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin10.TabIndex = 2;
            this.pb_lapszin10.TabStop = false;
            // 
            // pb_lapszin9
            // 
            this.pb_lapszin9.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin9.Name = "pb_lapszin9";
            this.pb_lapszin9.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin9.TabIndex = 1;
            this.pb_lapszin9.TabStop = false;
            // 
            // lbl_lapert9
            // 
            this.lbl_lapert9.AutoSize = true;
            this.lbl_lapert9.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert9.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert9.Name = "lbl_lapert9";
            this.lbl_lapert9.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert9.TabIndex = 0;
            this.lbl_lapert9.Text = "T";
            // 
            // pnl_lap13
            // 
            this.pnl_lap13.Controls.Add(this.lbl_lapert26);
            this.pnl_lap13.Controls.Add(this.pb_lapszin26);
            this.pnl_lap13.Controls.Add(this.pb_lapszin25);
            this.pnl_lap13.Controls.Add(this.lbl_lapert25);
            this.pnl_lap13.Location = new System.Drawing.Point(780, 234);
            this.pnl_lap13.Name = "pnl_lap13";
            this.pnl_lap13.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap13.TabIndex = 15;
            // 
            // lbl_lapert26
            // 
            this.lbl_lapert26.AutoSize = true;
            this.lbl_lapert26.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert26.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert26.Name = "lbl_lapert26";
            this.lbl_lapert26.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert26.TabIndex = 3;
            this.lbl_lapert26.Text = "T";
            // 
            // pb_lapszin26
            // 
            this.pb_lapszin26.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin26.Name = "pb_lapszin26";
            this.pb_lapszin26.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin26.TabIndex = 2;
            this.pb_lapszin26.TabStop = false;
            // 
            // pb_lapszin25
            // 
            this.pb_lapszin25.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin25.Name = "pb_lapszin25";
            this.pb_lapszin25.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin25.TabIndex = 1;
            this.pb_lapszin25.TabStop = false;
            // 
            // lbl_lapert25
            // 
            this.lbl_lapert25.AutoSize = true;
            this.lbl_lapert25.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert25.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert25.Name = "lbl_lapert25";
            this.lbl_lapert25.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert25.TabIndex = 0;
            this.lbl_lapert25.Text = "T";
            // 
            // pnl_lap21
            // 
            this.pnl_lap21.Controls.Add(this.lbl_lapert42);
            this.pnl_lap21.Controls.Add(this.pb_lapszin42);
            this.pnl_lap21.Controls.Add(this.pb_lapszin41);
            this.pnl_lap21.Controls.Add(this.lbl_lapert41);
            this.pnl_lap21.Location = new System.Drawing.Point(780, 457);
            this.pnl_lap21.Name = "pnl_lap21";
            this.pnl_lap21.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap21.TabIndex = 15;
            // 
            // lbl_lapert42
            // 
            this.lbl_lapert42.AutoSize = true;
            this.lbl_lapert42.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert42.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert42.Name = "lbl_lapert42";
            this.lbl_lapert42.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert42.TabIndex = 3;
            this.lbl_lapert42.Text = "T";
            // 
            // pb_lapszin42
            // 
            this.pb_lapszin42.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin42.Name = "pb_lapszin42";
            this.pb_lapszin42.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin42.TabIndex = 2;
            this.pb_lapszin42.TabStop = false;
            // 
            // pb_lapszin41
            // 
            this.pb_lapszin41.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin41.Name = "pb_lapszin41";
            this.pb_lapszin41.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin41.TabIndex = 1;
            this.pb_lapszin41.TabStop = false;
            // 
            // lbl_lapert41
            // 
            this.lbl_lapert41.AutoSize = true;
            this.lbl_lapert41.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert41.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert41.Name = "lbl_lapert41";
            this.lbl_lapert41.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert41.TabIndex = 0;
            this.lbl_lapert41.Text = "T";
            // 
            // pnl_lap20
            // 
            this.pnl_lap20.Controls.Add(this.lbl_lapert40);
            this.pnl_lap20.Controls.Add(this.pb_lapszin40);
            this.pnl_lap20.Controls.Add(this.pb_lapszin39);
            this.pnl_lap20.Controls.Add(this.lbl_lapert39);
            this.pnl_lap20.Location = new System.Drawing.Point(628, 457);
            this.pnl_lap20.Name = "pnl_lap20";
            this.pnl_lap20.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap20.TabIndex = 15;
            // 
            // lbl_lapert40
            // 
            this.lbl_lapert40.AutoSize = true;
            this.lbl_lapert40.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert40.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert40.Name = "lbl_lapert40";
            this.lbl_lapert40.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert40.TabIndex = 3;
            this.lbl_lapert40.Text = "T";
            // 
            // pb_lapszin40
            // 
            this.pb_lapszin40.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin40.Name = "pb_lapszin40";
            this.pb_lapszin40.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin40.TabIndex = 2;
            this.pb_lapszin40.TabStop = false;
            // 
            // pb_lapszin39
            // 
            this.pb_lapszin39.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin39.Name = "pb_lapszin39";
            this.pb_lapszin39.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin39.TabIndex = 1;
            this.pb_lapszin39.TabStop = false;
            // 
            // lbl_lapert39
            // 
            this.lbl_lapert39.AutoSize = true;
            this.lbl_lapert39.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert39.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert39.Name = "lbl_lapert39";
            this.lbl_lapert39.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert39.TabIndex = 0;
            this.lbl_lapert39.Text = "T";
            // 
            // pnl_lap12
            // 
            this.pnl_lap12.Controls.Add(this.lbl_lapert24);
            this.pnl_lap12.Controls.Add(this.pb_lapszin24);
            this.pnl_lap12.Controls.Add(this.pb_lapszin23);
            this.pnl_lap12.Controls.Add(this.lbl_lapert23);
            this.pnl_lap12.Location = new System.Drawing.Point(628, 234);
            this.pnl_lap12.Name = "pnl_lap12";
            this.pnl_lap12.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap12.TabIndex = 15;
            // 
            // lbl_lapert24
            // 
            this.lbl_lapert24.AutoSize = true;
            this.lbl_lapert24.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert24.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert24.Name = "lbl_lapert24";
            this.lbl_lapert24.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert24.TabIndex = 3;
            this.lbl_lapert24.Text = "T";
            // 
            // pb_lapszin24
            // 
            this.pb_lapszin24.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin24.Name = "pb_lapszin24";
            this.pb_lapszin24.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin24.TabIndex = 2;
            this.pb_lapszin24.TabStop = false;
            // 
            // pb_lapszin23
            // 
            this.pb_lapszin23.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin23.Name = "pb_lapszin23";
            this.pb_lapszin23.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin23.TabIndex = 1;
            this.pb_lapszin23.TabStop = false;
            // 
            // lbl_lapert23
            // 
            this.lbl_lapert23.AutoSize = true;
            this.lbl_lapert23.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert23.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert23.Name = "lbl_lapert23";
            this.lbl_lapert23.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert23.TabIndex = 0;
            this.lbl_lapert23.Text = "T";
            // 
            // pnl_lap4
            // 
            this.pnl_lap4.Controls.Add(this.lbl_lapert8);
            this.pnl_lap4.Controls.Add(this.pb_lapszin8);
            this.pnl_lap4.Controls.Add(this.pb_lapszin7);
            this.pnl_lap4.Controls.Add(this.lbl_lapert7);
            this.pnl_lap4.Location = new System.Drawing.Point(628, 11);
            this.pnl_lap4.Name = "pnl_lap4";
            this.pnl_lap4.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap4.TabIndex = 15;
            // 
            // lbl_lapert8
            // 
            this.lbl_lapert8.AutoSize = true;
            this.lbl_lapert8.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert8.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert8.Name = "lbl_lapert8";
            this.lbl_lapert8.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert8.TabIndex = 3;
            this.lbl_lapert8.Text = "T";
            // 
            // pb_lapszin8
            // 
            this.pb_lapszin8.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin8.Name = "pb_lapszin8";
            this.pb_lapszin8.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin8.TabIndex = 2;
            this.pb_lapszin8.TabStop = false;
            // 
            // pb_lapszin7
            // 
            this.pb_lapszin7.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin7.Name = "pb_lapszin7";
            this.pb_lapszin7.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin7.TabIndex = 1;
            this.pb_lapszin7.TabStop = false;
            // 
            // lbl_lapert7
            // 
            this.lbl_lapert7.AutoSize = true;
            this.lbl_lapert7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert7.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert7.Name = "lbl_lapert7";
            this.lbl_lapert7.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert7.TabIndex = 0;
            this.lbl_lapert7.Text = "T";
            // 
            // pnl_lap3
            // 
            this.pnl_lap3.Controls.Add(this.lbl_lapert6);
            this.pnl_lap3.Controls.Add(this.pb_lapszin6);
            this.pnl_lap3.Controls.Add(this.pb_lapszin5);
            this.pnl_lap3.Controls.Add(this.lbl_lapert5);
            this.pnl_lap3.Location = new System.Drawing.Point(476, 11);
            this.pnl_lap3.Name = "pnl_lap3";
            this.pnl_lap3.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap3.TabIndex = 15;
            // 
            // lbl_lapert6
            // 
            this.lbl_lapert6.AutoSize = true;
            this.lbl_lapert6.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert6.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert6.Name = "lbl_lapert6";
            this.lbl_lapert6.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert6.TabIndex = 3;
            this.lbl_lapert6.Text = "T";
            // 
            // pb_lapszin6
            // 
            this.pb_lapszin6.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin6.Name = "pb_lapszin6";
            this.pb_lapszin6.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin6.TabIndex = 2;
            this.pb_lapszin6.TabStop = false;
            // 
            // pb_lapszin5
            // 
            this.pb_lapszin5.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin5.Name = "pb_lapszin5";
            this.pb_lapszin5.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin5.TabIndex = 1;
            this.pb_lapszin5.TabStop = false;
            // 
            // lbl_lapert5
            // 
            this.lbl_lapert5.AutoSize = true;
            this.lbl_lapert5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert5.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert5.Name = "lbl_lapert5";
            this.lbl_lapert5.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert5.TabIndex = 0;
            this.lbl_lapert5.Text = "T";
            // 
            // pnl_lap11
            // 
            this.pnl_lap11.Controls.Add(this.lbl_lapert22);
            this.pnl_lap11.Controls.Add(this.pb_lapszin22);
            this.pnl_lap11.Controls.Add(this.pb_lapszin21);
            this.pnl_lap11.Controls.Add(this.lbl_lapert21);
            this.pnl_lap11.Location = new System.Drawing.Point(476, 234);
            this.pnl_lap11.Name = "pnl_lap11";
            this.pnl_lap11.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap11.TabIndex = 15;
            // 
            // lbl_lapert22
            // 
            this.lbl_lapert22.AutoSize = true;
            this.lbl_lapert22.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert22.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert22.Name = "lbl_lapert22";
            this.lbl_lapert22.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert22.TabIndex = 3;
            this.lbl_lapert22.Text = "T";
            // 
            // pb_lapszin22
            // 
            this.pb_lapszin22.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin22.Name = "pb_lapszin22";
            this.pb_lapszin22.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin22.TabIndex = 2;
            this.pb_lapszin22.TabStop = false;
            // 
            // pb_lapszin21
            // 
            this.pb_lapszin21.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin21.Name = "pb_lapszin21";
            this.pb_lapszin21.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin21.TabIndex = 1;
            this.pb_lapszin21.TabStop = false;
            // 
            // lbl_lapert21
            // 
            this.lbl_lapert21.AutoSize = true;
            this.lbl_lapert21.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert21.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert21.Name = "lbl_lapert21";
            this.lbl_lapert21.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert21.TabIndex = 0;
            this.lbl_lapert21.Text = "T";
            // 
            // pnl_lap19
            // 
            this.pnl_lap19.Controls.Add(this.lbl_lapert38);
            this.pnl_lap19.Controls.Add(this.pb_lapszin38);
            this.pnl_lap19.Controls.Add(this.pb_lapszin37);
            this.pnl_lap19.Controls.Add(this.lbl_lapert37);
            this.pnl_lap19.Location = new System.Drawing.Point(476, 457);
            this.pnl_lap19.Name = "pnl_lap19";
            this.pnl_lap19.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap19.TabIndex = 15;
            // 
            // lbl_lapert38
            // 
            this.lbl_lapert38.AutoSize = true;
            this.lbl_lapert38.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert38.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert38.Name = "lbl_lapert38";
            this.lbl_lapert38.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert38.TabIndex = 3;
            this.lbl_lapert38.Text = "T";
            // 
            // pb_lapszin38
            // 
            this.pb_lapszin38.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin38.Name = "pb_lapszin38";
            this.pb_lapszin38.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin38.TabIndex = 2;
            this.pb_lapszin38.TabStop = false;
            // 
            // pb_lapszin37
            // 
            this.pb_lapszin37.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin37.Name = "pb_lapszin37";
            this.pb_lapszin37.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin37.TabIndex = 1;
            this.pb_lapszin37.TabStop = false;
            // 
            // lbl_lapert37
            // 
            this.lbl_lapert37.AutoSize = true;
            this.lbl_lapert37.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert37.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert37.Name = "lbl_lapert37";
            this.lbl_lapert37.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert37.TabIndex = 0;
            this.lbl_lapert37.Text = "T";
            // 
            // pnl_lap18
            // 
            this.pnl_lap18.Controls.Add(this.lbl_lapert36);
            this.pnl_lap18.Controls.Add(this.pb_lapszin36);
            this.pnl_lap18.Controls.Add(this.pb_lapszin35);
            this.pnl_lap18.Controls.Add(this.lbl_lapert35);
            this.pnl_lap18.Location = new System.Drawing.Point(324, 457);
            this.pnl_lap18.Name = "pnl_lap18";
            this.pnl_lap18.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap18.TabIndex = 15;
            // 
            // lbl_lapert36
            // 
            this.lbl_lapert36.AutoSize = true;
            this.lbl_lapert36.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert36.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert36.Name = "lbl_lapert36";
            this.lbl_lapert36.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert36.TabIndex = 3;
            this.lbl_lapert36.Text = "T";
            // 
            // pb_lapszin36
            // 
            this.pb_lapszin36.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin36.Name = "pb_lapszin36";
            this.pb_lapszin36.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin36.TabIndex = 2;
            this.pb_lapszin36.TabStop = false;
            // 
            // pb_lapszin35
            // 
            this.pb_lapszin35.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin35.Name = "pb_lapszin35";
            this.pb_lapszin35.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin35.TabIndex = 1;
            this.pb_lapszin35.TabStop = false;
            // 
            // lbl_lapert35
            // 
            this.lbl_lapert35.AutoSize = true;
            this.lbl_lapert35.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert35.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert35.Name = "lbl_lapert35";
            this.lbl_lapert35.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert35.TabIndex = 0;
            this.lbl_lapert35.Text = "T";
            // 
            // pnl_lap10
            // 
            this.pnl_lap10.Controls.Add(this.lbl_lapert20);
            this.pnl_lap10.Controls.Add(this.pb_lapszin20);
            this.pnl_lap10.Controls.Add(this.pb_lapszin19);
            this.pnl_lap10.Controls.Add(this.lbl_lapert19);
            this.pnl_lap10.Location = new System.Drawing.Point(324, 234);
            this.pnl_lap10.Name = "pnl_lap10";
            this.pnl_lap10.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap10.TabIndex = 15;
            this.pnl_lap10.Paint += new System.Windows.Forms.PaintEventHandler(this.panel7_Paint);
            // 
            // lbl_lapert20
            // 
            this.lbl_lapert20.AutoSize = true;
            this.lbl_lapert20.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert20.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert20.Name = "lbl_lapert20";
            this.lbl_lapert20.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert20.TabIndex = 3;
            this.lbl_lapert20.Text = "T";
            // 
            // pb_lapszin20
            // 
            this.pb_lapszin20.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin20.Name = "pb_lapszin20";
            this.pb_lapszin20.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin20.TabIndex = 2;
            this.pb_lapszin20.TabStop = false;
            // 
            // pb_lapszin19
            // 
            this.pb_lapszin19.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin19.Name = "pb_lapszin19";
            this.pb_lapszin19.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin19.TabIndex = 1;
            this.pb_lapszin19.TabStop = false;
            // 
            // lbl_lapert19
            // 
            this.lbl_lapert19.AutoSize = true;
            this.lbl_lapert19.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert19.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert19.Name = "lbl_lapert19";
            this.lbl_lapert19.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert19.TabIndex = 0;
            this.lbl_lapert19.Text = "T";
            this.lbl_lapert19.Click += new System.EventHandler(this.label8_Click);
            // 
            // pnl_lap2
            // 
            this.pnl_lap2.Controls.Add(this.lbl_lapert4);
            this.pnl_lap2.Controls.Add(this.pb_lapszin4);
            this.pnl_lap2.Controls.Add(this.pb_lapszin3);
            this.pnl_lap2.Controls.Add(this.lbl_lapert3);
            this.pnl_lap2.Location = new System.Drawing.Point(324, 11);
            this.pnl_lap2.Name = "pnl_lap2";
            this.pnl_lap2.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap2.TabIndex = 15;
            // 
            // lbl_lapert4
            // 
            this.lbl_lapert4.AutoSize = true;
            this.lbl_lapert4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert4.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert4.Name = "lbl_lapert4";
            this.lbl_lapert4.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert4.TabIndex = 3;
            this.lbl_lapert4.Text = "T";
            // 
            // pb_lapszin4
            // 
            this.pb_lapszin4.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin4.Name = "pb_lapszin4";
            this.pb_lapszin4.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin4.TabIndex = 2;
            this.pb_lapszin4.TabStop = false;
            // 
            // pb_lapszin3
            // 
            this.pb_lapszin3.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin3.Name = "pb_lapszin3";
            this.pb_lapszin3.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin3.TabIndex = 1;
            this.pb_lapszin3.TabStop = false;
            // 
            // lbl_lapert3
            // 
            this.lbl_lapert3.AutoSize = true;
            this.lbl_lapert3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert3.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert3.Name = "lbl_lapert3";
            this.lbl_lapert3.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert3.TabIndex = 0;
            this.lbl_lapert3.Text = "T";
            // 
            // pnl_lap9
            // 
            this.pnl_lap9.Controls.Add(this.lbl_lapert18);
            this.pnl_lap9.Controls.Add(this.pb_lapszin18);
            this.pnl_lap9.Controls.Add(this.pb_lapszin17);
            this.pnl_lap9.Controls.Add(this.lbl_lapert17);
            this.pnl_lap9.Location = new System.Drawing.Point(172, 234);
            this.pnl_lap9.Name = "pnl_lap9";
            this.pnl_lap9.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap9.TabIndex = 15;
            // 
            // lbl_lapert18
            // 
            this.lbl_lapert18.AutoSize = true;
            this.lbl_lapert18.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert18.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert18.Name = "lbl_lapert18";
            this.lbl_lapert18.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert18.TabIndex = 3;
            this.lbl_lapert18.Text = "T";
            // 
            // pb_lapszin18
            // 
            this.pb_lapszin18.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin18.Name = "pb_lapszin18";
            this.pb_lapszin18.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin18.TabIndex = 2;
            this.pb_lapszin18.TabStop = false;
            // 
            // pb_lapszin17
            // 
            this.pb_lapszin17.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin17.Name = "pb_lapszin17";
            this.pb_lapszin17.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin17.TabIndex = 1;
            this.pb_lapszin17.TabStop = false;
            // 
            // lbl_lapert17
            // 
            this.lbl_lapert17.AutoSize = true;
            this.lbl_lapert17.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert17.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert17.Name = "lbl_lapert17";
            this.lbl_lapert17.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert17.TabIndex = 0;
            this.lbl_lapert17.Text = "T";
            // 
            // pnl_lap17
            // 
            this.pnl_lap17.Controls.Add(this.lbl_lapert34);
            this.pnl_lap17.Controls.Add(this.pb_lapszin34);
            this.pnl_lap17.Controls.Add(this.pb_lapszin33);
            this.pnl_lap17.Controls.Add(this.lbl_lapert33);
            this.pnl_lap17.Location = new System.Drawing.Point(172, 457);
            this.pnl_lap17.Name = "pnl_lap17";
            this.pnl_lap17.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap17.TabIndex = 15;
            // 
            // lbl_lapert34
            // 
            this.lbl_lapert34.AutoSize = true;
            this.lbl_lapert34.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert34.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert34.Name = "lbl_lapert34";
            this.lbl_lapert34.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert34.TabIndex = 3;
            this.lbl_lapert34.Text = "T";
            // 
            // pb_lapszin34
            // 
            this.pb_lapszin34.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin34.Name = "pb_lapszin34";
            this.pb_lapszin34.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin34.TabIndex = 2;
            this.pb_lapszin34.TabStop = false;
            // 
            // pb_lapszin33
            // 
            this.pb_lapszin33.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin33.Name = "pb_lapszin33";
            this.pb_lapszin33.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin33.TabIndex = 1;
            this.pb_lapszin33.TabStop = false;
            // 
            // lbl_lapert33
            // 
            this.lbl_lapert33.AutoSize = true;
            this.lbl_lapert33.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert33.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert33.Name = "lbl_lapert33";
            this.lbl_lapert33.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert33.TabIndex = 0;
            this.lbl_lapert33.Text = "T";
            // 
            // pnl_lap1
            // 
            this.pnl_lap1.Controls.Add(this.lbl_lapert2);
            this.pnl_lap1.Controls.Add(this.pb_lapszin2);
            this.pnl_lap1.Controls.Add(this.pb_lapszin1);
            this.pnl_lap1.Controls.Add(this.lbl_lapert1);
            this.pnl_lap1.Location = new System.Drawing.Point(172, 11);
            this.pnl_lap1.Name = "pnl_lap1";
            this.pnl_lap1.Size = new System.Drawing.Size(146, 200);
            this.pnl_lap1.TabIndex = 14;
            // 
            // lbl_lapert2
            // 
            this.lbl_lapert2.AutoSize = true;
            this.lbl_lapert2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert2.Location = new System.Drawing.Point(109, 159);
            this.lbl_lapert2.Name = "lbl_lapert2";
            this.lbl_lapert2.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert2.TabIndex = 3;
            this.lbl_lapert2.Text = "T";
            // 
            // pb_lapszin2
            // 
            this.pb_lapszin2.Location = new System.Drawing.Point(110, 121);
            this.pb_lapszin2.Name = "pb_lapszin2";
            this.pb_lapszin2.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin2.TabIndex = 2;
            this.pb_lapszin2.TabStop = false;
            // 
            // pb_lapszin1
            // 
            this.pb_lapszin1.Location = new System.Drawing.Point(7, 45);
            this.pb_lapszin1.Name = "pb_lapszin1";
            this.pb_lapszin1.Size = new System.Drawing.Size(32, 35);
            this.pb_lapszin1.TabIndex = 1;
            this.pb_lapszin1.TabStop = false;
            // 
            // lbl_lapert1
            // 
            this.lbl_lapert1.AutoSize = true;
            this.lbl_lapert1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.lbl_lapert1.Location = new System.Drawing.Point(6, 9);
            this.lbl_lapert1.Name = "lbl_lapert1";
            this.lbl_lapert1.Size = new System.Drawing.Size(33, 36);
            this.lbl_lapert1.TabIndex = 0;
            this.lbl_lapert1.Text = "T";
            // 
            // lbl_playerert
            // 
            this.lbl_playerert.AutoSize = true;
            this.lbl_playerert.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbl_playerert.Location = new System.Drawing.Point(4, 503);
            this.lbl_playerert.Name = "lbl_playerert";
            this.lbl_playerert.Size = new System.Drawing.Size(117, 22);
            this.lbl_playerert.TabIndex = 13;
            this.lbl_playerert.Text = "Játékos érték";
            // 
            // lbl_szoveg28
            // 
            this.lbl_szoveg28.AutoSize = true;
            this.lbl_szoveg28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbl_szoveg28.Location = new System.Drawing.Point(2, 479);
            this.lbl_szoveg28.Name = "lbl_szoveg28";
            this.lbl_szoveg28.Size = new System.Drawing.Size(130, 22);
            this.lbl_szoveg28.TabIndex = 12;
            this.lbl_szoveg28.Text = "A lapok értéke:";
            // 
            // lbl_szoveg27
            // 
            this.lbl_szoveg27.AutoSize = true;
            this.lbl_szoveg27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbl_szoveg27.Location = new System.Drawing.Point(2, 457);
            this.lbl_szoveg27.Name = "lbl_szoveg27";
            this.lbl_szoveg27.Size = new System.Drawing.Size(104, 22);
            this.lbl_szoveg27.TabIndex = 11;
            this.lbl_szoveg27.Text = "A te lapjaid:";
            // 
            // lbl_szoveg26
            // 
            this.lbl_szoveg26.AutoSize = true;
            this.lbl_szoveg26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbl_szoveg26.Location = new System.Drawing.Point(4, 241);
            this.lbl_szoveg26.Name = "lbl_szoveg26";
            this.lbl_szoveg26.Size = new System.Drawing.Size(158, 22);
            this.lbl_szoveg26.TabIndex = 10;
            this.lbl_szoveg26.Text = "Felezés egyik fele:";
            // 
            // lbl_osztoert
            // 
            this.lbl_osztoert.AutoSize = true;
            this.lbl_osztoert.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbl_osztoert.Location = new System.Drawing.Point(10, 72);
            this.lbl_osztoert.Name = "lbl_osztoert";
            this.lbl_osztoert.Size = new System.Drawing.Size(96, 22);
            this.lbl_osztoert.TabIndex = 9;
            this.lbl_osztoert.Text = "Osztóérték";
            // 
            // lbl_szoveg25
            // 
            this.lbl_szoveg25.AutoSize = true;
            this.lbl_szoveg25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbl_szoveg25.Location = new System.Drawing.Point(8, 44);
            this.lbl_szoveg25.Name = "lbl_szoveg25";
            this.lbl_szoveg25.Size = new System.Drawing.Size(130, 22);
            this.lbl_szoveg25.TabIndex = 8;
            this.lbl_szoveg25.Text = "A lapok értéke:";
            // 
            // lbl_szoveg24
            // 
            this.lbl_szoveg24.AutoSize = true;
            this.lbl_szoveg24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.lbl_szoveg24.Location = new System.Drawing.Point(8, 11);
            this.lbl_szoveg24.Name = "lbl_szoveg24";
            this.lbl_szoveg24.Size = new System.Drawing.Size(118, 22);
            this.lbl_szoveg24.TabIndex = 7;
            this.lbl_szoveg24.Text = "A bank lapjai:";
            // 
            // btn_zsetonvesz
            // 
            this.btn_zsetonvesz.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_zsetonvesz.Location = new System.Drawing.Point(1526, 770);
            this.btn_zsetonvesz.Name = "btn_zsetonvesz";
            this.btn_zsetonvesz.Size = new System.Drawing.Size(75, 56);
            this.btn_zsetonvesz.TabIndex = 6;
            this.btn_zsetonvesz.Text = "Zsetont\r\nveszek";
            this.btn_zsetonvesz.UseVisualStyleBackColor = true;
            this.btn_zsetonvesz.Click += new System.EventHandler(this.btn_zsetonvesz_Click);
            // 
            // btn_kilepes
            // 
            this.btn_kilepes.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_kilepes.Location = new System.Drawing.Point(1486, 36);
            this.btn_kilepes.Name = "btn_kilepes";
            this.btn_kilepes.Size = new System.Drawing.Size(95, 32);
            this.btn_kilepes.TabIndex = 5;
            this.btn_kilepes.Text = "Kilépés";
            this.btn_kilepes.UseVisualStyleBackColor = true;
            this.btn_kilepes.Click += new System.EventHandler(this.btn_kilepes_Click);
            // 
            // btn_betesz
            // 
            this.btn_betesz.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.btn_betesz.Location = new System.Drawing.Point(1425, 619);
            this.btn_betesz.Name = "btn_betesz";
            this.btn_betesz.Size = new System.Drawing.Size(90, 38);
            this.btn_betesz.TabIndex = 4;
            this.btn_betesz.Text = "Betesz";
            this.btn_betesz.UseVisualStyleBackColor = true;
            this.btn_betesz.Visible = false;
            this.btn_betesz.Click += new System.EventHandler(this.btn_betesz_Click);
            // 
            // sb_egyeni
            // 
            this.sb_egyeni.Location = new System.Drawing.Point(1385, 457);
            this.sb_egyeni.Maximum = 5000;
            this.sb_egyeni.Minimum = 25;
            this.sb_egyeni.Name = "sb_egyeni";
            this.sb_egyeni.Size = new System.Drawing.Size(37, 364);
            this.sb_egyeni.TabIndex = 3;
            this.sb_egyeni.Value = 5000;
            this.sb_egyeni.Visible = false;
            this.sb_egyeni.Scroll += new System.Windows.Forms.ScrollEventHandler(this.sb_egyeni_Scroll);
            // 
            // pnl_iranypult
            // 
            this.pnl_iranypult.BackColor = System.Drawing.Color.LemonChiffon;
            this.pnl_iranypult.Controls.Add(this.lbl_szoveg22);
            this.pnl_iranypult.Controls.Add(this.lbl_szoveg23);
            this.pnl_iranypult.Controls.Add(this.lbl_szoveg21);
            this.pnl_iranypult.Controls.Add(this.lbl_szoveg20);
            this.pnl_iranypult.Controls.Add(this.lbl_szoveg19);
            this.pnl_iranypult.Controls.Add(this.btn_segit5);
            this.pnl_iranypult.Controls.Add(this.btn_segit4);
            this.pnl_iranypult.Controls.Add(this.btn_segit3);
            this.pnl_iranypult.Controls.Add(this.btn_segit2);
            this.pnl_iranypult.Controls.Add(this.btn_segit1);
            this.pnl_iranypult.Controls.Add(this.btn_ismetles);
            this.pnl_iranypult.Controls.Add(this.btn_egyeni);
            this.pnl_iranypult.Controls.Add(this.btn_max);
            this.pnl_iranypult.Controls.Add(this.btn_min);
            this.pnl_iranypult.Controls.Add(this.btn_11);
            this.pnl_iranypult.Controls.Add(this.btn_1);
            this.pnl_iranypult.Controls.Add(this.lbl_szoveg18);
            this.pnl_iranypult.Controls.Add(this.lbl_zsetonod);
            this.pnl_iranypult.Location = new System.Drawing.Point(479, 832);
            this.pnl_iranypult.Name = "pnl_iranypult";
            this.pnl_iranypult.Size = new System.Drawing.Size(1122, 106);
            this.pnl_iranypult.TabIndex = 2;
            // 
            // lbl_szoveg22
            // 
            this.lbl_szoveg22.AutoSize = true;
            this.lbl_szoveg22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lbl_szoveg22.Location = new System.Drawing.Point(879, 30);
            this.lbl_szoveg22.Name = "lbl_szoveg22";
            this.lbl_szoveg22.Size = new System.Drawing.Size(51, 17);
            this.lbl_szoveg22.TabIndex = 17;
            this.lbl_szoveg22.Text = "Egyéni";
            // 
            // lbl_szoveg23
            // 
            this.lbl_szoveg23.AutoSize = true;
            this.lbl_szoveg23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lbl_szoveg23.Location = new System.Drawing.Point(1003, 30);
            this.lbl_szoveg23.Name = "lbl_szoveg23";
            this.lbl_szoveg23.Size = new System.Drawing.Size(106, 17);
            this.lbl_szoveg23.TabIndex = 16;
            this.lbl_szoveg23.Text = "Előző ismétlése";
            // 
            // lbl_szoveg21
            // 
            this.lbl_szoveg21.AutoSize = true;
            this.lbl_szoveg21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lbl_szoveg21.Location = new System.Drawing.Point(724, 30);
            this.lbl_szoveg21.Name = "lbl_szoveg21";
            this.lbl_szoveg21.Size = new System.Drawing.Size(56, 17);
            this.lbl_szoveg21.TabIndex = 15;
            this.lbl_szoveg21.Text = "1000 cr";
            // 
            // lbl_szoveg20
            // 
            this.lbl_szoveg20.AutoSize = true;
            this.lbl_szoveg20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lbl_szoveg20.Location = new System.Drawing.Point(585, 30);
            this.lbl_szoveg20.Name = "lbl_szoveg20";
            this.lbl_szoveg20.Size = new System.Drawing.Size(40, 17);
            this.lbl_szoveg20.TabIndex = 14;
            this.lbl_szoveg20.Text = "25 cr";
            // 
            // lbl_szoveg19
            // 
            this.lbl_szoveg19.AutoSize = true;
            this.lbl_szoveg19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lbl_szoveg19.Location = new System.Drawing.Point(388, 59);
            this.lbl_szoveg19.Name = "lbl_szoveg19";
            this.lbl_szoveg19.Size = new System.Drawing.Size(40, 17);
            this.lbl_szoveg19.TabIndex = 13;
            this.lbl_szoveg19.Text = "Vagy";
            this.lbl_szoveg19.Visible = false;
            // 
            // btn_segit5
            // 
            this.btn_segit5.Location = new System.Drawing.Point(965, 18);
            this.btn_segit5.Name = "btn_segit5";
            this.btn_segit5.Size = new System.Drawing.Size(32, 27);
            this.btn_segit5.TabIndex = 12;
            this.btn_segit5.Text = "?";
            this.btn_segit5.UseVisualStyleBackColor = true;
            // 
            // btn_segit4
            // 
            this.btn_segit4.Location = new System.Drawing.Point(822, 18);
            this.btn_segit4.Name = "btn_segit4";
            this.btn_segit4.Size = new System.Drawing.Size(32, 27);
            this.btn_segit4.TabIndex = 11;
            this.btn_segit4.Text = "?";
            this.btn_segit4.UseVisualStyleBackColor = true;
            // 
            // btn_segit3
            // 
            this.btn_segit3.Location = new System.Drawing.Point(679, 18);
            this.btn_segit3.Name = "btn_segit3";
            this.btn_segit3.Size = new System.Drawing.Size(32, 27);
            this.btn_segit3.TabIndex = 10;
            this.btn_segit3.Text = "?";
            this.btn_segit3.UseVisualStyleBackColor = true;
            // 
            // btn_segit2
            // 
            this.btn_segit2.Location = new System.Drawing.Point(536, 18);
            this.btn_segit2.Name = "btn_segit2";
            this.btn_segit2.Size = new System.Drawing.Size(32, 27);
            this.btn_segit2.TabIndex = 9;
            this.btn_segit2.Text = "?";
            this.btn_segit2.UseVisualStyleBackColor = true;
            // 
            // btn_segit1
            // 
            this.btn_segit1.Location = new System.Drawing.Point(391, 20);
            this.btn_segit1.Name = "btn_segit1";
            this.btn_segit1.Size = new System.Drawing.Size(32, 27);
            this.btn_segit1.TabIndex = 8;
            this.btn_segit1.Text = "?";
            this.btn_segit1.UseVisualStyleBackColor = true;
            // 
            // btn_ismetles
            // 
            this.btn_ismetles.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.btn_ismetles.Location = new System.Drawing.Point(965, 47);
            this.btn_ismetles.Name = "btn_ismetles";
            this.btn_ismetles.Size = new System.Drawing.Size(143, 41);
            this.btn_ismetles.TabIndex = 7;
            this.btn_ismetles.Text = "Ismétlés";
            this.btn_ismetles.UseVisualStyleBackColor = true;
            this.btn_ismetles.Click += new System.EventHandler(this.btn_ismetles_Click);
            // 
            // btn_egyeni
            // 
            this.btn_egyeni.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.btn_egyeni.Location = new System.Drawing.Point(822, 47);
            this.btn_egyeni.Name = "btn_egyeni";
            this.btn_egyeni.Size = new System.Drawing.Size(143, 41);
            this.btn_egyeni.TabIndex = 6;
            this.btn_egyeni.Text = "Egyéni tét";
            this.btn_egyeni.UseVisualStyleBackColor = true;
            this.btn_egyeni.Click += new System.EventHandler(this.btn_egyeni_Click);
            // 
            // btn_max
            // 
            this.btn_max.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.btn_max.Location = new System.Drawing.Point(679, 47);
            this.btn_max.Name = "btn_max";
            this.btn_max.Size = new System.Drawing.Size(143, 41);
            this.btn_max.TabIndex = 5;
            this.btn_max.Text = "Maximum";
            this.btn_max.UseVisualStyleBackColor = true;
            this.btn_max.Click += new System.EventHandler(this.btn_max_Click);
            // 
            // btn_min
            // 
            this.btn_min.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.btn_min.Location = new System.Drawing.Point(536, 47);
            this.btn_min.Name = "btn_min";
            this.btn_min.Size = new System.Drawing.Size(143, 41);
            this.btn_min.TabIndex = 4;
            this.btn_min.Text = "Minimum";
            this.btn_min.UseVisualStyleBackColor = true;
            this.btn_min.Click += new System.EventHandler(this.btn_min_Click);
            // 
            // btn_11
            // 
            this.btn_11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.btn_11.Location = new System.Drawing.Point(446, 47);
            this.btn_11.Name = "btn_11";
            this.btn_11.Size = new System.Drawing.Size(84, 41);
            this.btn_11.TabIndex = 3;
            this.btn_11.Text = "11";
            this.btn_11.UseVisualStyleBackColor = true;
            this.btn_11.Visible = false;
            this.btn_11.Click += new System.EventHandler(this.btn_11_Click);
            // 
            // btn_1
            // 
            this.btn_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.btn_1.Location = new System.Drawing.Point(284, 49);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(84, 41);
            this.btn_1.TabIndex = 2;
            this.btn_1.Text = "1";
            this.btn_1.UseVisualStyleBackColor = true;
            this.btn_1.Visible = false;
            this.btn_1.Click += new System.EventHandler(this.btn_1_Click);
            // 
            // lbl_szoveg18
            // 
            this.lbl_szoveg18.AutoSize = true;
            this.lbl_szoveg18.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.lbl_szoveg18.Location = new System.Drawing.Point(20, 47);
            this.lbl_szoveg18.Name = "lbl_szoveg18";
            this.lbl_szoveg18.Size = new System.Drawing.Size(120, 29);
            this.lbl_szoveg18.TabIndex = 0;
            this.lbl_szoveg18.Text = "Zsetonod:";
            // 
            // lbl_zsetonod
            // 
            this.lbl_zsetonod.AutoSize = true;
            this.lbl_zsetonod.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.lbl_zsetonod.Location = new System.Drawing.Point(146, 47);
            this.lbl_zsetonod.Name = "lbl_zsetonod";
            this.lbl_zsetonod.Size = new System.Drawing.Size(112, 29);
            this.lbl_zsetonod.TabIndex = 1;
            this.lbl_zsetonod.Text = "Zsetonok";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label1.Location = new System.Drawing.Point(615, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(75, 18);
            this.label1.TabIndex = 9;
            this.label1.Text = "Zsetonok:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label2.Location = new System.Drawing.Point(429, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 18);
            this.label2.TabIndex = 10;
            this.label2.Text = "Egyenleg:";
            // 
            // Blackjack
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gold;
            this.ClientSize = new System.Drawing.Size(1604, 939);
            this.Controls.Add(this.pnl_jatek);
            this.Controls.Add(this.pnl_kapkod);
            this.Controls.Add(this.pnl_egyenlegtolt);
            this.Controls.Add(this.pnl_zsetonvesz);
            this.Controls.Add(this.pnl_emailkod);
            this.Controls.Add(this.pnl_jelszocsere);
            this.Controls.Add(this.pnl_bankkartya);
            this.Controls.Add(this.pnl_regisztracio);
            this.Controls.Add(this.pnl_belepes);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1620, 980);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(1620, 980);
            this.Name = "Blackjack";
            this.Text = "Blackjack";
            this.pnl_belepes.ResumeLayout(false);
            this.pnl_belepes.PerformLayout();
            this.pnl_regisztracio.ResumeLayout(false);
            this.pnl_regisztracio.PerformLayout();
            this.pnl_bankkartya.ResumeLayout(false);
            this.pnl_bankkartya.PerformLayout();
            this.pnl_jelszocsere.ResumeLayout(false);
            this.pnl_jelszocsere.PerformLayout();
            this.pnl_emailkod.ResumeLayout(false);
            this.pnl_emailkod.PerformLayout();
            this.pnl_zsetonvesz.ResumeLayout(false);
            this.pnl_zsetonvesz.PerformLayout();
            this.pnl_egyenlegtolt.ResumeLayout(false);
            this.pnl_egyenlegtolt.PerformLayout();
            this.pnl_kapkod.ResumeLayout(false);
            this.pnl_kapkod.PerformLayout();
            this.pnl_jatek.ResumeLayout(false);
            this.pnl_jatek.PerformLayout();
            this.pnl_lap24.ResumeLayout(false);
            this.pnl_lap24.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin48)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin47)).EndInit();
            this.pnl_lap16.ResumeLayout(false);
            this.pnl_lap16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin31)).EndInit();
            this.pnl_lap8.ResumeLayout(false);
            this.pnl_lap8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin15)).EndInit();
            this.pnl_lap7.ResumeLayout(false);
            this.pnl_lap7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin13)).EndInit();
            this.pnl_lap15.ResumeLayout(false);
            this.pnl_lap15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin29)).EndInit();
            this.pnl_lap23.ResumeLayout(false);
            this.pnl_lap23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin46)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin45)).EndInit();
            this.pnl_lap22.ResumeLayout(false);
            this.pnl_lap22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin44)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin43)).EndInit();
            this.pnl_lap14.ResumeLayout(false);
            this.pnl_lap14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin28)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin27)).EndInit();
            this.pnl_lap6.ResumeLayout(false);
            this.pnl_lap6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin11)).EndInit();
            this.pnl_lap5.ResumeLayout(false);
            this.pnl_lap5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin9)).EndInit();
            this.pnl_lap13.ResumeLayout(false);
            this.pnl_lap13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin26)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin25)).EndInit();
            this.pnl_lap21.ResumeLayout(false);
            this.pnl_lap21.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin42)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin41)).EndInit();
            this.pnl_lap20.ResumeLayout(false);
            this.pnl_lap20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin40)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin39)).EndInit();
            this.pnl_lap12.ResumeLayout(false);
            this.pnl_lap12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin23)).EndInit();
            this.pnl_lap4.ResumeLayout(false);
            this.pnl_lap4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin7)).EndInit();
            this.pnl_lap3.ResumeLayout(false);
            this.pnl_lap3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin5)).EndInit();
            this.pnl_lap11.ResumeLayout(false);
            this.pnl_lap11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin21)).EndInit();
            this.pnl_lap19.ResumeLayout(false);
            this.pnl_lap19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin37)).EndInit();
            this.pnl_lap18.ResumeLayout(false);
            this.pnl_lap18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin36)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin35)).EndInit();
            this.pnl_lap10.ResumeLayout(false);
            this.pnl_lap10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin19)).EndInit();
            this.pnl_lap2.ResumeLayout(false);
            this.pnl_lap2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin3)).EndInit();
            this.pnl_lap9.ResumeLayout(false);
            this.pnl_lap9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin17)).EndInit();
            this.pnl_lap17.ResumeLayout(false);
            this.pnl_lap17.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin34)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin33)).EndInit();
            this.pnl_lap1.ResumeLayout(false);
            this.pnl_lap1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_lapszin1)).EndInit();
            this.pnl_iranypult.ResumeLayout(false);
            this.pnl_iranypult.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_belepes;
        private System.Windows.Forms.Button btn_regisztracio;
        private System.Windows.Forms.Button btn_elfelejt;
        private System.Windows.Forms.Label lbl_szoveg3;
        private System.Windows.Forms.Label lbl_szoveg2;
        private System.Windows.Forms.Label lbl_szoveg1;
        private System.Windows.Forms.TextBox tb_bejelszo;
        private System.Windows.Forms.TextBox tb_befelhasz;
        private System.Windows.Forms.Button btn_bezar;
        private System.Windows.Forms.Button btn_belepes;
        private System.Windows.Forms.Panel pnl_regisztracio;
        private System.Windows.Forms.Button btn_revissza;
        private System.Windows.Forms.Button btn_regisztralok;
        private System.Windows.Forms.CheckBox cb_nemrob;
        private System.Windows.Forms.CheckBox cb_hozzaad;
        private System.Windows.Forms.CheckBox cb_elfogad;
        private System.Windows.Forms.TextBox tb_reemail;
        private System.Windows.Forms.TextBox tb_rejelszoujra;
        private System.Windows.Forms.TextBox tb_rejelszo;
        private System.Windows.Forms.TextBox tb_refelhasz;
        private System.Windows.Forms.Label lbl_szoveg7;
        private System.Windows.Forms.Label lbl_szoveg5;
        private System.Windows.Forms.Label lbl_szoveg4;
        private System.Windows.Forms.Label lbl_szoveg6;
        private System.Windows.Forms.Panel pnl_bankkartya;
        private System.Windows.Forms.TextBox tb_lejarat;
        private System.Windows.Forms.TextBox tb_cvc;
        private System.Windows.Forms.TextBox tb_kartyaszam;
        private System.Windows.Forms.Button btn_hozzaad;
        private System.Windows.Forms.Label lbl_szoveg10;
        private System.Windows.Forms.Label lbl_szoveg9;
        private System.Windows.Forms.Label lbl_szoveg8;
        private System.Windows.Forms.Panel pnl_jelszocsere;
        private System.Windows.Forms.TextBox tb_csejelszoujra;
        private System.Windows.Forms.TextBox tb_csejelszo;
        private System.Windows.Forms.TextBox tb_emailkod;
        private System.Windows.Forms.Label lbl_szoveg13;
        private System.Windows.Forms.Label lbl_szoveg12;
        private System.Windows.Forms.Label lbl_szoveg11;
        private System.Windows.Forms.Button btn_csere;
        private System.Windows.Forms.Panel pnl_emailkod;
        private System.Windows.Forms.TextBox tb_emailbe;
        private System.Windows.Forms.Button btn_kovissza;
        private System.Windows.Forms.Button btn_emailker;
        private System.Windows.Forms.Label lbl_szoveg14;
        private System.Windows.Forms.Panel pnl_zsetonvesz;
        private System.Windows.Forms.Button btn_100000;
        private System.Windows.Forms.Button btn_10000;
        private System.Windows.Forms.Button btn_5000;
        private System.Windows.Forms.Button btn_1000;
        private System.Windows.Forms.RadioButton rb_100000;
        private System.Windows.Forms.RadioButton rb_10000;
        private System.Windows.Forms.RadioButton rb_5000;
        private System.Windows.Forms.RadioButton rb_1000;
        private System.Windows.Forms.Label lbl_zsetonmennyiseg;
        private System.Windows.Forms.Label lbl_egyenlegem;
        private System.Windows.Forms.Button btn_zsevissza;
        private System.Windows.Forms.Button btn_egyenlegtolt;
        private System.Windows.Forms.Button btn_megvesz;
        private System.Windows.Forms.Panel pnl_egyenlegtolt;
        private System.Windows.Forms.Button btn_toltes;
        private System.Windows.Forms.Button btn_egyvissza;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lbl_szoveg17;
        private System.Windows.Forms.Panel pnl_kapkod;
        private System.Windows.Forms.Label lbl_kapkod;
        private System.Windows.Forms.Label lbl_szoveg16;
        private System.Windows.Forms.Panel pnl_jatek;
        private System.Windows.Forms.Label lbl_zsetonod;
        private System.Windows.Forms.Label lbl_szoveg18;
        private System.Windows.Forms.Panel pnl_lap24;
        private System.Windows.Forms.Label lbl_lapert48;
        private System.Windows.Forms.PictureBox pb_lapszin48;
        private System.Windows.Forms.PictureBox pb_lapszin47;
        private System.Windows.Forms.Label lbl_lapert47;
        private System.Windows.Forms.Panel pnl_lap16;
        private System.Windows.Forms.Label lbl_lapert32;
        private System.Windows.Forms.PictureBox pb_lapszin32;
        private System.Windows.Forms.PictureBox pb_lapszin31;
        private System.Windows.Forms.Label lbl_lapert31;
        private System.Windows.Forms.Panel pnl_lap8;
        private System.Windows.Forms.Label lbl_lapert16;
        private System.Windows.Forms.PictureBox pb_lapszin16;
        private System.Windows.Forms.PictureBox pb_lapszin15;
        private System.Windows.Forms.Label lbl_lapert15;
        private System.Windows.Forms.Panel pnl_lap7;
        private System.Windows.Forms.Label lbl_lapert14;
        private System.Windows.Forms.PictureBox pb_lapszin14;
        private System.Windows.Forms.PictureBox pb_lapszin13;
        private System.Windows.Forms.Label lbl_lapert13;
        private System.Windows.Forms.Panel pnl_lap15;
        private System.Windows.Forms.Label lbl_lapert30;
        private System.Windows.Forms.PictureBox pb_lapszin30;
        private System.Windows.Forms.PictureBox pb_lapszin29;
        private System.Windows.Forms.Label lbl_lapert29;
        private System.Windows.Forms.Panel pnl_lap23;
        private System.Windows.Forms.Label lbl_lapert46;
        private System.Windows.Forms.PictureBox pb_lapszin46;
        private System.Windows.Forms.PictureBox pb_lapszin45;
        private System.Windows.Forms.Label lbl_lapert45;
        private System.Windows.Forms.Panel pnl_lap22;
        private System.Windows.Forms.Label lbl_lapert44;
        private System.Windows.Forms.PictureBox pb_lapszin44;
        private System.Windows.Forms.PictureBox pb_lapszin43;
        private System.Windows.Forms.Label lbl_lapert43;
        private System.Windows.Forms.Panel pnl_lap14;
        private System.Windows.Forms.Label lbl_lapert28;
        private System.Windows.Forms.PictureBox pb_lapszin28;
        private System.Windows.Forms.PictureBox pb_lapszin27;
        private System.Windows.Forms.Label lbl_lapert27;
        private System.Windows.Forms.Panel pnl_lap6;
        private System.Windows.Forms.Label lbl_lapert12;
        private System.Windows.Forms.PictureBox pb_lapszin12;
        private System.Windows.Forms.PictureBox pb_lapszin11;
        private System.Windows.Forms.Label lbl_lapert11;
        private System.Windows.Forms.Panel pnl_lap5;
        private System.Windows.Forms.Label lbl_lapert10;
        private System.Windows.Forms.PictureBox pb_lapszin10;
        private System.Windows.Forms.PictureBox pb_lapszin9;
        private System.Windows.Forms.Label lbl_lapert9;
        private System.Windows.Forms.Panel pnl_lap13;
        private System.Windows.Forms.Label lbl_lapert26;
        private System.Windows.Forms.PictureBox pb_lapszin26;
        private System.Windows.Forms.PictureBox pb_lapszin25;
        private System.Windows.Forms.Label lbl_lapert25;
        private System.Windows.Forms.Panel pnl_lap21;
        private System.Windows.Forms.Label lbl_lapert42;
        private System.Windows.Forms.PictureBox pb_lapszin42;
        private System.Windows.Forms.PictureBox pb_lapszin41;
        private System.Windows.Forms.Label lbl_lapert41;
        private System.Windows.Forms.Panel pnl_lap20;
        private System.Windows.Forms.Label lbl_lapert40;
        private System.Windows.Forms.PictureBox pb_lapszin40;
        private System.Windows.Forms.PictureBox pb_lapszin39;
        private System.Windows.Forms.Label lbl_lapert39;
        private System.Windows.Forms.Panel pnl_lap12;
        private System.Windows.Forms.Label lbl_lapert24;
        private System.Windows.Forms.PictureBox pb_lapszin24;
        private System.Windows.Forms.PictureBox pb_lapszin23;
        private System.Windows.Forms.Label lbl_lapert23;
        private System.Windows.Forms.Panel pnl_lap4;
        private System.Windows.Forms.Label lbl_lapert8;
        private System.Windows.Forms.PictureBox pb_lapszin8;
        private System.Windows.Forms.PictureBox pb_lapszin7;
        private System.Windows.Forms.Label lbl_lapert7;
        private System.Windows.Forms.Panel pnl_lap3;
        private System.Windows.Forms.Label lbl_lapert6;
        private System.Windows.Forms.PictureBox pb_lapszin6;
        private System.Windows.Forms.PictureBox pb_lapszin5;
        private System.Windows.Forms.Label lbl_lapert5;
        private System.Windows.Forms.Panel pnl_lap11;
        private System.Windows.Forms.Label lbl_lapert22;
        private System.Windows.Forms.PictureBox pb_lapszin22;
        private System.Windows.Forms.PictureBox pb_lapszin21;
        private System.Windows.Forms.Label lbl_lapert21;
        private System.Windows.Forms.Panel pnl_lap19;
        private System.Windows.Forms.Label lbl_lapert38;
        private System.Windows.Forms.PictureBox pb_lapszin38;
        private System.Windows.Forms.PictureBox pb_lapszin37;
        private System.Windows.Forms.Label lbl_lapert37;
        private System.Windows.Forms.Panel pnl_lap18;
        private System.Windows.Forms.Label lbl_lapert36;
        private System.Windows.Forms.PictureBox pb_lapszin36;
        private System.Windows.Forms.PictureBox pb_lapszin35;
        private System.Windows.Forms.Label lbl_lapert35;
        private System.Windows.Forms.Panel pnl_lap10;
        private System.Windows.Forms.Label lbl_lapert20;
        private System.Windows.Forms.PictureBox pb_lapszin20;
        private System.Windows.Forms.PictureBox pb_lapszin19;
        private System.Windows.Forms.Label lbl_lapert19;
        private System.Windows.Forms.Panel pnl_lap2;
        private System.Windows.Forms.Label lbl_lapert4;
        private System.Windows.Forms.PictureBox pb_lapszin4;
        private System.Windows.Forms.PictureBox pb_lapszin3;
        private System.Windows.Forms.Label lbl_lapert3;
        private System.Windows.Forms.Panel pnl_lap9;
        private System.Windows.Forms.Label lbl_lapert18;
        private System.Windows.Forms.PictureBox pb_lapszin18;
        private System.Windows.Forms.PictureBox pb_lapszin17;
        private System.Windows.Forms.Label lbl_lapert17;
        private System.Windows.Forms.Panel pnl_lap17;
        private System.Windows.Forms.Label lbl_lapert34;
        private System.Windows.Forms.PictureBox pb_lapszin34;
        private System.Windows.Forms.PictureBox pb_lapszin33;
        private System.Windows.Forms.Label lbl_lapert33;
        private System.Windows.Forms.Panel pnl_lap1;
        private System.Windows.Forms.Label lbl_lapert2;
        private System.Windows.Forms.PictureBox pb_lapszin2;
        private System.Windows.Forms.PictureBox pb_lapszin1;
        private System.Windows.Forms.Label lbl_lapert1;
        private System.Windows.Forms.Label lbl_playerert;
        private System.Windows.Forms.Label lbl_szoveg28;
        private System.Windows.Forms.Label lbl_szoveg27;
        private System.Windows.Forms.Label lbl_szoveg26;
        private System.Windows.Forms.Label lbl_osztoert;
        private System.Windows.Forms.Label lbl_szoveg25;
        private System.Windows.Forms.Label lbl_szoveg24;
        private System.Windows.Forms.Button btn_zsetonvesz;
        private System.Windows.Forms.Button btn_kilepes;
        private System.Windows.Forms.Button btn_betesz;
        private System.Windows.Forms.VScrollBar sb_egyeni;
        private System.Windows.Forms.Panel pnl_iranypult;
        private System.Windows.Forms.Label lbl_szoveg22;
        private System.Windows.Forms.Label lbl_szoveg23;
        private System.Windows.Forms.Label lbl_szoveg21;
        private System.Windows.Forms.Label lbl_szoveg20;
        private System.Windows.Forms.Label lbl_szoveg19;
        private System.Windows.Forms.Button btn_segit5;
        private System.Windows.Forms.Button btn_segit4;
        private System.Windows.Forms.Button btn_segit3;
        private System.Windows.Forms.Button btn_segit2;
        private System.Windows.Forms.Button btn_segit1;
        private System.Windows.Forms.Button btn_ismetles;
        private System.Windows.Forms.Button btn_egyeni;
        private System.Windows.Forms.Button btn_max;
        private System.Windows.Forms.Button btn_min;
        private System.Windows.Forms.Button btn_11;
        private System.Windows.Forms.Button btn_1;
        private System.Windows.Forms.Button btn_guest;
        private System.Windows.Forms.Label lbl_felezert;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}

