﻿namespace Memória_Melinda
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_kils = new System.Windows.Forms.Button();
            this.rb_SRAM = new System.Windows.Forms.RadioButton();
            this.rb_DRAM = new System.Windows.Forms.RadioButton();
            this.rb_PROM = new System.Windows.Forms.RadioButton();
            this.rb_EPROM = new System.Windows.Forms.RadioButton();
            this.Ismerteto = new System.Windows.Forms.ListBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.gb_RAM = new System.Windows.Forms.GroupBox();
            this.p_a2 = new System.Windows.Forms.Panel();
            this.p_tak2 = new System.Windows.Forms.Panel();
            this.p_s2 = new System.Windows.Forms.Panel();
            this.p_t2 = new System.Windows.Forms.Panel();
            this.p_f2 = new System.Windows.Forms.Panel();
            this.p_k1 = new System.Windows.Forms.Panel();
            this.p_a1 = new System.Windows.Forms.Panel();
            this.p_s1 = new System.Windows.Forms.Panel();
            this.p_f1 = new System.Windows.Forms.Panel();
            this.p_t1 = new System.Windows.Forms.Panel();
            this.p_k2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.p_tak1 = new System.Windows.Forms.Panel();
            this.lb_SRAM = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bt_has = new System.Windows.Forms.Button();
            this.lb_DRAM = new System.Windows.Forms.Label();
            this.gb_ROM = new System.Windows.Forms.GroupBox();
            this.p_a4 = new System.Windows.Forms.Panel();
            this.p_s4 = new System.Windows.Forms.Panel();
            this.p_f4 = new System.Windows.Forms.Panel();
            this.p_t4 = new System.Windows.Forms.Panel();
            this.p_k4 = new System.Windows.Forms.Panel();
            this.p_tak4 = new System.Windows.Forms.Panel();
            this.p_s3 = new System.Windows.Forms.Panel();
            this.p_a3 = new System.Windows.Forms.Panel();
            this.p_k3 = new System.Windows.Forms.Panel();
            this.p_f3 = new System.Windows.Forms.Panel();
            this.p_tak3 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.p_t3 = new System.Windows.Forms.Panel();
            this.bt_has2 = new System.Windows.Forms.Button();
            this.lb_EPROM = new System.Windows.Forms.Label();
            this.lb_PROM = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.gb_RAM.SuspendLayout();
            this.gb_ROM.SuspendLayout();
            this.SuspendLayout();
            // 
            // bt_kils
            // 
            this.bt_kils.BackColor = System.Drawing.Color.Salmon;
            this.bt_kils.Location = new System.Drawing.Point(197, 31);
            this.bt_kils.Name = "bt_kils";
            this.bt_kils.Size = new System.Drawing.Size(91, 37);
            this.bt_kils.TabIndex = 0;
            this.bt_kils.Text = "Ismerető";
            this.bt_kils.UseVisualStyleBackColor = false;
            this.bt_kils.Click += new System.EventHandler(this.button1_Click);
            // 
            // rb_SRAM
            // 
            this.rb_SRAM.AutoSize = true;
            this.rb_SRAM.BackColor = System.Drawing.Color.SandyBrown;
            this.rb_SRAM.Location = new System.Drawing.Point(19, 31);
            this.rb_SRAM.Name = "rb_SRAM";
            this.rb_SRAM.Size = new System.Drawing.Size(56, 17);
            this.rb_SRAM.TabIndex = 1;
            this.rb_SRAM.TabStop = true;
            this.rb_SRAM.Text = "SRAM";
            this.rb_SRAM.UseVisualStyleBackColor = false;
            // 
            // rb_DRAM
            // 
            this.rb_DRAM.AutoSize = true;
            this.rb_DRAM.BackColor = System.Drawing.Color.SandyBrown;
            this.rb_DRAM.Location = new System.Drawing.Point(18, 59);
            this.rb_DRAM.Name = "rb_DRAM";
            this.rb_DRAM.Size = new System.Drawing.Size(57, 17);
            this.rb_DRAM.TabIndex = 2;
            this.rb_DRAM.TabStop = true;
            this.rb_DRAM.Text = "DRAM";
            this.rb_DRAM.UseVisualStyleBackColor = false;
            // 
            // rb_PROM
            // 
            this.rb_PROM.AutoSize = true;
            this.rb_PROM.BackColor = System.Drawing.Color.SandyBrown;
            this.rb_PROM.Location = new System.Drawing.Point(108, 31);
            this.rb_PROM.Name = "rb_PROM";
            this.rb_PROM.Size = new System.Drawing.Size(57, 17);
            this.rb_PROM.TabIndex = 3;
            this.rb_PROM.TabStop = true;
            this.rb_PROM.Text = "PROM";
            this.rb_PROM.UseVisualStyleBackColor = false;
            // 
            // rb_EPROM
            // 
            this.rb_EPROM.AutoSize = true;
            this.rb_EPROM.BackColor = System.Drawing.Color.SandyBrown;
            this.rb_EPROM.Location = new System.Drawing.Point(108, 59);
            this.rb_EPROM.Name = "rb_EPROM";
            this.rb_EPROM.Size = new System.Drawing.Size(67, 17);
            this.rb_EPROM.TabIndex = 4;
            this.rb_EPROM.TabStop = true;
            this.rb_EPROM.Text = "EPROM ";
            this.rb_EPROM.UseVisualStyleBackColor = false;
            // 
            // Ismerteto
            // 
            this.Ismerteto.FormattingEnabled = true;
            this.Ismerteto.Location = new System.Drawing.Point(294, 19);
            this.Ismerteto.Name = "Ismerteto";
            this.Ismerteto.Size = new System.Drawing.Size(396, 69);
            this.Ismerteto.TabIndex = 5;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.gb_RAM);
            this.groupBox1.Controls.Add(this.gb_ROM);
            this.groupBox1.Controls.Add(this.rb_EPROM);
            this.groupBox1.Controls.Add(this.Ismerteto);
            this.groupBox1.Controls.Add(this.bt_kils);
            this.groupBox1.Controls.Add(this.rb_SRAM);
            this.groupBox1.Controls.Add(this.rb_PROM);
            this.groupBox1.Controls.Add(this.rb_DRAM);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(697, 653);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Ismertető";
            // 
            // gb_RAM
            // 
            this.gb_RAM.BackColor = System.Drawing.Color.Ivory;
            this.gb_RAM.Controls.Add(this.p_a2);
            this.gb_RAM.Controls.Add(this.p_tak2);
            this.gb_RAM.Controls.Add(this.p_s2);
            this.gb_RAM.Controls.Add(this.p_t2);
            this.gb_RAM.Controls.Add(this.p_f2);
            this.gb_RAM.Controls.Add(this.p_k1);
            this.gb_RAM.Controls.Add(this.p_a1);
            this.gb_RAM.Controls.Add(this.p_s1);
            this.gb_RAM.Controls.Add(this.p_f1);
            this.gb_RAM.Controls.Add(this.p_t1);
            this.gb_RAM.Controls.Add(this.p_k2);
            this.gb_RAM.Controls.Add(this.label6);
            this.gb_RAM.Controls.Add(this.label5);
            this.gb_RAM.Controls.Add(this.label4);
            this.gb_RAM.Controls.Add(this.label3);
            this.gb_RAM.Controls.Add(this.label2);
            this.gb_RAM.Controls.Add(this.p_tak1);
            this.gb_RAM.Controls.Add(this.lb_SRAM);
            this.gb_RAM.Controls.Add(this.label1);
            this.gb_RAM.Controls.Add(this.bt_has);
            this.gb_RAM.Controls.Add(this.lb_DRAM);
            this.gb_RAM.Location = new System.Drawing.Point(6, 101);
            this.gb_RAM.Name = "gb_RAM";
            this.gb_RAM.Size = new System.Drawing.Size(666, 260);
            this.gb_RAM.TabIndex = 16;
            this.gb_RAM.TabStop = false;
            this.gb_RAM.Text = "RAM";
            // 
            // p_a2
            // 
            this.p_a2.Location = new System.Drawing.Point(342, 232);
            this.p_a2.Name = "p_a2";
            this.p_a2.Size = new System.Drawing.Size(194, 20);
            this.p_a2.TabIndex = 27;
            // 
            // p_tak2
            // 
            this.p_tak2.Location = new System.Drawing.Point(342, 62);
            this.p_tak2.Name = "p_tak2";
            this.p_tak2.Size = new System.Drawing.Size(194, 20);
            this.p_tak2.TabIndex = 24;
            // 
            // p_s2
            // 
            this.p_s2.Location = new System.Drawing.Point(342, 198);
            this.p_s2.Name = "p_s2";
            this.p_s2.Size = new System.Drawing.Size(194, 20);
            this.p_s2.TabIndex = 19;
            // 
            // p_t2
            // 
            this.p_t2.Location = new System.Drawing.Point(342, 127);
            this.p_t2.Name = "p_t2";
            this.p_t2.Size = new System.Drawing.Size(194, 20);
            this.p_t2.TabIndex = 19;
            // 
            // p_f2
            // 
            this.p_f2.Location = new System.Drawing.Point(342, 161);
            this.p_f2.Name = "p_f2";
            this.p_f2.Size = new System.Drawing.Size(194, 20);
            this.p_f2.TabIndex = 26;
            // 
            // p_k1
            // 
            this.p_k1.Location = new System.Drawing.Point(124, 95);
            this.p_k1.Name = "p_k1";
            this.p_k1.Size = new System.Drawing.Size(194, 20);
            this.p_k1.TabIndex = 25;
            // 
            // p_a1
            // 
            this.p_a1.Location = new System.Drawing.Point(124, 232);
            this.p_a1.Name = "p_a1";
            this.p_a1.Size = new System.Drawing.Size(194, 20);
            this.p_a1.TabIndex = 23;
            // 
            // p_s1
            // 
            this.p_s1.Location = new System.Drawing.Point(124, 198);
            this.p_s1.Name = "p_s1";
            this.p_s1.Size = new System.Drawing.Size(194, 20);
            this.p_s1.TabIndex = 22;
            // 
            // p_f1
            // 
            this.p_f1.Location = new System.Drawing.Point(124, 161);
            this.p_f1.Name = "p_f1";
            this.p_f1.Size = new System.Drawing.Size(194, 20);
            this.p_f1.TabIndex = 0;
            // 
            // p_t1
            // 
            this.p_t1.Location = new System.Drawing.Point(124, 127);
            this.p_t1.Name = "p_t1";
            this.p_t1.Size = new System.Drawing.Size(194, 20);
            this.p_t1.TabIndex = 18;
            // 
            // p_k2
            // 
            this.p_k2.Location = new System.Drawing.Point(342, 95);
            this.p_k2.Name = "p_k2";
            this.p_k2.Size = new System.Drawing.Size(194, 20);
            this.p_k2.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 232);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "Ár:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(14, 198);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "Sebesség:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 13);
            this.label4.TabIndex = 19;
            this.label4.Text = "Felejtés:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 127);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 18;
            this.label3.Text = "Törlés:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Kategória:";
            // 
            // p_tak1
            // 
            this.p_tak1.Location = new System.Drawing.Point(124, 62);
            this.p_tak1.Name = "p_tak1";
            this.p_tak1.Size = new System.Drawing.Size(194, 20);
            this.p_tak1.TabIndex = 18;
            // 
            // lb_SRAM
            // 
            this.lb_SRAM.BackColor = System.Drawing.Color.Gold;
            this.lb_SRAM.Location = new System.Drawing.Point(188, 24);
            this.lb_SRAM.Name = "lb_SRAM";
            this.lb_SRAM.Size = new System.Drawing.Size(59, 24);
            this.lb_SRAM.TabIndex = 8;
            this.lb_SRAM.Text = "SRAM";
            this.lb_SRAM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 13);
            this.label1.TabIndex = 15;
            this.label1.Text = "Tárolókapacitás:";
            // 
            // bt_has
            // 
            this.bt_has.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.bt_has.AutoSize = true;
            this.bt_has.BackColor = System.Drawing.Color.Salmon;
            this.bt_has.Location = new System.Drawing.Point(551, 62);
            this.bt_has.Name = "bt_has";
            this.bt_has.Size = new System.Drawing.Size(93, 168);
            this.bt_has.TabIndex = 12;
            this.bt_has.Text = "Összehasonlít";
            this.bt_has.UseVisualStyleBackColor = false;
            this.bt_has.Click += new System.EventHandler(this.bt_has_Click);
            // 
            // lb_DRAM
            // 
            this.lb_DRAM.BackColor = System.Drawing.Color.Gold;
            this.lb_DRAM.Location = new System.Drawing.Point(419, 24);
            this.lb_DRAM.Name = "lb_DRAM";
            this.lb_DRAM.Size = new System.Drawing.Size(50, 24);
            this.lb_DRAM.TabIndex = 9;
            this.lb_DRAM.Text = "DRAM";
            this.lb_DRAM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gb_ROM
            // 
            this.gb_ROM.BackColor = System.Drawing.Color.Ivory;
            this.gb_ROM.Controls.Add(this.p_a4);
            this.gb_ROM.Controls.Add(this.p_s4);
            this.gb_ROM.Controls.Add(this.p_f4);
            this.gb_ROM.Controls.Add(this.p_t4);
            this.gb_ROM.Controls.Add(this.p_k4);
            this.gb_ROM.Controls.Add(this.p_tak4);
            this.gb_ROM.Controls.Add(this.p_s3);
            this.gb_ROM.Controls.Add(this.p_a3);
            this.gb_ROM.Controls.Add(this.p_k3);
            this.gb_ROM.Controls.Add(this.p_f3);
            this.gb_ROM.Controls.Add(this.p_tak3);
            this.gb_ROM.Controls.Add(this.label12);
            this.gb_ROM.Controls.Add(this.label11);
            this.gb_ROM.Controls.Add(this.label10);
            this.gb_ROM.Controls.Add(this.label9);
            this.gb_ROM.Controls.Add(this.label8);
            this.gb_ROM.Controls.Add(this.label7);
            this.gb_ROM.Controls.Add(this.p_t3);
            this.gb_ROM.Controls.Add(this.bt_has2);
            this.gb_ROM.Controls.Add(this.lb_EPROM);
            this.gb_ROM.Controls.Add(this.lb_PROM);
            this.gb_ROM.Location = new System.Drawing.Point(6, 367);
            this.gb_ROM.Name = "gb_ROM";
            this.gb_ROM.Size = new System.Drawing.Size(666, 278);
            this.gb_ROM.TabIndex = 17;
            this.gb_ROM.TabStop = false;
            this.gb_ROM.Text = "ROM";
            // 
            // p_a4
            // 
            this.p_a4.Location = new System.Drawing.Point(342, 246);
            this.p_a4.Name = "p_a4";
            this.p_a4.Size = new System.Drawing.Size(194, 20);
            this.p_a4.TabIndex = 31;
            // 
            // p_s4
            // 
            this.p_s4.Location = new System.Drawing.Point(342, 205);
            this.p_s4.Name = "p_s4";
            this.p_s4.Size = new System.Drawing.Size(194, 20);
            this.p_s4.TabIndex = 32;
            // 
            // p_f4
            // 
            this.p_f4.Location = new System.Drawing.Point(342, 171);
            this.p_f4.Name = "p_f4";
            this.p_f4.Size = new System.Drawing.Size(194, 20);
            this.p_f4.TabIndex = 30;
            // 
            // p_t4
            // 
            this.p_t4.Location = new System.Drawing.Point(342, 132);
            this.p_t4.Name = "p_t4";
            this.p_t4.Size = new System.Drawing.Size(194, 20);
            this.p_t4.TabIndex = 20;
            // 
            // p_k4
            // 
            this.p_k4.Location = new System.Drawing.Point(342, 95);
            this.p_k4.Name = "p_k4";
            this.p_k4.Size = new System.Drawing.Size(194, 20);
            this.p_k4.TabIndex = 29;
            // 
            // p_tak4
            // 
            this.p_tak4.Location = new System.Drawing.Point(342, 62);
            this.p_tak4.Name = "p_tak4";
            this.p_tak4.Size = new System.Drawing.Size(194, 20);
            this.p_tak4.TabIndex = 28;
            // 
            // p_s3
            // 
            this.p_s3.Location = new System.Drawing.Point(124, 205);
            this.p_s3.Name = "p_s3";
            this.p_s3.Size = new System.Drawing.Size(194, 20);
            this.p_s3.TabIndex = 27;
            // 
            // p_a3
            // 
            this.p_a3.Location = new System.Drawing.Point(124, 246);
            this.p_a3.Name = "p_a3";
            this.p_a3.Size = new System.Drawing.Size(194, 20);
            this.p_a3.TabIndex = 26;
            // 
            // p_k3
            // 
            this.p_k3.Location = new System.Drawing.Point(124, 95);
            this.p_k3.Name = "p_k3";
            this.p_k3.Size = new System.Drawing.Size(194, 20);
            this.p_k3.TabIndex = 19;
            // 
            // p_f3
            // 
            this.p_f3.Location = new System.Drawing.Point(124, 170);
            this.p_f3.Name = "p_f3";
            this.p_f3.Size = new System.Drawing.Size(194, 20);
            this.p_f3.TabIndex = 19;
            // 
            // p_tak3
            // 
            this.p_tak3.Location = new System.Drawing.Point(124, 62);
            this.p_tak3.Name = "p_tak3";
            this.p_tak3.Size = new System.Drawing.Size(194, 20);
            this.p_tak3.TabIndex = 19;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(19, 205);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(57, 13);
            this.label12.TabIndex = 25;
            this.label12.Text = "Sebesség:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 246);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 13);
            this.label11.TabIndex = 24;
            this.label11.Text = "Ár:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 171);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(46, 13);
            this.label10.TabIndex = 23;
            this.label10.Text = "Felejtés:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 132);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(39, 13);
            this.label9.TabIndex = 22;
            this.label9.Text = "Törlés:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 95);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 13);
            this.label8.TabIndex = 21;
            this.label8.Text = "Kategória:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 62);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "Tárolókapacitás:";
            // 
            // p_t3
            // 
            this.p_t3.Location = new System.Drawing.Point(124, 132);
            this.p_t3.Name = "p_t3";
            this.p_t3.Size = new System.Drawing.Size(194, 20);
            this.p_t3.TabIndex = 19;
            // 
            // bt_has2
            // 
            this.bt_has2.BackColor = System.Drawing.Color.Salmon;
            this.bt_has2.Location = new System.Drawing.Point(551, 73);
            this.bt_has2.Name = "bt_has2";
            this.bt_has2.Size = new System.Drawing.Size(93, 168);
            this.bt_has2.TabIndex = 13;
            this.bt_has2.Text = "Összehasonlít";
            this.bt_has2.UseVisualStyleBackColor = false;
            this.bt_has2.Click += new System.EventHandler(this.bt_has2_Click);
            // 
            // lb_EPROM
            // 
            this.lb_EPROM.BackColor = System.Drawing.Color.Gold;
            this.lb_EPROM.Location = new System.Drawing.Point(410, 26);
            this.lb_EPROM.Name = "lb_EPROM";
            this.lb_EPROM.Size = new System.Drawing.Size(59, 24);
            this.lb_EPROM.TabIndex = 11;
            this.lb_EPROM.Text = "EPROM";
            this.lb_EPROM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lb_PROM
            // 
            this.lb_PROM.BackColor = System.Drawing.Color.Gold;
            this.lb_PROM.Location = new System.Drawing.Point(188, 26);
            this.lb_PROM.Name = "lb_PROM";
            this.lb_PROM.Size = new System.Drawing.Size(59, 24);
            this.lb_PROM.TabIndex = 10;
            this.lb_PROM.Text = "PROM";
            this.lb_PROM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(714, 668);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "Form1";
            this.Text = "Memória";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gb_RAM.ResumeLayout(false);
            this.gb_RAM.PerformLayout();
            this.gb_ROM.ResumeLayout(false);
            this.gb_ROM.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bt_kils;
        private System.Windows.Forms.RadioButton rb_SRAM;
        private System.Windows.Forms.RadioButton rb_DRAM;
        private System.Windows.Forms.RadioButton rb_PROM;
        private System.Windows.Forms.RadioButton rb_EPROM;
        private System.Windows.Forms.ListBox Ismerteto;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lb_SRAM;
        private System.Windows.Forms.Label lb_DRAM;
        private System.Windows.Forms.Label lb_PROM;
        private System.Windows.Forms.Label lb_EPROM;
        private System.Windows.Forms.Button bt_has;
        private System.Windows.Forms.Button bt_has2;
        private System.Windows.Forms.GroupBox gb_RAM;
        private System.Windows.Forms.GroupBox gb_ROM;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel p_tak1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel p_k2;
        private System.Windows.Forms.Panel p_a1;
        private System.Windows.Forms.Panel p_s1;
        private System.Windows.Forms.Panel p_f1;
        private System.Windows.Forms.Panel p_t1;
        private System.Windows.Forms.Panel p_s3;
        private System.Windows.Forms.Panel p_a3;
        private System.Windows.Forms.Panel p_k3;
        private System.Windows.Forms.Panel p_f3;
        private System.Windows.Forms.Panel p_tak3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel p_t3;
        private System.Windows.Forms.Panel p_a2;
        private System.Windows.Forms.Panel p_s2;
        private System.Windows.Forms.Panel p_t2;
        private System.Windows.Forms.Panel p_f2;
        private System.Windows.Forms.Panel p_k1;
        private System.Windows.Forms.Panel p_tak2;
        private System.Windows.Forms.Panel p_s4;
        private System.Windows.Forms.Panel p_a4;
        private System.Windows.Forms.Panel p_f4;
        private System.Windows.Forms.Panel p_t4;
        private System.Windows.Forms.Panel p_k4;
        private System.Windows.Forms.Panel p_tak4;
    }
}

