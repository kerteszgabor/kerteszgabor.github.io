﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memória_Melinda
{
    class RAM : Memoria
    {

        public RAM(int tarolokap,string kategoria, string torles,string felejtes, string sebesseg, string ar) : base(tarolokap, kategoria, torles,felejtes,sebesseg,ar)
        {

        }


   
    }
}
