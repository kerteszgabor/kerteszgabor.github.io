﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// 2017. októberi középszintű ágazati érettségi programozás feladatának megoldása
// Készítette: Kertész Gábor

namespace Egyszamjatek
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Jatekos> jatekosok = new List<Jatekos>();
            Beolvas("egyszamjatek.txt", jatekosok);         // lista feltöltése beolvasott adatokkal

            Console.WriteLine("3. feladat: Játékosok száma: " + jatekosok.Count);

            Console.WriteLine("4. feladat: Fordulók száma: " + jatekosok.First().Eredmenyek.Count); // mivel mindenki részt vett minden fordulóban,
                                                                                                    // ezért bármelyik ember tippjeinek számát vizsgálhatjuk
            // 5-ös feladat
            bool voltEgyes = jatekosok.Select(x => x.Eredmenyek.First()).Contains(1);  // kiválogatjuk az első forduló eredményét (ez mindenkinél az első szám)
            if (voltEgyes)                                                             // majd megnézzük, hogy ebben az "első oszlopban" van-e egyes
            {
                Console.WriteLine("5. feladat: volt egyes!");
            }
            else
            {
                Console.WriteLine("5. feladat: nem volt egyes!");
            }

            int legagyobbTipp = jatekosok.SelectMany(x => x.Eredmenyek).Max();    // .SelectMany operátor: "kilapítja" a listákat. Tehát, ha van egy listám, amiben olyan elemek vannak,
            Console.WriteLine("6. feladat: legnagyobb tipp: " + legagyobbTipp);   // melyek maguk is egy listát tartalmaznak, akkor megkaphatjuk az "al-listák" elemeit egy közös listában

            Console.Write($"7. feladat: kérem egy forduló sorszámát [1-{jatekosok.Count+1}]: ");
            try
            {
                int forduloSorszama = int.Parse(Console.ReadLine());
                int gyoztesTipp = GyoztesTipp(jatekosok, forduloSorszama);  // győztes tipp kiértékelése, működést lásd lejjebb
                if (gyoztesTipp != -1)  // tehát volt győztes tipp
                {
                    Console.WriteLine($"8. feladat: győztes a tipp a {forduloSorszama}. fordulóban: {gyoztesTipp}");
                    string gyoztesNeve = jatekosok.Where(x => x.Eredmenyek[forduloSorszama - 1] == gyoztesTipp).FirstOrDefault().Nev; // kikeresem, hogy a fordulóban "ki adta le" a győztes tippet
                    Console.WriteLine($"A győztes neve: {gyoztesNeve}");
                    KiirFajlba(forduloSorszama, gyoztesNeve, gyoztesTipp);  // fájlba írás, minta szerint
                }
                else
                {
                    Console.WriteLine($"8. feladat: nem volt győztes tipp a {forduloSorszama}. fordulóban.");
                }
            }
            catch (IndexOutOfRangeException)
            {
                Console.WriteLine("Megadott sorszámmal nem található forduló!");
            }
            catch (FormatException)
            {
                Console.WriteLine("Hibás beviteli formátum, kérlek, hogy csak egész számot adj meg!");
            }

            Console.ReadLine();
        }

        static void Beolvas(string fajl, List<Jatekos> jatekosok)
        {
            if (File.Exists(fajl))
            {
                StreamReader f = File.OpenText(fajl);
                while (!f.EndOfStream)
                {
                    string[] darabolt = f.ReadLine().Split(' ');
                    int i = 0;
                    Jatekos jatekos = new Jatekos();
                    jatekos.Eredmenyek = new List<int>();           // belső tulajdonságokat is példányosítsuk, különben NULL reference hiba állhat elő, annak ellenére, hogy fordul a kód!

                    while (i < darabolt.Length)                                 // addig olvasok, míg van elem a beolvasott tömbben
                    {
                        if (Char.IsDigit(darabolt[i][0]))                       // probléma: nem tudom meddig tartanak a számok, mikor jön az utolsó adat, a név
                        {
                            jatekos.Eredmenyek.Add(int.Parse(darabolt[i]));     // megoldás: ha az aktuális adat első karaktere szám (Char.IsDigit()), akkor az biztosan egy tipp
                        }
                        else
                        {
                            jatekos.Nev = darabolt[i];
                        }
                        ++i;                                                    // ciklusváltozót kézzel léptetem
                    }
                    jatekosok.Add(jatekos);                                     // az új játékost hozzáadom a listához, amikor végeztem az adatainak feldolgozásával
                }
            }
            else
            {
                Console.WriteLine("Nincs fájl");
            }
        }

        // megadja egy forduló sorszáma alapján, hogy mi volt a győztes tipp abban a fordulóban
        static int GyoztesTipp(List<Jatekos> jatekosok, int forduloSorszama)
        {
            List<int> forduloEredmenyei = new List<int>();
            try
            {
                forduloEredmenyei = jatekosok.Select(x => x.Eredmenyek[forduloSorszama - 1]).ToList(); // bekért számnak megfelelő forduló kiválasztása, lásd ötös feladat
            }
            catch (Exception)
            {
                throw new IndexOutOfRangeException();      // ha kivétel keletkezik, nem foglalkozunk vele, feljebb dobjuk, main metódus kezeli azt
            }

            forduloEredmenyei = forduloEredmenyei.OrderBy(x => x).ToList();                                      // rendezés növekvő sorrendbe, hiszen a legkisebb egyedi tippet keressük
            foreach (var item in forduloEredmenyei)
            {
                var elofordulasokSzama = forduloEredmenyei.Where(x => x == item).Count();       // minden "kicsi" tipphez megvizsgáljuk, hogy ő egyedül áll-e a tippek sorozatában
                if (elofordulasokSzama == 1)                                                    // ha igen --> megtaláltuk a legkisebb egyedi, tehát győztes tippet,
                {                                                                               
                    return item;                                                                // kilépünk, visszaadjuk azt
                }
            }
            return -1;                                                                          // ha végigértünk a listán, de nem volt győztes tipp, jelezzük -1 értékkel azt (hiszen ilyen forduló nem lehet)
        }

        static void KiirFajlba(int forduloSzama, string gyoztesNeve, int gyoztesTipp)
        {
            StreamWriter r = new StreamWriter("nyertes.txt");
            r.WriteLine($"Forduló sorszáma: {forduloSzama}");
            r.WriteLine($"Nyertes tipp: {gyoztesTipp}");
            r.WriteLine($"Nyertes játékos: {gyoztesNeve}");
            r.Close();
        }
    }

    // csak adattárolásra szolgáló, ún. "DTO osztály"
    class Jatekos
    {
        public string Nev { get; set; }

        public List<int> Eredmenyek { get; set; }
    }
}
