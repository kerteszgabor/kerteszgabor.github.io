﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AlkotoB
{
    public partial class Form1 : Form
    {
        List<Alkoto> alkotok = new List<Alkoto>();
        public Form1()
        {
            InitializeComponent();
        }

        void Beolvas(string fajl)
        {
            if (File.Exists(fajl))
            {
                StreamReader f = new StreamReader(fajl);
                Alkoto seged = null;
                int i = 0;

                while (!f.EndOfStream)
                {
                    if (i % 2 == 0)
                    {
                        seged = new Alkoto();
                        seged.Nev = f.ReadLine();
                    }
                    else
                    {
                        string[] darabolt = f.ReadLine().Split(' ');
                        seged.Ervenytelen = int.Parse(darabolt[0]);
                        seged.Ervenyes = int.Parse(darabolt[1]);
                        alkotok.Add(seged);
                    }
                    ++i;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Beolvas("alkoto.txt");
            alkotok.ForEach(alkoto => listBox1.Items.Add(alkoto));
        }

        private void rb_osszes_ervenyes_CheckedChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            int szavazatokSzama = alkotok.Sum(x => x.Ervenyes);
            listBox2.Items.Add($"Érvényes szavazatok száma összesen: {szavazatokSzama}");
        }

        private void rb_ervenytelenek_CheckedChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            double ervenytelenSzavazatok = alkotok.Sum(x => x.Ervenytelen);
            double eredmeny = ervenytelenSzavazatok / alkotok.Count;
            listBox2.Items.Add($"Érvénytelen szavazatok átlagban: {eredmeny}");
        }

        private void rb_nyertes_CheckedChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            var nyertesSzavazat = alkotok.Select(x => x.Ervenyes).Max();
            Alkoto nyertesAlkoto = alkotok.Where(x => x.Ervenyes == nyertesSzavazat).FirstOrDefault();
            listBox2.Items.Add($"Nyertes emberke: {nyertesAlkoto}");
        }

        private void rb_tizneltobb_ervenytelen_CheckedChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            bool vanilyen = alkotok.Any(x => x.Ervenytelen > 10);
            if (vanilyen)
            {
                listBox2.Items.Add("Volt tíznél több érvénytelen szavazatot kapó szemnély!");
                Alkoto vesztes = alkotok.Where(x => x.Ervenytelen > 10).FirstOrDefault();
                listBox2.Items.Add(vesztes);
            }
            else
            {
                listBox2.Items.Add("Nincs ilyen versenyző!");
            }
        }

        private void rb_nemkapott_ervenytelent_CheckedChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            var nemKapottErvenytelent = alkotok.Where(x => x.Ervenytelen == 0).ToList();
            var legtobbSzavazat = nemKapottErvenytelent.Select(x => x.Ervenyes).Max();
            Alkoto alkoto = alkotok.Where(x => x.Ervenyes == legtobbSzavazat).FirstOrDefault();
            listBox2.Items.Add(alkoto);
        }

        private void rb_otvennelTobb_CheckedChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            var otvennelTobb = alkotok.Where(x => x.Ervenyes > 50);
            foreach (var item in otvennelTobb)
            {
                listBox2.Items.Add(item);
            }
        }

        private void rb_csokkenoSorrend_CheckedChanged(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            var newList = alkotok.OrderByDescending(x => x.Ervenyes);
            foreach (var item in newList)
            {
                listBox2.Items.Add(item);
            }
        }
    }

    class Alkoto
    {
        public string Nev { get; set; }
        public int Ervenyes { get; set; }
        public int Ervenytelen { get; set; }

        public override string ToString()
        {
            return $"{Nev}, Érvényes: {Ervenyes}, Érvénytelen: {Ervenytelen}";
        }
    }
}
