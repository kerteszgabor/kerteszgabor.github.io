﻿namespace AlkotoB
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.rb_osszes_ervenyes = new System.Windows.Forms.RadioButton();
            this.rb_ervenytelenek = new System.Windows.Forms.RadioButton();
            this.rb_nyertes = new System.Windows.Forms.RadioButton();
            this.rb_tizneltobb_ervenytelen = new System.Windows.Forms.RadioButton();
            this.rb_nemkapott_ervenytelent = new System.Windows.Forms.RadioButton();
            this.rb_otvennelTobb = new System.Windows.Forms.RadioButton();
            this.rb_csokkenoSorrend = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 12);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(275, 329);
            this.listBox1.TabIndex = 0;
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(823, 12);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(286, 329);
            this.listBox2.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(97, 372);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 2;
            this.button1.Text = "Beolvas";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // rb_osszes_ervenyes
            // 
            this.rb_osszes_ervenyes.AutoSize = true;
            this.rb_osszes_ervenyes.Location = new System.Drawing.Point(373, 66);
            this.rb_osszes_ervenyes.Name = "rb_osszes_ervenyes";
            this.rb_osszes_ervenyes.Size = new System.Drawing.Size(121, 17);
            this.rb_osszes_ervenyes.TabIndex = 3;
            this.rb_osszes_ervenyes.TabStop = true;
            this.rb_osszes_ervenyes.Text = "rb_osszes_ervenyes";
            this.rb_osszes_ervenyes.UseVisualStyleBackColor = true;
            this.rb_osszes_ervenyes.CheckedChanged += new System.EventHandler(this.rb_osszes_ervenyes_CheckedChanged);
            // 
            // rb_ervenytelenek
            // 
            this.rb_ervenytelenek.AutoSize = true;
            this.rb_ervenytelenek.Location = new System.Drawing.Point(373, 107);
            this.rb_ervenytelenek.Name = "rb_ervenytelenek";
            this.rb_ervenytelenek.Size = new System.Drawing.Size(107, 17);
            this.rb_ervenytelenek.TabIndex = 4;
            this.rb_ervenytelenek.TabStop = true;
            this.rb_ervenytelenek.Text = "rb_ervenytelenek";
            this.rb_ervenytelenek.UseVisualStyleBackColor = true;
            this.rb_ervenytelenek.CheckedChanged += new System.EventHandler(this.rb_ervenytelenek_CheckedChanged);
            // 
            // rb_nyertes
            // 
            this.rb_nyertes.AutoSize = true;
            this.rb_nyertes.Location = new System.Drawing.Point(373, 151);
            this.rb_nyertes.Name = "rb_nyertes";
            this.rb_nyertes.Size = new System.Drawing.Size(74, 17);
            this.rb_nyertes.TabIndex = 5;
            this.rb_nyertes.TabStop = true;
            this.rb_nyertes.Text = "rb_nyertes";
            this.rb_nyertes.UseVisualStyleBackColor = true;
            this.rb_nyertes.CheckedChanged += new System.EventHandler(this.rb_nyertes_CheckedChanged);
            // 
            // rb_tizneltobb_ervenytelen
            // 
            this.rb_tizneltobb_ervenytelen.AutoSize = true;
            this.rb_tizneltobb_ervenytelen.Location = new System.Drawing.Point(373, 188);
            this.rb_tizneltobb_ervenytelen.Name = "rb_tizneltobb_ervenytelen";
            this.rb_tizneltobb_ervenytelen.Size = new System.Drawing.Size(146, 17);
            this.rb_tizneltobb_ervenytelen.TabIndex = 6;
            this.rb_tizneltobb_ervenytelen.TabStop = true;
            this.rb_tizneltobb_ervenytelen.Text = "rb_tizneltobb_ervenytelen";
            this.rb_tizneltobb_ervenytelen.UseVisualStyleBackColor = true;
            this.rb_tizneltobb_ervenytelen.CheckedChanged += new System.EventHandler(this.rb_tizneltobb_ervenytelen_CheckedChanged);
            // 
            // rb_nemkapott_ervenytelent
            // 
            this.rb_nemkapott_ervenytelent.AutoSize = true;
            this.rb_nemkapott_ervenytelent.Location = new System.Drawing.Point(373, 225);
            this.rb_nemkapott_ervenytelent.Name = "rb_nemkapott_ervenytelent";
            this.rb_nemkapott_ervenytelent.Size = new System.Drawing.Size(154, 17);
            this.rb_nemkapott_ervenytelent.TabIndex = 7;
            this.rb_nemkapott_ervenytelent.TabStop = true;
            this.rb_nemkapott_ervenytelent.Text = "rb_nemkapott_ervenytelent";
            this.rb_nemkapott_ervenytelent.UseVisualStyleBackColor = true;
            this.rb_nemkapott_ervenytelent.CheckedChanged += new System.EventHandler(this.rb_nemkapott_ervenytelent_CheckedChanged);
            // 
            // rb_otvennelTobb
            // 
            this.rb_otvennelTobb.AutoSize = true;
            this.rb_otvennelTobb.Location = new System.Drawing.Point(373, 269);
            this.rb_otvennelTobb.Name = "rb_otvennelTobb";
            this.rb_otvennelTobb.Size = new System.Drawing.Size(106, 17);
            this.rb_otvennelTobb.TabIndex = 8;
            this.rb_otvennelTobb.TabStop = true;
            this.rb_otvennelTobb.Text = "rb_otvennelTobb";
            this.rb_otvennelTobb.UseVisualStyleBackColor = true;
            this.rb_otvennelTobb.CheckedChanged += new System.EventHandler(this.rb_otvennelTobb_CheckedChanged);
            // 
            // rb_csokkenoSorrend
            // 
            this.rb_csokkenoSorrend.AutoSize = true;
            this.rb_csokkenoSorrend.Location = new System.Drawing.Point(373, 309);
            this.rb_csokkenoSorrend.Name = "rb_csokkenoSorrend";
            this.rb_csokkenoSorrend.Size = new System.Drawing.Size(124, 17);
            this.rb_csokkenoSorrend.TabIndex = 9;
            this.rb_csokkenoSorrend.TabStop = true;
            this.rb_csokkenoSorrend.Text = "rb_csokkenoSorrend";
            this.rb_csokkenoSorrend.UseVisualStyleBackColor = true;
            this.rb_csokkenoSorrend.CheckedChanged += new System.EventHandler(this.rb_csokkenoSorrend_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1181, 450);
            this.Controls.Add(this.rb_csokkenoSorrend);
            this.Controls.Add(this.rb_otvennelTobb);
            this.Controls.Add(this.rb_nemkapott_ervenytelent);
            this.Controls.Add(this.rb_tizneltobb_ervenytelen);
            this.Controls.Add(this.rb_nyertes);
            this.Controls.Add(this.rb_ervenytelenek);
            this.Controls.Add(this.rb_osszes_ervenyes);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton rb_osszes_ervenyes;
        private System.Windows.Forms.RadioButton rb_ervenytelenek;
        private System.Windows.Forms.RadioButton rb_nyertes;
        private System.Windows.Forms.RadioButton rb_tizneltobb_ervenytelen;
        private System.Windows.Forms.RadioButton rb_nemkapott_ervenytelent;
        private System.Windows.Forms.RadioButton rb_otvennelTobb;
        private System.Windows.Forms.RadioButton rb_csokkenoSorrend;
    }
}

