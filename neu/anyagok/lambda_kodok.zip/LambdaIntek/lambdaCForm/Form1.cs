﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lambdaCForm
{
    public partial class Form1 : Form
    {
        static Random r = new Random();
        List<int> szamok = new List<int>();
        public Form1()
        {
            InitializeComponent();
            General();
            Kiir(listBox1, szamok);
        }

        void General()
        {
            for (int i = 0; i < 20; i++)
            {
                szamok.Add(r.Next(-20,21));
            }
        }

        void Kiir(ListBox lb, List<int> szamLista)
        {
            foreach (var item in szamLista)
            {
                lb.Items.Add(item);
            }
        }

        void Kiir(ListBox lb, int szam)
        {
            lb.Items.Add(szam);
        }

        private void otnelNagyobb_CheckedChanged(object sender, EventArgs e)
        {
            var otnelNagyobbak = szamok.Where(x => x > 5).ToList();
            Kiir(listBox2, otnelNagyobbak);
        }

        private void utolsoParos_CheckedChanged(object sender, EventArgs e)
        {
            int utolsoParos = szamok.Last(x => x % 2 == 0);
            Kiir(listBox2, utolsoParos);
        }

        private void szamokKobei_CheckedChanged(object sender, EventArgs e)
        {
            var kobok = szamok.Select(x => (int)Math.Pow(x, 3)).ToList();
            Kiir(listBox2, kobok);
        }

        private void legnagyobbNegativ_CheckedChanged(object sender, EventArgs e)
        {
            var bigneg = szamok.Where(x => Math.Sign(x) == -1).Max();
            Kiir(listBox2, bigneg);
        }
    }
}
