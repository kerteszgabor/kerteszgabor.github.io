﻿namespace LambdaB
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.eredeti = new System.Windows.Forms.ListBox();
            this.eredmeny = new System.Windows.Forms.ListBox();
            this.nagybetusSzavak = new System.Windows.Forms.RadioButton();
            this.elsoTBetus = new System.Windows.Forms.RadioButton();
            this.elsoOtnelHoszabb = new System.Windows.Forms.RadioButton();
            this.pTorlo = new System.Windows.Forms.RadioButton();
            this.negyKar = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // eredeti
            // 
            this.eredeti.FormattingEnabled = true;
            this.eredeti.Location = new System.Drawing.Point(50, 40);
            this.eredeti.Name = "eredeti";
            this.eredeti.Size = new System.Drawing.Size(161, 355);
            this.eredeti.TabIndex = 0;
            // 
            // eredmeny
            // 
            this.eredmeny.FormattingEnabled = true;
            this.eredmeny.Location = new System.Drawing.Point(599, 40);
            this.eredmeny.Name = "eredmeny";
            this.eredmeny.Size = new System.Drawing.Size(161, 355);
            this.eredmeny.TabIndex = 1;
            // 
            // nagybetusSzavak
            // 
            this.nagybetusSzavak.AutoSize = true;
            this.nagybetusSzavak.Location = new System.Drawing.Point(258, 84);
            this.nagybetusSzavak.Name = "nagybetusSzavak";
            this.nagybetusSzavak.Size = new System.Drawing.Size(116, 19);
            this.nagybetusSzavak.TabIndex = 2;
            this.nagybetusSzavak.TabStop = true;
            this.nagybetusSzavak.Text = "nagybetus nevek";
            this.nagybetusSzavak.UseVisualStyleBackColor = true;
            this.nagybetusSzavak.CheckedChanged += new System.EventHandler(this.nagybetusSzavak_CheckedChanged);
            // 
            // elsoTBetus
            // 
            this.elsoTBetus.AutoSize = true;
            this.elsoTBetus.Location = new System.Drawing.Point(258, 145);
            this.elsoTBetus.Name = "elsoTBetus";
            this.elsoTBetus.Size = new System.Drawing.Size(114, 19);
            this.elsoTBetus.TabIndex = 3;
            this.elsoTBetus.TabStop = true;
            this.elsoTBetus.Text = "Első T betűs szó";
            this.elsoTBetus.UseVisualStyleBackColor = true;
            this.elsoTBetus.CheckedChanged += new System.EventHandler(this.elsoTBetus_CheckedChanged);
            // 
            // elsoOtnelHoszabb
            // 
            this.elsoOtnelHoszabb.AutoSize = true;
            this.elsoOtnelHoszabb.Location = new System.Drawing.Point(258, 198);
            this.elsoOtnelHoszabb.Name = "elsoOtnelHoszabb";
            this.elsoOtnelHoszabb.Size = new System.Drawing.Size(135, 19);
            this.elsoOtnelHoszabb.TabIndex = 4;
            this.elsoOtnelHoszabb.TabStop = true;
            this.elsoOtnelHoszabb.Text = "Első ötnél hosszabb";
            this.elsoOtnelHoszabb.UseVisualStyleBackColor = true;
            this.elsoOtnelHoszabb.CheckedChanged += new System.EventHandler(this.elsoOtnelHoszabb_CheckedChanged);
            // 
            // pTorlo
            // 
            this.pTorlo.AutoSize = true;
            this.pTorlo.Location = new System.Drawing.Point(440, 84);
            this.pTorlo.Name = "pTorlo";
            this.pTorlo.Size = new System.Drawing.Size(119, 19);
            this.pTorlo.TabIndex = 5;
            this.pTorlo.TabStop = true;
            this.pTorlo.Text = "P betűsek törlése";
            this.pTorlo.UseVisualStyleBackColor = true;
            this.pTorlo.CheckedChanged += new System.EventHandler(this.pTorlo_CheckedChanged);
            // 
            // negyKar
            // 
            this.negyKar.AutoSize = true;
            this.negyKar.Location = new System.Drawing.Point(440, 169);
            this.negyKar.Name = "negyKar";
            this.negyKar.Size = new System.Drawing.Size(49, 19);
            this.negyKar.TabIndex = 6;
            this.negyKar.TabStop = true;
            this.negyKar.Text = "4kar";
            this.negyKar.UseVisualStyleBackColor = true;
            this.negyKar.CheckedChanged += new System.EventHandler(this.negyKar_CheckedChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.negyKar);
            this.Controls.Add(this.pTorlo);
            this.Controls.Add(this.elsoOtnelHoszabb);
            this.Controls.Add(this.elsoTBetus);
            this.Controls.Add(this.nagybetusSzavak);
            this.Controls.Add(this.eredmeny);
            this.Controls.Add(this.eredeti);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox eredeti;
        private System.Windows.Forms.ListBox eredmeny;
        private System.Windows.Forms.RadioButton nagybetusSzavak;
        private System.Windows.Forms.RadioButton elsoTBetus;
        private System.Windows.Forms.RadioButton elsoOtnelHoszabb;
        private System.Windows.Forms.RadioButton pTorlo;
        private System.Windows.Forms.RadioButton negyKar;
    }
}

