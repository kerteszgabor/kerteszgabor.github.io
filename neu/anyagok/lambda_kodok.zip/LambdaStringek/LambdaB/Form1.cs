﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LambdaB
{
    public partial class Form1 : Form
    {
        static string bemenet = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
        static List<string> feldolgozott = new List<string>();

        public Form1()
        {
            InitializeComponent();
            feldolgozott = Feldolgoz();
            Kiir(eredeti, feldolgozott);
        }

        List<string> Feldolgoz()
        {
            bemenet.Remove('.');
            bemenet.Remove(',');
            List<string> feldolgozott = bemenet.Split(' ').ToList();
            return feldolgozott;
        }

        void Kiir(ListBox lb, List<string> elemek)
        {
            lb.Items.Clear();
            foreach (var item in elemek)
            {
                lb.Items.Add(item);
            }
        }

        void Kiir(ListBox lb, string elem)
        {
            lb.Items.Clear();
            if (elem != null)
            {
                lb.Items.Add(elem);
            }
            else
            {
                lb.Items.Add("Nincs ilyen elem");
            }
        }

        private void nagybetusSzavak_CheckedChanged(object sender, EventArgs e)
        {
            var eredmenyek = feldolgozott.Select(x => x.ToUpper()).ToList();
            Kiir(eredmeny, eredmenyek);
        }

        private void elsoTBetus_CheckedChanged(object sender, EventArgs e)
        {
            string elsoTbetus = feldolgozott.Where(x => x[0] == 'T').FirstOrDefault();
            Kiir(eredmeny, elsoTbetus);
        }

        private void elsoOtnelHoszabb_CheckedChanged(object sender, EventArgs e)
        {
            string elsoOtnelHosszabb = feldolgozott.Where(x => x.Length > 5).FirstOrDefault();
            Kiir(eredmeny, elsoOtnelHosszabb);
        }

        private void pTorlo_CheckedChanged(object sender, EventArgs e)
        {
            var pBetusek = feldolgozott.Where(x => x.StartsWith("p") || x.StartsWith("P")).ToList();
            var eredmenyek = feldolgozott.Where(x => !pBetusek.Contains(x)).ToList();
            var eredmenyek2 = feldolgozott.Except(pBetusek);
            bool egyenlo = eredmenyek == eredmenyek2;
            Kiir(eredmeny, eredmenyek);
        }

        private void negyKar_CheckedChanged(object sender, EventArgs e)
        {
            bool negyKarakter = !feldolgozott.Any(x => x.Length > 4);
            Kiir(eredmeny, negyKarakter == false ? "Nem, van hosszabb!" : "Nincs hosszabb, mint 4");
        }
    }
}
