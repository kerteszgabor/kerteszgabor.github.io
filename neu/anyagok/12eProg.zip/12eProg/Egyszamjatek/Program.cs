﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Egyszamjatek
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Jatekos> jatekosok = new List<Jatekos>();
            Beolvas("egyszamjatek.txt", jatekosok);

            Console.WriteLine("3. feladat: Játékosok száma: " + jatekosok.Count);

            Console.WriteLine("4. feladat: Fordulók száma: " + jatekosok.First().Eredmenyek.Count);

            // 5-ös feladat
            bool voltEgyes = jatekosok.Select(x => x.Eredmenyek.First()).Contains(1);
            if (voltEgyes)
            {
                Console.WriteLine("5. feladat: volt egyes!");
            }
            else
            {
                Console.WriteLine("5. feladat: nem volt egyes!");
            }

            int legagyobbTipp = jatekosok.SelectMany(x => x.Eredmenyek).Max();
            Console.WriteLine("6. feladat: legnagyobb tipp: " + legagyobbTipp);

            Console.Write($"7. feladat: kérem egy forduló sorszámát [1-{jatekosok.Count+1}]");
            string beolvas = Console.ReadLine();

            int gyoztesTipp = GyoztesTipp(jatekosok, beolvas);
            if (gyoztesTipp != -1)
            {
                Console.WriteLine("8. feladat: győztes a tipp a fordulóban: " + gyoztesTipp);
                var forduloEredmeny = jatekosok.Select(x => x.Eredmenyek[int.Parse(beolvas) + 1]).ToList();
                Console.WriteLine(jatekosok.Where(x => x.Eredmenyek[int.Parse(beolvas) + 1] == gyoztesTipp).FirstOrDefault().Nev);
                KiirFajlba(forduloEredmeny);
            }
            else
            {
                Console.WriteLine("nem volt gyoztes");
            }

            Console.ReadLine();
        }

        static int GyoztesTipp(List<Jatekos> jatekosok, string beolvas)
        {
            var forduloEredmenyei = jatekosok.Select(x => x.Eredmenyek[int.Parse(beolvas)-1]).ToList();
            forduloEredmenyei.OrderBy(x => x);
            foreach (var item in forduloEredmenyei)
            {
                var elofordulasokSzama = forduloEredmenyei.Where(x => x == item).Count();
                if (elofordulasokSzama == 1)
                {

                    return item;
                }
            }
            return -1;
        }

        static void Beolvas(string fajl,  List<Jatekos> jatekosok)
        {
            if (File.Exists(fajl))
            {
                StreamReader f = File.OpenText(fajl);
                while (!f.EndOfStream)
                {
                    string[] darabolt = f.ReadLine().Split(' ');
                    int i = 0;
                    Jatekos jatekos = new Jatekos();
                    jatekos.Eredmenyek = new List<int>();           // NULL reference

                    while (i < darabolt.Length)
                    {
                        if (Char.IsDigit(darabolt[i][0]))
                        {
                            jatekos.Eredmenyek.Add(int.Parse(darabolt[i]));
                        }
                        else
                        {
                            jatekos.Nev = darabolt[i];
                        }
                        ++i;
                    }
                    jatekosok.Add(jatekos);
                }
            }
            else
            {
                Console.WriteLine("Nincs fájl");
            }
        }

        static void KiirFajlba(List<int> forduloEredmenye)
        {
            StreamWriter r = new StreamWriter("nyertes.txt");
            foreach (var item in forduloEredmenye)
            {
                r.WriteLine(item);
            }
            r.Close();
        }
    }

    class Jatekos
    {
        public string Nev { get; set; }

        public List<int> Eredmenyek { get; set; }
    }
}
